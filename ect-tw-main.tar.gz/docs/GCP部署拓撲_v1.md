# ECT-TW GCP 部署拓撲 v1（2026-11-18）

- **定案**：2026-11-18 洪哥指定「伺服器要用 GCP」。
- **區域**：`asia-east1`（彰化）— 個資落地台灣、延遲最低；異地備份 `asia-east1` 多可用區。
- **狀態**：設計文件。**本批未部署**；上線前需洪哥再次 confirm（動生產照規矩）。
- 與自家《藍新金流申請與嵌入 SOP》的 `gcloud compute ssh/scp` 環境一致（同一個本機 SDK／帳號可管理多專案）。
- **⚠️ ECT-TW 應另建獨立 GCP 專案，不與 PickMyOrder 共用**（見 §8 實測：本機 active 專案為 `pickmyorder-prod`）。理由同藍新商店代號不得借讓：帳單歸屬、IAM 邊界、Cloud SQL 資料隔離、律師主體認定皆須切乾淨。

---

## 1. 架構圖

```
                    Internet (HTTPS only)
                            │
                  Cloud Load Balancing
                  + Cloud Armor (WAF/速率限制)
                  + 代管 SSL 憑證
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
   Cloud Run (API)     Cloud Run (官網)    Cloud Storage
   ect-tw-api          ect-tw-web         靜態資源/憑證
   Node 22 Express     (M1 後段)          （信託存入憑證 PDF）
        │                                      ▲
        │  VPC Connector (Serverless)           │ Signed URL
        ├──────────────┬───────────────────────┘
        │              │
  Cloud SQL for PostgreSQL 16   Secret Manager
  私人 IP / 無公網 IP          NEWEBPAY_*/ECT_*/DB
  HA + 自動備份(PITR)          （版本化、審計、輪替）
        │
  Cloud Scheduler → Cloud Run Job（grace sweep / ESG 快照 / 對帳）
```

## 2. 服務選型與理由

| 元件 | 選型 | 理由 |
|------|------|------|
| 運算 | **Cloud Run**（容器、自動擴縮至 0） | 早期流量小、成本可控；`Dockerfile` 已備；不用養 VM |
| 資料庫 | **Cloud SQL for PostgreSQL 16** | 與本地 `docker-compose` 同版本；交易鎖／append-only journal／PITR 備份 |
| 密鑰 | **Secret Manager** | 藍新 HashKey/HashIV、DB 密碼、`ECT_ADMIN_TOKEN`、`ECT_SESSION_SECRET` 全不落地；對應 SOP「金鑰不貼對話/log/Git」鐵律 |
| 網路 | VPC Connector + Cloud SQL 私人 IP | DB 無公網 IP；回呼端點仍由 CLB 對外（藍新要打得到） |
| 憑證 / WAF | 代管 SSL + Cloud Armor | HTTPS-only、HSTS、回呼速率限制（SOP §七資安待辦 1） |
| 物件儲存 | Cloud Storage | 券面信託存入憑證、公益收據；Signed URL 限時取 |
| 排程 | Cloud Scheduler + Cloud Run Job | GRACE 掃描、ESG 快照、T+1 清算（不靠「服務存活才跑」的背景任務） |
| CI/CD | GitHub Actions → Artifact Registry → Cloud Run | 沿用現有 `ci.yml`；CI 已起 postgres service 跑真 DB 測試 |
| 日誌 | Cloud Logging + 告警 | 回呼 `BAD_SIGNATURE`／`AMOUNT_MISMATCH` 設警示 |

## 3. 三處必接線（沿用自家藍新 SOP §2.5）

1. **回呼不帶 Origin**：`/pay/newebpay/*` 不得以 Origin 當認證，改以 `TradeSha` 驗簽／解密。Cloud Armor 只做速率限制，不做 Origin 白名單擋回呼。
2. **CSP `form-action`**：已放行 `https://core.newebpay.com`／`https://ccore.newebpay.com`（`src/server.js` helmet），否則瀏覽器封鎖表單 POST。
3. **form-urlencoded 自解析**：`express.text({type:()=>true})` + `parseFormBody()`，不依賴 multipart。

## 4. 環境分層

| 環境 | 用途 | 金流 |
|------|------|------|
| local | `docker compose up -d postgres` + `npm run db:migrate` | `NEWEBPAY_SANDBOX=1`、stub |
| CI | GitHub Actions + postgres service | 官方公開測試憑證，不連藍新 |
| staging | Cloud Run（asia-east1）+ Cloud SQL | 藍新測試區 `ccore` |
| prod | 同上、獨立專案/DB | 藍新正式區 `core`、Secret Manager 正式金鑰 |

> ⚠️ 自家 SOP 中 **PickMyOrder 的正式區商店代號**（詳自家 SOP，不複製進本倉庫）與其 HashKey/HashIV 屬該專案資產；ECT-TW 應用**自己的商店代號**（選我科技既有主體下另開或複用需律師/藍新確認），不可直接借讓（條款第 17 條）。

## 5. 上線前檢查清單（部署時逐項回讀）

- [ ] `ECT_GCP_PROJECT`／`ECT_GCP_REGION=asia-east1` 已設
- [ ] Secret Manager 六支密鑰齊備，Cloud Run 服務帳戶有 `secretmanager.secretAccessor`
- [ ] Cloud SQL 私人 IP、無公網；PITR 與自動備份開啟
- [ ] `npm run db:migrate` 在 staging 跑過，`db:status` 顯示 001/002
- [ ] `GET /health` → `0.2.0-m1`；`GET /health/db` → `ok:true`；`GET /api/public/esg` → `source:ledger`
- [ ] `GET /api/admin/newebpay` 類回讀只回遮罩，明文不出畫面
- [ ] 對外 `/pay/newebpay/notify` 可達（無 Origin 也不被擋）
- [ ] 藍新測試區小額真交易一次，確認 `newebpay_txn` → PAID、`orders` → FULFILLED、券正確產生
- [ ] Cloud Logging 無 `BAD_SIGNATURE`／`AMOUNT_MISMATCH` 異常告警
- [ ] **律師意見書已回覆**（代收代付／發票時點／信託憑證流程）才開正式收款

## 6. 成本量級（早期，僅供預算，非報價）

| 項目 | 量級 |
|------|------|
| **早期替代（M1，推薦）**：單台 e2-micro ＋ 20GB pd-balanced | **≈ NT$ 292/月，上限 380**（可對撞算式見 `docs/單VM上線SOP_v1.md` §2） |
| Cloud Run（API + web，低流量） | 近乎免費額度內～數百元/月 |
| Cloud SQL（最小 HA 執行個體） | 主要固定成本，約 NT$ 2–4 千/月 |
| Secret Manager / Artifact Registry / Logging | 數十～百元/月 |
| Cloud Load Balancing + Armor | 約 NT$ 數百～千元/月 |

> 與規格書 §8「首年外部成本 NT$ 60–90 萬」口徑一致：該數字主體是法遵意見書、主體設立、域名與行政，雲端基礎設施佔比低。
>
> **2026-11-18 補充（洪哥定「早期月成本 ≤ NT$380」）**：§2–§5 的 Cloud Run＋Cloud SQL 拓撲**改列為 M2 升級路徑**，不作廢；**M1 上線採單台 e2-micro VM**，與本機 POC 共用同一份 `docker-compose.yml`。服務無狀態、狀態全在 PG、金鑰全走環境變數，日後搬 Cloud Run 零改動。落地細節見 `docs/單VM上線SOP_v1.md`。

## 7. 已知限制

- 本文件為拓撲設計，**未建立任何 GCP 資源、未部署、未產生費用**。
- 正式區藍新商店代號歸屬待確認（見 §4 警告）。
- 電子發票加值中心（ezPay）尚未串接，M1 後段處理。
- 與大陸版 `211.159.225.80`（自架 nginx）完全分離，不做跨境資料庫同步；個資不出台灣。

---

## 8. 連線健檢紀錄（2026-11-18，唯讀，未部署、未產生費用）

洪哥指示「直接連上 GCP 看看」，本機實測結果：

| 檢查項 | 結果 | 判讀 |
|--------|------|------|
| Google Cloud SDK | `589.0.0`（`~/AppData/Local/Google/Cloud SDK/`） | ✅ 已裝 |
| 登入帳號 | `houpen0928@gmail.com`（ACTIVE） | ✅ 憑證存在（`credentials.db`，2026-10-17） |
| `gcloud config` | active configuration `default`、**project = `pickmyorder-prod`** | 🔴 **連到的是 PickMyOrder，不是 ECT-TW** |
| `gcloud projects list` 等 5 個 API | 全部 `oauth2.googleapis.com/token` refresh 502 | 🔴 access token 過期要 refresh，通道被擋 |
| 對照組：`api.github.com` via proxy | **200** | ✅ proxy 本身活著 |
| 對照組：`www.google.com` / `oauth2` / `googleapis` | **000 / 502** | 🔴 Google 全系被沙盒 proxy 白名單擋掉 |
| 第二種獨立抓法 `gcloud auth print-access-token` | 同樣 502 | ✅ 交叉驗證：非 curl 問題、非單一指令問題 |

**結論**：不是 GCP 帳號或憑證問題，是 **WorkBuddy 沙盒對外 proxy（`127.0.0.1:51812`）只放行特定網域（GitHub 通、Google 不通）**，導致 token refresh 失敗。本機環境是齊的，只差連線通道。

### 8.1 本機 cmd 實測（2026-11-18 16:17，洪哥提供截圖）

```
C:\Users\A>gcloud config list & gcloud projects list
[core] account = houpen0928@gmail.com / project = pickmyorder-prod   ← 正常
（gcloud projects list 無輸出、無錯誤、無提示符 → 命令未返回，卡在網路）
```

- 判讀：帳號與設定正常，但 `projects list` **卡住不返回**（cmd 環境無 `HTTP_PROXY`，開發機位於江蘇昆山，直連 Google API 不可達）。這與沙盒的 502 是同一個根本問題的兩面：**沙盒是白名單擋、本機是沒走代理**。
- 次要可能：cmd 用 `&` 串接兩個 `gcloud.cmd` 時，第二個的 stdout 可能被 console 緩衝吞掉 → 驗證方式就是**分開跑**。
- **正解建議：改用 Cloud Shell**（`console.cloud.google.com` → 右上 `>_`）。終端跑在 Google 機房、已認證，完全繞開本地網路與代理設定，是跨國團隊最穩的運維入口。
- 診斷順序：單獨跑 `gcloud auth print-access-token` —— 卡住/報錯＝網路或認證層；能印出 token＝網路正常，問題在專案權限或 API。

**上線前置待辦（補充 §5）**：- [ ] **另建 ECT-TW 專屬 GCP 專案**（建議 ID `ect-tw-prod`，綁選我科技帳單帳戶），並新增 `gcloud config configurations create ect-tw` 獨立設定，避免誤用 `pickmyorder-prod`
- [ ] 在非沙盒環境（洪哥本機終端或授權通道）執行唯讀盤點：`gcloud projects list` / `services list --enabled` / `compute instances list` / `sql instances list` / `run services list`
- [ ] 啟用 API：`run.googleapis.com`、`sqladmin.googleapis.com`、`secretmanager.googleapis.com`、`artifactregistry.googleapis.com`、`cloudresourcemanager.googleapis.com`
- [ ] 確認 `asia-east1` 配額與帳單帳戶已綁；建立服務帳號（最小權限）與 Secret Manager 金鑰槽位
- [ ] 上述完成後，**實際部署仍需洪哥再 confirm 一次**（動基礎設施／動錢不自動執行）
