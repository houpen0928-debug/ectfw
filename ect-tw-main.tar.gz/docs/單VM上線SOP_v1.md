# ECT-TW 單 VM 上線 SOP v1（早期低用量最省方案）

- **日期**：2026-11-18
- **決策依據**：洪哥定案「平台主體＝選我科技有限公司」「雲端＝GCP asia-east1 彰化」「早期月成本目標 **≤ NT$380**」
- **狀態**：規劃＋腳本已落地；**未建任何 GCP 資源、未產生費用**。動資源／動正式收款前需洪哥再 confirm
- **對應工程**：`docker-compose.yml`（本機 POC 與上線同一份）、`deploy/nginx/{http,ssl}.conf`、`scripts/backup.sh`／`restore.sh`／`crontab.example`、`scripts/check-prod-compose.js`

---

## 1. 結論

早期最省不是 Cloud Run，而是**一台台灣 VM 全包（Node + PostgreSQL + nginx）**。省錢關鍵不是選哪個雲服務，而是**避開固定月費**：Cloud SQL 最小規格不能停機，用量再小照收，是早期最大的冤枉錢。

| 方案 | 月成本 | 判斷 |
|---|---|---|
| 本機 Docker（POC） | **NT$ 0** | 功能全驗得過，CI 也有真 PG |
| **e2-micro 單 VM ＋ 20GB** | **≈ NT$ 292**（上限 380） | ✅ **推薦** |
| e2-small 單 VM ＋ 20GB | ≈ NT$ 518 | 2GB RAM 較穩，但超出 380 目標，要重新拍板 |
| Cloud Run ＋ Cloud SQL | ≈ NT$ 860–1,120 | API 可縮到 0，但 DB 固定費壓不下來 |
| 蹭既有 `ainiuvpn-tw` | NT$ 0 | 🔴 不建議：VPN 節點被封／被掃機率高、資源互搶、攻擊面擴大 |

**一年差約 NT$ 8,000**（對比 Cloud Run＋Cloud SQL）。等日均請求上千、或需要 PITR／HA 再搬，那時才值得。

---

## 2. 成本重算（每格給算式，可自行對撞）

**計價來源（2026-11-18 核實）**

| 來源 | 數值 |
|---|---|
| `gcloud-compute.com/asia-east1/e2-micro.html` | e2-micro 標準 **US$0.0097/hr → US$7.08/月**（730hr）；2 vCPU 共享 / **1GB RAM** |
| `gcloud-compute.com/asia-east1/e2-small.html` | e2-small **US$0.0194/hr → US$14.16/月**；2GB RAM |
| pd-balanced asia-east1 | 約 **US$0.102/GB-月**（以官方計價器為準） |
| 匯率 | 以 **US$1 = NT$32** 估算（以實際帳單為準） |
| 外部 IP | 附掛於**運行中** VM 的外部 IP 免費；未附掛／VM 停止才計費 |
| egress | Standard Tier 200GB/月免費，早期低用量用不到 |

**算式**

| 項目 | 算式 | US$/月 | NT$/月 |
|---|---|---|---|
| e2-micro 運算 | 0.0097 × 730 | 7.08 | 226.6 |
| pd-balanced 20GB | 0.102 × 20 | 2.04 | 65.3 |
| 外部 IP（附掛） | 0 | 0 | 0 |
| egress < 200GB | 0 | 0 | 0 |
| **合計** | | **9.12** | **≈ 292** |
| **380 上限** | 292 ＋ **88 緩衝**（快照／log／匯率浮動／零星 egress） | | **≤ 380** ✅ |

> ⚠️ **修正前一版對話估算**：e2-small 曾報「NT$440」→ 實為 US$14.16×32 = NT$453（尚未含磁碟），含 20GB 應為 **NT$518**；e2-micro 曾報「NT$190」→ 實為 **NT$292 含碟**。落差來自：①漏算 20GB 開機磁碟 ②asia-east1 區域溢價 ③匯率。這正是「文件數字要能自動對撞」的用途——本表每格都給算式，任何人都能重算。

> ⚠️ 免費層資料庫（Neon／Supabase）**全部不合格**：機房都在新加坡／東京／美西，而規格書紅線是**個資不出台灣**。開發期無真實個資可用本機 PG；一有用戶資料就必須台灣落地。先用免費層、上線再搬，不如一開始就用標準 PG（我們無專屬 API，schema 完全相容）。

---

## 3. 1GB RAM 的取捨（e2-micro 不是 2GB）

| 元件 | compose 上限 | 實估 |
|---|---|---|
| OS ＋ Docker daemon | — | 150–200 MB |
| PostgreSQL 16 | 384 MB | 250–300 MB（`shared_buffers=128MB`、20 連線） |
| Node app | 256 MB | 80–120 MB |
| nginx | 64 MB | 10–20 MB |
| **合計** | **704 MB** | 約 500–640 MB |

1GB 夠，但**必須加 1GB swap** 防突發 OOM。`mem_limit` 已寫進 compose，並由檢查器 `R07` 把關（CI 會檔下任何放寬）。PG 調參在 `docker-compose.yml` 的 `command:` 裡，不是靠容器預設值。

> 日後要 2GB：只改 `--machine-type=e2-small`，**compose 完全不用動**，成本變 NT$518（超出 380，需重新拍板）。

---

## 4. TLS：Cloudflare Origin CA，不用 certbot

| | Origin CA（本 SOP 採用） | certbot | Cloudflare Tunnel |
|---|---|---|---|
| 額外容器 | **0** | 1（＋續期 cron） | 1（cloudflared，約 40MB） |
| 憑證管理 | 一張，有效期可選 15 年 | 90 天自動續 | 免 |
| 入站埠 | 853 → 只 443 | 需開 80 驗證 | **全關**（出站連 CF） |
| 決策 | ✅ 最省 RAM、已落地 | ❌ 1GB 不值得 | 🟡 不想管防火牆／憑證時替代 |

- 用戶 → Cloudflare（80/443）→ Origin（**只 443**）；HTTP→HTTPS 由 Cloudflare「Always Use HTTPS」處理
- 防火牆**只放行 Cloudflare IP 段的 443**（IP 段會變，以 `https://www.cloudflare.com/ips-v4` 為準，勿寫死在文件）
- Origin CA 憑證只信任 Cloudflare → 瀏覽器直連 VM 公網 IP 會顯示不受信任，**這是刻意設計**（隱藏真實 IP）
- 建議再開 **Authenticated Origin Pulls（mTLS）**，`deploy/nginx/ssl.conf` 已留兩行註解，取消即可
- SSH 走 IAP／Cloud Shell，**不開 0.0.0.0/0 的 22**

---

## 5. VM 建立指令（**只給指令，不執行**）

> 🔴 執行前先 confirm：從這一步開始計費（e2-micro ≈ NT$292/月）。專案需先存在（`docs/GCP專案建立操作清單_v1.md`），帳單綁**選我科技**。

```bash
gcloud config set project ecttwprod2
gcloud config set compute/region asia-east1

# 建立 VM（Ubuntu 22.04 LTS，勿用 2604 太新；pd-balanced 20GB）
gcloud compute instances create ect-tw-vm \
  --zone=asia-east1-b \
  --machine-type=e2-micro \
  --image-project=ubuntu-os-cloud \
  --image-family=ubuntu-2204-lts \
  --boot-disk-type=pd-balanced \
  --boot-disk-size=20GB \
  --tags=ect-tw-edge

# 防火牆：只放行 Cloudflare 的 443（先到 cloudflare.com/ips-v4 取當下 IP 段）
gcloud compute firewall-rules create ect-tw-allow-cf-443 \
  --direction=INGRESS --priority=1000 --network=default \
  --action=ALLOW --rules=tcp:443 \
  --source-ranges="<填入 Cloudflare IPv4 段，逗號分隔>" \
  --target-tags=ect-tw-edge

# SSH 走 IAP（不放 0.0.0.0/0）
gcloud compute firewall-rules create ect-tw-allow-iap-ssh \
  --direction=INGRESS --priority=1000 --network=default \
  --action=ALLOW --rules=tcp:22 \
  --source-ranges=35.235.240.0/20 --target-tags=ect-tw-edge

# 1GB swap（e2-micro 必做）
sudo fallocate -l 1G /swapfile && sudo chmod 600 /swapfile
sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
sudo sysctl -w vm.swappiness=10
```

**驗收**：`gcloud compute firewall-rules list` 中沒有任何 `0.0.0.0/0` 放行 22 或 5433 的規則。

---

## 6. 部署步驟

```bash
# VM 上
sudo apt-get update && sudo apt-get install -y docker.io docker-compose-plugin
sudo mkdir -p /opt/ect-tw && cd /opt/ect-tw

# 私有倉庫：不在 VM 上放 GitHub token。二擇一：
#   (a) 本機打包上傳：git archive --format=tar.gz -o ect-tw.tar.gz main
#       gcloud compute scp ect-tw.tar.gz ect-tw-vm:/tmp/ --zone=asia-east1-b --project=ecttwprod2
#   (b) 或建立「唯讀 deploy key」供 VM 使用（可持續 git pull）

sudo cp .env.example .env
sudo nano .env    # 必填：ECT_PG_PASSWORD（隨機）、NEWEBPAY_*、ECT_ADMIN_TOKEN
                  # 切換：ECT_NODE_ENV=production / NGINX_CONF=ssl
                  #       ECT_EDGE_PORT=80 / ECT_TLS_PORT=443
# Cloudflare Origin CA 憑證放 deploy/certs/origin.pem + origin.key（chmod 600 key）

sudo docker compose up -d --build     # app 啟動會自動跑 db:migrate（冪等）
sudo docker compose ps                # 三個服務都要 healthy
curl -k  https://127.0.0.1/nginx-health
curl -k  https://127.0.0.1/health
curl -k  https://127.0.0.1/health/db
```

⚠️ `.env` 不入庫、不進 image（`.gitignore` 與 `.dockerignore` 雙重排除）。正式金鑰長期應走 GCP Secret Manager 注入，見 `docs/GCP部署拓撲_v1.md`。

---

## 7. 備份與還原

```bash
# VM 宿主 crontab（scripts/crontab.example）
17 3 * * * cd /opt/ect-tw && ECT_BACKUP_KEEP_DAYS=14 ./scripts/backup.sh >> /var/log/ect-backup.log 2>&1

# 手動備份 / 還原
npm run db:backup
npm run db:restore -- backups/ect_tw-20261118-031700.dump   # 需輸入 YES 二次確認

# 每週異地留一份（Windows 本機）
gcloud compute scp ect-tw-vm:/opt/ect-tw/backups/ect_tw-*.dump C:/backup/ect-tw/ --zone=asia-east1-b --project=ecttwprod2
```

- `backup.sh` 用 `docker compose exec -T postgres pg_dump`（`-T` 因 cron 無 TTY），**不額外跑容器**，省 1GB RAM
- 空 dump 視為失敗並刪除，避免日後還原拿到 0 byte；保留 14 天
- `restore.sh` 會先停 app、還原後不論成敗都拉回 app（trap）；`--clean --if-exists` 會 DROP 既有物件，故強制輸入 `YES`

---

## 8. 上線驗收清單

- [ ] `docker compose ps` → postgres / app / nginx 皆 **healthy**
- [ ] `npm run db:check` → 版本表 **001／002／003／004** 齊全，checksum 無漂移
- [ ] `npm run verify` → 76 支（69 pass／7 CI-only skip）、禁詞 0、`npm run compose -- --selftest` 18 條全綠
- [ ] `/health` 200、`/health/db` 200、`/api/public/esg` 200
- [ ] **官網**：`/` 200（無尾斜線亦為 200）、`/style.css` 200、`/app.js` 200、`/api/public/site` 200 且含 `heroTitle`
  - [ ] ESG 數字條讀取失敗時顯示「—」，不得以估算值替代
  - [ ] **法遵門面**：頁尾顯示公司名稱／統一編號 **62023886**／代表人／登記地址；`/api/public/site` 回傳 `copy.entity.*` 非空
  - [ ] 首頁含「禮券定型化契約專區」「發行人與平台的分工」「常見問答」；券廣場分類標註「建置中」，不得以空殼電商分類呈現
  - [ ] **最新版 academia 首頁**：雙欄首屏、三步驟流程、產學合作專區、企業諮詢表單皆存在；`/api/public/site` 含 `heroTitleV2` 與 `academiaV1` 鍵；諮詢僅開郵件草稿、不落地資料
  - [ ] 🔴 客服申訴專線若另設專線，先改 `.env` 的 `ECT_ENTITY_SERVICE_PHONE` 再上線（目前暫用公司電話 02-28097206）
  - [ ] 隱私權政策＋Cookie 同意橫幅已上線（個資法，§2.7／§4.1）
- [ ] **後台**：`/admin`（無尾斜線 301 → `/admin/` 屬正常，用 `-L` 驗）200、`/admin/app.js` 200、`/admin/style.css` 200
  - [ ] 未帶 `X-Admin-Token` 打 `/api/admin/overview` → **401**；帶正確 token → 200 且 `compliance` 可查
  - [ ] 🔴 上線前補**平台 HQ TOTP 二階登入**；目前僅單因子，勿直接對外開放
- [ ] **核銷台**：`/verify/` 200、`/verify/app.js` 200、`/verify/style.css` 200、`/api/verify/config` 200
  - [ ] `/verify`（無尾斜線）301 → `/verify/` 屬正常，勿關掉 express.static 的目錄正規化（否則相對路徑會壞）
  - [ ] 未帶 `X-Verify-Key` 打 `/api/verify/lookup` → **503**（fail-closed）
  - [ ] `.env` 已設 `ECT_VERIFY_KEY`／`ECT_VERIFY_VENDOR_ID`，且該 vendor 與券的發行人一致
- [ ] **電子發票**：帶 `X-Admin-Token` 打 `/api/admin/invoices` → 200 且 `monitor` 可查
  - [ ] `ECT_INVOICE_PROVIDER` 只先用 `stub` 或 `http`；🔴 **未取得 ezPay 官方技術文件前勿設 `ezpay`**（`EZPAY_HOST` 未設會 fail-closed，不會誤送）
  - [ ] `ECT_INVOICE_ISSUE_POINT` 依**律師意見書 C2** 設定（ORDER／REDEEM），勿自行假定
- [ ] 藍新 notify 偽造簽章 → `200 REJECT:FAIL_CLOSED`（不阻塞、不重送）
- [ ] 外部經 Cloudflare 域名可訪問；**直連 VM 公網 IP 被拒**
- [ ] 防火牆無 `0.0.0.0/0` 放行 22／5433
- [ ] `./scripts/backup.sh` 產出非空 dump，並完成一次異地抓取
- [ ] 帳單歸屬確認為**選我科技有限公司**

---

## 9. 何時搬走（升級觸發，非現在）

| 觸發條件 | 動作 | 成本變化 |
|---|---|---|
| 日均請求 > 1,000／PG 連線常滿 | 先升 `e2-small`（compose 不改） | NT$292 → 518 |
| 需要 PITR／HA／託管備份 | 搬 Cloud SQL（須 confirm） | ＋NT$2–4 千/月 |
| 需要多實例／自動擴縮 | 搬 Cloud Run（**服務無狀態，零改動**） | 依用量 |

現在用 VM，未來搬 Cloud Run 幾乎零改動：狀態全在 PG、金鑰全走環境變數、服務本身無狀態。**不要為了省錢把架構寫死**——這是這版設計真正的價值。

---

## 10. 費用紅線

| 不做 | 理由 |
|---|---|
| 不自動建 VM／Cloud SQL／CLB／Cloud Run | 動資源即計費，須洪哥 confirm |
| 不代綁帳單 | 主體認列與發票歸屬，人工處理 |
| 不蹭 `ainiuvpn-tw` | 見 §1 |
| 不為了壓成本改用境外免費 DB | 個資不出台灣 |
| 不放寬 `mem_limit`／改用 certbot | 1GB RAM 硬約束，CI 會檔 |
