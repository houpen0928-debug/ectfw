# ECT-TW GCP 專案建立操作清單 v1（2026-11-18）

> 目的：把 ECT-TW 的地基佔好（專案、區域、API），**不建任何付費資源**。
> 適用：洪哥在 Console 已登入（`houpen0928@gmail.com`）。全程約 10 分鐘。

## 執行記錄（2026-11-25 批次 C 實測，取代本文件部分預設）

| 項目 | 實測結果 |
|---|---|
| 專案建立 | ⚠️ Console UI 表單點「建立」**未提交成功**（表單丟失）；改走 **Cloud Shell 終端** `gcloud projects create ecttwprod` → ✅ operation finished successfully |
| 專案 ID | **`ecttwprod`**（≠原定 `ecttwprod2`）——Cloud Shell 終端鍵盤通道無法輸入 `-`（被解析為 Insert 轉義序列）；ID 僅為標識符，對外品牌／域名不變 |
| 帳號 | `houpen0928@gmail.com`（個人 Gmail、No organization，與 §0 預設一致） |
| 帳單 | 🔴 **未綁**：唯一帳單帳戶 `0160C9-C215C6-E9FA8C`（「我的帳單帳戶 1」，直接／個人自助）**逾期——Mastercard ••••8810 遭拒、欠款 $5,146**，修付款前建 VM 必敗（SOP §10 不代綁帳單） |
| API | 未啟用（等帳單修復後 `gcloud services enable compute.googleapis.com` 一次做） |
| 通道 | 🔴 本機 gcloud CLI 不可用（本機網路對 Google 域全斷，token refresh 失敗）；GCP 操作走 **Console／Cloud Shell 終端**（IDE 模式因 WebSocket 被擋，用終端模式 `?show=terminal`） |

---

## 0. 開始前先確認兩件事

| # | 事項 | 現況 | 建議 |
|---|------|------|------|
| 1 | **用哪個帳號當擁有者** | 目前 `houpen0928@gmail.com`（個人 Gmail） | 先用它建，**別卡在等公司 Organization**。但專案會落在「No organization」下 |
| 2 | **帳單帳戶歸屬** | 未確認 | 必須是**選我科技有限公司**的帳單帳戶（發票與稅務歸屬）。個人卡代墊會讓費用認列變麻煩 |

> ⚠️ 專案 ID 是**全球唯一**，`ecttwprod2` 可能已被佔用。若建立失敗，換 `ecttwprod2-tw`／`ectw-prod`。

---

## 1. 一鍵路徑（推薦：Cloud Shell）

Console 右上角點 **`>_`** 開 Cloud Shell，把倉庫裡的腳本貼進去跑：

```bash
bash scripts/gcp-bootstrap.sh            # 建 ecttwprod2
bash scripts/gcp-bootstrap.sh ectw-prod  # 若 ID 被佔用，換一個
```

腳本做的事（**全部免費**）：
1. 建專案（已存在則跳過，可重複執行）
2. `gcloud config` 切到本專案、固定 `asia-east1`
3. 啟用 7 個 API：`cloudresourcemanager`／`run`／`sqladmin`／`secretmanager`／`artifactregistry`／`cloudbuild`／`iam`
4. 印出驗證清單與帳單狀態（**只讀不綁**）

腳本**不會**做：綁帳單、建 Cloud SQL、建 Cloud Run、建 VM、建任何收費資源。

---

## 2. Console 手點對照（不想用 CLI 就照這張）

| 步驟 | 位置 | 做什麼 | 費用 |
|---|---|---|---|
| 1 | 頂部專案選擇器 → 「新增專案」 | 名稱 `ECT-TW`、ID `ecttwprod2` | 免費 |
| 2 | 左側「帳單」→「連結帳單帳戶」 | 綁**選我科技**帳單帳戶 | 免費 |
| 3 | 搜尋列輸入「API 和服務」→「程式庫」 | 依序啟用 §1 的 7 個 API | 免費 |
| 4 | 「IAM 與管理」→「服務帳號」 | 建 `ect-tw-runner`（最小權限：Cloud Run Invoker + Secret Accessor） | 免費 |
| 5 | 「Security」→「Secret Manager」 | 建 3 個空槽：`NEWEBPAY_HASHKEY`／`NEWEBPAY_HASHIV`／`ECT_PG_URL` | 免費（僅存放） |
| 6 | 「API 和服務」→「啟用 API 和服務」→ 確認 7 個都 `已啟用` | 對照 §3 | — |
| 7 | **停手** | 建 Cloud SQL / Cloud Run 之前先跟 B哥 confirm | 🔴 會收費 |

---

## 3. 驗收清單（Cloud Shell 貼這串，輸出貼回來）

```bash
gcloud config list
gcloud projects describe ecttwprod2 --format="value(projectId,lifecycleState)"
gcloud services list --enabled --format="value(config.name)" | sort
gcloud billing projects describe ecttwprod2 --format="value(billingEnabled)"
```

**通過標準**：
- `projectId = ecttwprod2`、`lifecycleState = ACTIVE`
- 7 個 API 全部出現（`run`／`sqladmin`／`secretmanager`／`artifactregistry`／`cloudbuild`／`iam`／`cloudresourcemanager`）
- `billingEnabled = True`（若 False，回 §2 步驟 2 綁帳單）

---

## 4. 費用紅線（這段最重要）

| 動作 | 費用 | 何時做 |
|------|------|--------|
| 建專案、開 API、設區域、建服務帳號、建 Secret 空槽 | **0 元** | 現在就做 |
| Cloud SQL 最小執行個體 | 約 NT$ 2–4 千/月 | **M2 有真資料才建**，先 confirm |
| Cloud Run | 近乎免費額度 | M2 部署時 |
| Cloud Load Balancing + Armor | NT$ 數百～千/月 | 對外開放前 |
| Artifact Registry 映像 | 數十元/月 | CI 推映像時 |

> **M1 階段其實不需要真 GCP**：本機 `docker-compose` 有 PG、CI 有 postgres service，全部功能都能驗。
> 現在建專案只是「把地基與名字佔好」，**不必急著開資源燒錢**。

---

## 5. 待辦（建完專案後）

- [ ] **專案遷入公司 Organization**：目前掛在個人 Gmail 的「No organization」，日後選我科技若建 Cloud Identity／Workspace，再把專案轉入（GCP 支援專案轉移，需兩邊管理員權限）
- [ ] 另開 `gcloud config configurations create ect-tw`，避免誤在 `pickmyorder-prod` 上操作（本機 CLI 目前預設就是它）
- [ ] 藍新商店代號：ECT-TW **不可**沿用 PickMyOrder 的 `MS…`（條款第 17 條不得借讓），需另申請
- [ ] 服務帳號金鑰**不落地**：Cloud Run 用 Workload Identity／掛載 Secret，不產 JSON 金鑰檔
