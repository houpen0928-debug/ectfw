# apps/admin｜後台四端（M1 後段第一批：平台 HQ 骨架已落地）

## 已實作（v0.4.0-m1）

- 零構建靜態：`index.html` / `app.js` / `style.css`，外部載入、無 inline script／`innerHTML`／`eval`
- 登入：`X-Admin-Token`，金鑰**僅存 `sessionStorage`**（關掉分頁即失效），不寫 `localStorage`、不進 URL
- **法遵儀表置頂**：代收未付餘額（`payables_monitor`）／零殘值違規（`residual_monitor`）／點數守恆漂移（`points_conservation`）；非零值標紅
- 營運總覽 KPI、電子發票監控與「重試待補開立」（`POST /api/admin/invoices/retry`）、後台四端佔位
- `GET /api/admin/overview`：一次聚合四個監控視圖，`::int`／`::bigint` 明確轉型避免 PG BIGINT 字串污染；無 DB 回 503，不拖垮官網與核銷台
- 表格以 `createElement`＋`textContent` 建立；文案以 `data-copy` 靜態副本逐字對撞 `config/copy.js`（數量由 CI 動態統計，文件不寫死）
- 路由：`/admin`（無尾斜線 301 → `/admin/` 屬正常目錄正規化）；掛載由 **R18** 靜態規則把關

## 四端規劃

| 端 | 對象 | 核心 | 狀態 |
|----|------|------|------|
| 平台 HQ | 選我科技運營 | 廠商上架審核（信託憑證）／券檔審批／清算總覽／代收未付餘額監控／ESG 儀表盤／退券審核／公益撥付覆核 | ✅ 本批：總覽＋發票監控；其餘待建 |
| 廠商子後台 | 上架廠商 | 商品券檔／優惠期間設定／核銷記錄／T+1 對帳／信託專戶資訊維護 | ⏭️ M1 後段 |
| 企業採購戶 | 企業客戶 | 批量採購／員工分發／使用率匿名統計／三節預購 | ⏭️ M1 後段 |
| 公益對帳端 | 合作公益團體 | 受贈記錄／撥付進度／感謝回執上傳 | ⏭️ M1 後段 |

- M1 沿用 Node＋多頁靜態模式；模組變多後再評估 Vue3 重構
- 🔴 **平台 HQ 強制 TOTP 二階登入尚未實作**：目前為 `X-Admin-Token` 單因子，**正式對外開放前必須補**
- 「代收未付餘額」為法遵儀表，置頂顯示（已實作，非營運 KPI）
