'use strict';
// 後台骨架：零構建、外部載入、動態文字一律 textContent（無 innerHTML）。
// 金鑰只存 sessionStorage（關掉分頁即失效），不寫 localStorage、不進 URL。
(function () {
  const KEY = 'ECT_TW_ADMIN_TOKEN';
  const $ = (sel) => document.querySelector(sel);
  const fmt = new Intl.NumberFormat('zh-Hant-TW');
  let site = null;

  function getByPath(obj, dotted) {
    return dotted.split('.').reduce((v, k) => (v == null ? undefined : v[k]), obj);
  }
  const label = (path, fallback) => {
    const v = site ? getByPath(site.copy, path) : undefined;
    return typeof v === 'string' ? v : fallback;
  };
  const setText = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  const token = () => sessionStorage.getItem(KEY) || '';
  const setToken = (v) => { if (v) sessionStorage.setItem(KEY, v); else sessionStorage.removeItem(KEY); };
  const money = (cents) => `NT$ ${fmt.format(Math.round(Number(cents || 0) / 100))}`;

  async function applyCopy() {
    try {
      const r = await fetch('/api/public/site', { credentials: 'same-origin' });
      if (r.ok) site = await r.json();
    } catch (_) { /* 保留 HTML 靜態副本 */ }
    document.querySelectorAll('[data-copy]').forEach((el) => {
      const v = site ? getByPath(site.copy, el.dataset.copy) : undefined;
      if (typeof v === 'string') el.textContent = v;
    });
    setText('ver', site ? `v${site.version}` : '');
  }

  async function api(path, opts) {
    const o = opts || {};
    const headers = Object.assign({}, o.headers || {}, { 'X-Admin-Token': token() });
    if (o.body) headers['Content-Type'] = 'application/json';
    const r = await fetch(path, Object.assign({}, o, { headers, credentials: 'same-origin' }));
    let data = {};
    try { data = await r.json(); } catch (_) { /* 非 JSON 回應 */ }
    return { status: r.status, data };
  }

  function conn(text, cls) {
    const el = $('#conn');
    el.textContent = text;
    el.className = `pill ${cls || ''}`.trim();
  }

  function markAlert(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('bad', Number(value) !== 0);
  }

  function renderOverview(d) {
    const k = d.kpi || {};
    const c = d.compliance || {};
    const i = d.invoice || {};
    setText('k-tickets', fmt.format(Number(k.tickets) || 0));
    setText('k-unbound', fmt.format(Number(k.unbound) || 0));
    setText('k-vendors', fmt.format(Number(k.vendors) || 0));
    setText('k-products', fmt.format(Number(k.products) || 0));
    setText('k-ordersPaid', fmt.format(Number(k.ordersPaid) || 0));
    setText('k-verifyOps', fmt.format(Number(k.verifyOps) || 0));
    setText('c-payable', money(c.payableCents));
    setText('c-zeroResidual', fmt.format(Number(c.zeroResidualViolations) || 0));
    setText('c-drift', fmt.format(Number(c.pointsDriftCents) || 0));
    setText('i-pending', fmt.format(Number(i.pending) || 0));
    setText('i-failed', fmt.format(Number(i.failed) || 0));
    markAlert('c-zeroResidual', c.zeroResidualViolations);
    markAlert('c-drift', c.pointsDriftCents);
    markAlert('i-failed', i.failed);
  }

  function renderInvoices(d) {
    const body = $('#invBody');
    body.textContent = '';
    const rows = Array.isArray(d.invoices) ? d.invoices.slice(0, 20) : [];
    $('#emptyHint').hidden = rows.length > 0;
    for (const row of rows) {
      const tr = document.createElement('tr');
      const cells = [
        String(row.created_at || '').slice(0, 19).replace('T', ' '),
        String(row.order_no || row.invoice_no || '—'),
        String(row.status || '—'),
        money(row.amount_cents),
        String(row.issue_point || '—'),
      ];
      for (const v of cells) {
        const td = document.createElement('td');
        td.textContent = v;
        tr.appendChild(td);
      }
      body.appendChild(tr);
    }
  }

  function showDash(on) {
    $('#loginCard').hidden = on;
    $('#dash').hidden = !on;
  }

  async function load() {
    conn(label('admin.status.loading', '讀取中'));
    const [ov, inv] = await Promise.all([
      api('/api/admin/overview'),
      api('/api/admin/invoices'),
    ]);
    if (ov.status === 401) {
      setToken('');
      showDash(false);
      conn(label('admin.status.unauthorized', '金鑰無效'), 'bad');
      setText('loginMsg', label('admin.status.unauthorized', '金鑰無效'));
      return;
    }
    if (ov.status !== 200 || !ov.data.ok) {
      showDash(true);
      conn(label('admin.status.dbUnavailable', '資料庫不可用'), 'bad');
      $('#dbHint').hidden = false;
      return;
    }
    $('#dbHint').hidden = true;
    showDash(true);
    conn(label('admin.status.ok', '已連線'), 'ok');
    setText('who', ov.data.generatedAt ? `更新於 ${String(ov.data.generatedAt).slice(0, 19).replace('T', ' ')}` : '');
    renderOverview(ov.data);
    if (inv.data && inv.data.ok) renderInvoices(inv.data);
  }

  async function login() {
    const v = $('#token').value.trim();
    if (!v) { setText('loginMsg', label('admin.status.unauthorized', '金鑰無效')); return; }
    setToken(v);
    setText('loginMsg', '');
    await load();
  }

  async function retry() {
    const r = await api('/api/admin/invoices/retry', {
      method: 'POST', body: JSON.stringify({ limit: 20 }),
    });
    setText('retryMsg', r.data && r.data.ok ? `${(r.data.results || []).length} 筆已處理` : '處理失敗');
    await load();
  }

  applyCopy().then(() => {
    $('#btnLogin').addEventListener('click', login);
    $('#token').addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
    $('#btnLogout').addEventListener('click', () => {
      setToken('');
      showDash(false);
      conn(label('admin.status.loggedOut', '未登入'));
    });
    $('#btnRetry').addEventListener('click', retry);
    if (token()) load();
  });
})();
