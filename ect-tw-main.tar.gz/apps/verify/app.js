'use strict';
// ECT-TW 門市核銷台（零依賴；所有動態文字以 textContent 寫入，防 XSS）
const $ = (id) => document.getElementById(id);
const S = {
  key: sessionStorage.getItem('ectVerifyKey') || '',
  staff: sessionStorage.getItem('ectVerifyStaff') || 'staff',
  cfg: null,
  ticket: null,
};

const STATE_LABEL = {
  UNBOUND: '未歸戶',
  BOUND: '已歸戶',
  USED: '已全額兌換',
  GRACE: '優惠期間結束（價值完整保留）',
  CONVERTED: '已轉為點數',
  CHARITY: '已轉贈公益',
};

function money(cents) {
  const v = Number(cents || 0);
  return 'NT$ ' + (v / 100).toLocaleString('zh-TW', {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  });
}

function setResult(ok, text) {
  const el = $('result');
  el.hidden = false;
  el.className = 'result ' + (ok ? 'ok' : 'bad');
  el.textContent = text;
}

function reqHeaders() {
  return {
    'content-type': 'application/json',
    'X-Verify-Key': S.key,
    'X-Verify-Staff': S.staff,
  };
}

async function api(path, opts = {}) {
  try {
    const r = await fetch(path, { ...opts, headers: { ...reqHeaders(), ...(opts.headers || {}) } });
    const data = await r.json().catch(() => ({ ok: false, error: 'BAD_JSON', message: '回應格式錯誤' }));
    return { status: r.status, data };
  } catch (err) {
    return { status: 0, data: { ok: false, error: 'NETWORK', message: err.message } };
  }
}

function fail(data) {
  setResult(false, `✗ ${data.error || 'FAILED'}${data.message ? ' — ' + data.message : ''}`);
}

function cell(tr, text) {
  const td = document.createElement('td');
  td.textContent = text == null ? '' : String(text);
  tr.appendChild(td);
}

function renderJournal(rows) {
  const body = $('journalBody');
  body.textContent = '';
  if (!rows || !rows.length) {
    const tr = document.createElement('tr');
    cell(tr, '—'); cell(tr, '尚無操作紀錄'); cell(tr, ''); cell(tr, '');
    body.appendChild(tr);
    return;
  }
  for (const r of rows) {
    const tr = document.createElement('tr');
    cell(tr, r.created_at ? new Date(r.created_at).toLocaleString('zh-TW') : '—');
    cell(tr, r.action);
    cell(tr, r.actor);
    cell(tr, r.payload ? JSON.stringify(r.payload).slice(0, 120) : '');
    body.appendChild(tr);
  }
}

function renderInvoice(inv) {
  const box = $('invoiceBox');
  if (!inv) {
    box.textContent = '尚無發票紀錄（依系統設定之開立時點產生）';
    box.className = 'invoice';
    return;
  }
  const map = { PENDING: '開立處理中', ISSUED: '已開立', FAILED: '待補開立' };
  box.className = 'invoice ' + (inv.status === 'ISSUED' ? 'ok' : inv.status === 'FAILED' ? 'bad' : '');
  box.textContent = `發票 ${map[inv.status] || inv.status}` +
    `｜金額 ${money(inv.amount_cents)}` +
    (inv.invoice_no ? `｜號碼 ${inv.invoice_no}` : '') +
    (inv.donate_code ? `｜捐贈碼 ${inv.donate_code}` : '') +
    (inv.last_error ? `｜${inv.last_error}` : '');
}

function renderTicket(tk, inv) {
  S.ticket = tk;
  $('ticketCard').hidden = false;
  $('actionCard').hidden = false;
  $('extraCard').hidden = false;

  $('tkState').textContent = STATE_LABEL[tk.state] || tk.state;
  $('tkState').className = 'state s-' + tk.state;
  $('tkProduct').textContent = tk.product_name || '';
  $('tkFace').textContent = money(tk.face_value_cents);
  $('tkFloor').textContent = money(tk.floor_value_cents);
  $('tkResidual').textContent = money(tk.residual_cents);
  $('tkIssue').textContent = tk.issue_no || '—';
  $('tkSale').textContent = tk.sale_date ? String(tk.sale_date).slice(0, 10) : '—';
  $('tkId').textContent = '#' + tk.id;
  $('tkOwner').textContent = tk.owner_user_id ? `已歸戶 #${tk.owner_user_id}` : '尚未歸戶';

  const live = ['BOUND', 'GRACE'].includes(tk.state) && Number(tk.residual_cents) > 0;
  $('btnRedeem').disabled = !live;
  $('btnGrace').disabled = !['UNBOUND', 'BOUND'].includes(tk.state);
  $('btnConvert').disabled = !live || tk.owner_user_id == null;
  $('btnDonate').disabled = !live;
  $('actHint').textContent = live
    ? '可核銷；核銷後剩餘價值完整保留，可繼續兌換、轉點數或轉公益。'
    : '此狀態無可執行之核銷動作；價值仍完整保留。';
  renderInvoice(inv);
}

async function loadConfig() {
  const { data } = await api('/api/verify/config');
  if (!data || !data.title) {
    $('conn').textContent = '設定讀取失敗';
    $('conn').className = 'pill bad';
    return;
  }
  S.cfg = data;
  $('entity').textContent = data.entity || '';
  $('conn').textContent = `就緒 · 開立點 ${data.issuePoint} · ${data.provider}`;
  $('conn').className = 'pill ok';
  $('cfgNote').textContent = data.copy.invoiceNote || '';
  $('legalNote').textContent = data.copy.alwaysValid || '';
  $('ver').textContent = 'v' + data.version;
}

async function loadPartners() {
  const { data } = await api('/api/verify/partners');
  const sel = $('partner');
  const keep = sel.value;
  sel.textContent = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = '選擇公益團體';
  sel.appendChild(empty);
  if (data && data.ok) {
    for (const p of data.partners) {
      const o = document.createElement('option');
      o.value = String(p.id);
      o.textContent = p.name + (p.donate_code ? `（${p.donate_code}）` : '');
      sel.appendChild(o);
    }
  }
  sel.value = keep;
}

async function loadJournal(ticketId) {
  const { data } = await api('/api/verify/journal/' + encodeURIComponent(ticketId));
  renderJournal(data && data.ok ? data.journal : []);
}

async function loadInvoice(ticketId) {
  const { data } = await api('/api/verify/invoice/' + encodeURIComponent(ticketId));
  renderInvoice(data && data.ok ? data.invoice : null);
}

async function lookup() {
  const code = $('code').value.trim();
  if (!code) return setResult(false, '請輸入票券代碼');
  if (!S.key) return setResult(false, '請先輸入並儲存核銷金鑰');
  const { data } = await api('/api/verify/lookup', {
    method: 'POST', body: JSON.stringify({ code }),
  });
  if (!data.ok) {
    $('ticketCard').hidden = true;
    $('actionCard').hidden = true;
    $('extraCard').hidden = true;
    S.ticket = null;
    return fail(data);
  }
  renderTicket(data.ticket, data.invoice);
  setResult(true, `✓ 已查得票券 #${data.ticket.id}`);
  await Promise.all([loadJournal(data.ticket.id), loadPartners()]);
  return undefined;
}

function invoiceFields() {
  return {
    carrierId: $('carrier').value.trim() || undefined,
    donateCode: $('donateCode').value.trim() || undefined,
    buyerUnifiedNo: $('buyerUbn').value.trim() || undefined,
  };
}

async function doAction(path, label, extra = {}) {
  if (!S.ticket) return setResult(false, '請先查詢票券');
  const body = { code: $('code').value.trim(), ...extra };
  const { data } = await api('/api/verify/' + path, {
    method: 'POST', body: JSON.stringify(body),
  });
  if (!data.ok) return fail(data);
  setResult(true, `✓ ${label}完成｜狀態 ${STATE_LABEL[data.state] || data.state || '—'}` +
    (data.residualCents != null ? `｜剩餘 ${money(data.residualCents)}` : ''));
  $('amountYuan').value = '';
  await lookup();
  if (S.ticket) await loadInvoice(S.ticket.id);
  return undefined;
}

$('btnSave').addEventListener('click', () => {
  S.key = $('key').value.trim();
  S.staff = $('staff').value.trim() || 'staff';
  sessionStorage.setItem('ectVerifyKey', S.key);
  sessionStorage.setItem('ectVerifyStaff', S.staff);
  setResult(true, '✓ 門市設定已儲存（僅存於本瀏覽器工作階段）');
});

$('btnLookup').addEventListener('click', lookup);
$('code').addEventListener('keydown', (e) => { if (e.key === 'Enter') lookup(); });

$('btnRedeem').addEventListener('click', () => {
  const raw = $('amountYuan').value.trim();
  const extra = invoiceFields();
  if (raw !== '') {
    const n = Number(raw);
    if (!Number.isFinite(n) || n <= 0 || !Number.isInteger(n)) {
      return setResult(false, '金額請輸入正整數（元）；電子發票以元為最小單位');
    }
    extra.amountCents = n * 100;
  }
  return doAction('redeem', '核銷', extra);
});

$('btnGrace').addEventListener('click', () => doAction('grace', '優惠期間結束'));
$('btnConvert').addEventListener('click', () => doAction('convert', '轉為點數'));
$('btnDonate').addEventListener('click', () => {
  const pid = Number($('partner').value || 0);
  if (!pid) return setResult(false, '請先選擇合作公益團體');
  return doAction('donate', '轉贈公益', { partnerId: pid });
});

$('key').value = S.key;
$('staff').value = S.staff;
loadConfig();
