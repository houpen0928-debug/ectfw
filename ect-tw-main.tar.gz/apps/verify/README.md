# apps/verify｜核銷工具（M1 已落地 → M3）

| 形態 | 時點 | 狀態 | 說明 |
|------|------|------|------|
| 網頁核銷台 | M1 | ✅ 已落地 | 零構建靜態頁（外部 JS/CSS、helmet CSP 相容、`textContent` 防 XSS）；手輸／掃碼券碼 → 查券 → 五個動作 |
| 核銷 App | M2 | ⏭️ | uniapp 廠商模式：批量掃碼、離線佇列（連線後批次驗證）、班次日報 |
| 硬體整合 | M3 | ⏭️ | USB／藍牙掃碼槍、小票機 |

## 使用（本機）

1. `.env` 設 `ECT_VERIFY_KEY`（高熵隨機字串）與 `ECT_VERIFY_VENDOR_ID`（此核銷台綁定的發行人 ID）。
2. 起服務後開 `http://127.0.0.1:8080/verify/`（**尾斜線**；`/verify` 會 301 正規化，屬正常）。
3. 頁面「門市設定」填入同一把 `ECT_VERIFY_KEY` 與人員代號 → 存於 `sessionStorage`，不落地、不進 log。
4. 輸入券碼查詢，再依狀態執行動作。

🔴 未設 `ECT_VERIFY_KEY`／`ECT_VERIFY_VENDOR_ID` 時，`/api/verify/*` 一律 **503**（fail-closed）。

## API（除 config 外皆需 `X-Verify-Key`，可另帶 `X-Verify-Staff`）

| 端點 | 動作 |
|---|---|
| `GET /api/verify/config` | 公開；文案、狀態／動作枚舉、開立點、provider（不含任何憑證） |
| `POST /api/verify/lookup` | 唯讀查券（不上寫鎖）＋該券最新發票 |
| `POST /api/verify/redeem` | 核銷；可帶 `amountCents`（分，須整元才可開發票），不帶則用完整剩餘價值 |
| `POST /api/verify/grace` | 優惠期間結束，**價值一分不減** |
| `POST /api/verify/convert` | 剩餘價值轉點數（只轉給券的 owner，不接受客戶端指定 userId） |
| `POST /api/verify/donate` | 剩餘價值轉公益（需已登錄 `charity_partners`） |
| `GET /api/verify/journal/:ticketId`／`/invoice/:ticketId`／`/partners` | 操作軌跡／發票／合作團體 |
| `GET /api/admin/invoices`／`POST /api/admin/invoices/retry` | 管理端發票監控與補開（改用 `X-Admin-Token`） |

## 法遵與安全

- 無「到期」語義；`GRACE` 只代表優惠期間結束，價值完整保留（`ticket_chain`／`verify_operations` 留痕）。
- 部分核銷後 `residual_cents` 完整保留，可繼續兌換、轉點數或轉公益；**不是一次性作廢**。
- 發行人隔離：`findTicketByCode` 比對 `vendor_id`，A 廠商的核銷台查不到／核不了 B 廠商的券。
- 寫動作以 `FOR UPDATE OF t` 取鎖防 TOCTOU；唯讀 lookup 不上寫鎖。拒絕也留 `verify_operations`（result=REJECTED），該表為 append-only。
- 發票開立時點由 `ECT_INVOICE_ISSUE_POINT` 決定（**待律師意見書 C2**）；發票失敗以 SAVEPOINT 隔離，不回滾核銷，失敗記 `invoice_outbox` 待補開。
- 防偽：券碼以 sha256 存庫（`code_hash`），明文僅於發券當下回傳一次；前端不保存券碼。
