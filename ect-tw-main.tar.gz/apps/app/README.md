# apps/app｜iOS / Android App（M2）

- 技術棧：**uniapp（Vue3）**一套套雙端，順帶 H5
- 登入：LINE Login＋Apple Sign-In（App Store 4.8）＋手機 OTP 兜底
- 頁面：券夾／券詳情（6 項應記載事項＋優惠期間＋信託標示）／券廣場購買／點數（流水・兌券・轉公益）／退券退款／個資行使
- 推播：FCM＋APNs（交易提醒）；LINE Messaging API（營運訊息）
- 點數**不可購買、不可換現**；對外口徑為「點數／權益／兌換」，避免電支認定
- 上架：Apple Developer（USD 99/年）、Google Play（USD 25 一次性）
