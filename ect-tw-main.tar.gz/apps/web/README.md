# apps/web｜官網首頁（最新版：academia 優化版，2026-11-21）

> 洪哥指定以 Codex 交付的 `ECT-TW-home-academia.zip` 為**最新版**，取代 2026-11-20 的 A2 六區落實版。
> 來源：`C:\Users\A\Documents\Codex\2026-11-20\new-chat-2\outputs\ECT-TW-home-academia.zip`（原交付為本機改版，尚未提交 GitHub／部署；本批完成整合、驗證與推送）。

## 這版新增／改了什麼

| 項目 | 內容 | 錨點 |
|---|---|---|
| 雙欄首屏 | 左文案＋右服務概念券卡，主標走 `web.heroTitleV2` | `#top` |
| 三步驟流程 | 企業送禮 → 員工選用 → 自主轉贈 | `#how` |
| 產學合作專區 | `web.academiaV1.*` 13 個文案鍵，獨立成區 | `#academia` |
| 企業諮詢表單 | 原生驗證 → **只開郵件草稿**，由訪客確認後自行寄出 | `#consult` |
| 電話／郵件入口 | 頁尾與服務區並列，走 `entity.*` 文案鍵 | `#service` |
| 無障礙 | 跳至主要內容、鍵盤焦點樣式、`prefers-reduced-motion` | 全頁 |
| 樣式 | 全新設計令牌與 RWD，無外部字體／圖片（完全離線可用） | `style.css` |

## 沿用不改（法遵底線，本批逐一覆核）

- **A2 六區架構**：品牌主張／逛禮券／公益實時／法遵與權益／雙公益通道／角色捷徑
- **頁尾法遵門面**：`data-copy="entity.*"` 顯示公司名稱、統一編號 **62023886**、代表人洪承洋、登記地址、客服專線與信箱；`buildSiteConfig()` 的 `entity` 分組可被 `/api/public/site` 覆寫
- 🔴 **平台非發行人**：`web.issuerNote` 明定發行人為各檔券所載廠商，全量揭露於逐檔券公開頁；平台不當發行人、不代收券貨款
- 法遵三保證、六項應記載、履約保障、退券程序、FAQ（原生 `<details>` 零 JS）
- ESG 數字條接 `GET /api/public/esg`；**讀取失敗保留「—」，不以估算值替代**
- 券廣場公開批次 API 未上線，`#market` 誠實標「建置中」，不做空殼分類

## V2 文案鍵（新增 19 個，舊鍵全數保留）

`web.taglineV2` / `web.heroTitleV2` / `web.heroSubV2` / `web.ctaPrimaryV2` / `web.ctaSecondaryV2` / `web.fourGoodV2`（4 筆）／`web.academiaV1.*`（13 筆）。

`src/routes/public.js` 的 `buildSiteConfig()` 以整包 `web: copy.web` 輸出，新鍵**自動帶上**，不需改後端。前端 `data-copy` 遇 API 缺鍵或非字串值時，保留已對撞過的 HTML 靜態副本（優雅降級）。

## 企業諮詢（不落地任何資料）

- 表單用原生 `reportValidity()`；送出後只導向 `mailto:`，**沒有新增收件 API、沒有網站資料儲存**
- 收件信箱由頁尾 `[data-copy="entity.serviceEmail"]` 讀取（並由 `/api/public/site` 覆寫），與 `config/copy.js` **自動對撞**，避免寫死造成漂移
- 狀態列明確告知「已嘗試開啟郵件軟體，請確認並寄出」，不宣稱已收到諮詢

## 驗證（本批補上原交付未做的部分）

原交付已驗：JS 語法、頁內錨點、重複 ID、section 配對、文案對應。
本批另驗：全站 **178 處** `data-copy` 兩種獨立抓法逐字對撞 0 mismatch（官網 142／後台 36）、27 檔語法 0 錯、禁詞 0、compose **18/18**、**68 支**測試 0 fail、本機起服務 `/` 200（19,992 bytes）與區網入口 200、`/api/public/site` 回傳 V2 鍵與完整 entity、`/admin/`／`/verify/` 未受影響、CI 冒煙所用法遵關鍵字全數仍在頁上。

## 臺灣用語（CI 自動把關）

對外用語一律走 `config/copy.js`；`scripts/check-banned-words.js` 除法規明文禁用語外，另把大陸版語彙加入自動掃描。

⚠️ **本檔位於 `apps/`，會被掃描，故不逐字列出禁用語**；完整用語對照表與詞表集中在根目錄 `README.md` 的「臺灣用語對照」一節（根目錄不在掃描範圍，可供人工審查）。
🔴 `核銷` 刻意不列為禁用語：門市核銷台是內部工具、用語合法，僅**對客**文案禁用（由 `data-copy` 統一控管）。

## 待辦（誠實邊界）

- 🔴 券廣場公開批次 API 與逐檔券公開頁尚未上線（首頁已標「建置中」）
- 企業諮詢目前為 mailto；若日後要留下諮詢紀錄，需另設計收件 API 與個資告知
- 逐檔券公開頁：須全量揭露 6 項應記載事項＋履約保障＋退券程序
- 🔴 客服申訴專線**暫用公司電話 02-28097206**；若另設專線，改 `.env` 的 `ECT_ENTITY_SERVICE_PHONE` 即可
- 隱私權政策＋Cookie 同意橫幅（個資法，§2.7／§4.1）、網域綁定、TOTP 二階登入

> 法遵文案一律取自 `config/copy.js`，不得自行撰寫；CI 掃描法規禁用語與大陸版語彙，並以 `data-copy` 對撞防漂移。
