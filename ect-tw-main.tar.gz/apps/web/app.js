'use strict';
// 官網首頁：零構建、外部載入、全部文字走 textContent（helmet CSP 相容）。
// data-copy 元素以 /api/public/site 為權威覆寫；HTML 內的靜態副本由
// tests/site.test.js 與 config/copy.js 自動對撞，兩邊不許漂移。
(function () {
  const $ = (sel) => document.querySelector(sel);
  const fmt = new Intl.NumberFormat('zh-Hant-TW');
  // API base 可切換（C.15 架構A）：靜態首頁在 Pages、API 在 api.twect.com.tw；
  // 讀不到 meta（本機/舊版）時退回相對路徑 = 同源行為不變。
  const API = (document.querySelector('meta[name="ect-api-base"]') || { content: '' }).content || '';

  function getByPath(obj, dotted) {
    return dotted.split('.').reduce((v, k) => (v == null ? undefined : v[k]), obj);
  }

  async function applyCopy() {
    let site = null;
    try {
      const r = await fetch(API + '/api/public/site', { credentials: 'same-origin' });
      if (r.ok) site = await r.json();
    } catch (_) { /* 保留 HTML 靜態副本 */ }

    document.querySelectorAll('[data-copy]').forEach((el) => {
      const value = site ? getByPath(site.copy, el.dataset.copy) : undefined;
      if (typeof value === 'string') el.textContent = value;
      // 非字串（陣列／物件）或 API 不可用時，保留已對撞過的靜態副本
    });

    $('#ver').textContent = site ? `v${site.version}` : '';
    // #esgSource 專供公益數字來源標示；主體資料改由頁尾 data-copy 呈現，不再混用
    return site;
  }

  async function loadEsg() {
    try {
      const r = await fetch(API + '/api/public/esg', { credentials: 'same-origin' });
      if (!r.ok) throw new Error('esg unavailable');
      const d = await r.json();
      $('#esgCharityTotal').textContent = `NT$ ${fmt.format(Number(d.charityTotal) || 0)}`;
      $('#esgCharityCount').textContent = fmt.format(Number(d.charityCount) || 0);
      $('#esgZeroWaste').textContent = `${(Number(d.zeroWasteRate) || 0).toFixed(2)}%`;
      $('#esgProjects').textContent = fmt.format(Number(d.projects) || 0);
      if (d.meta && d.meta.source === 'ledger') {
        $('#esgSource').textContent = `${d.meta.liveLabel || ''}｜來源：平台帳本`.replace(/^｜/, '');
      }
    } catch (_) {
      // 依 copy.web.esgNote：讀取失敗保留「—」，不以估算值替代
    }
  }

  applyCopy().then(loadEsg);
})();


// 使用原生驗證；僅建立郵件草稿，網站不宣稱已收到諮詢。
(function () {
  const form = document.querySelector('#consultForm');
  if (!form) return;
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const values = new FormData(form);
    const body = ['公司／組織：' + values.get('company'), '聯絡人：' + values.get('contact'), '聯絡信箱：' + values.get('email'), '需求類型：' + values.get('need'), '', '需求說明：', values.get('message') || '尚未填寫'].join('\r\n');
    const subject = '臺灣益卡通企業諮詢｜' + values.get('need');
    // 信箱取自頁尾已對撞的 data-copy 元素（並由 /api/public/site 覆寫），避免與 entity.serviceEmail 漂移
    const emailEl = document.querySelector('[data-copy="entity.serviceEmail"]');
    const email = (emailEl && emailEl.textContent.trim()) || 'jasonhung@pickmyplus.com';
    window.location.href = 'mailto:' + email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
    document.querySelector('#consultStatus').textContent = '已嘗試開啟郵件軟體，請確認並寄出。若未開啟，請使用下方信箱或電話聯絡。';
  });
})();
