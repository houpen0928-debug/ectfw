'use strict';
// LIFF 前端骨架（批次②）：零構建、外部載入、動態文字一律 textContent。
// 🔴 未設定 LIFF ID 時「完全不動作」：不載 SDK、不送出請求、不顯示可操作入口。
// 首頁「透過 LINE 使用」專區的建置中標記與文案均未變動，本頁沒有任何對外入口連結。
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var statusEl = $('#status');
  var gate = $('#gate');
  var wallet = $('#wallet');
  var scanBtn = $('#scanBtn');
  var scanNote = $('#scanNote');
  var SDK = 'https://static.line-scdn.net/liff/edge/2/sdk.js';

  function setStatus(t) { if (statusEl) statusEl.textContent = t; }
  function showGate(msg) {
    setStatus(msg);
    if (gate) gate.hidden = false;
    if (wallet) wallet.hidden = true;
  }
  function showWallet(msg) {
    setStatus(msg);
    if (gate) gate.hidden = true;
    if (wallet) wallet.hidden = false;
  }
  function meta(name) {
    var el = document.querySelector('meta[name="' + name + '"]');
    return el ? String(el.content || '').trim() : '';
  }

  var liffId = meta('ect-liff-id');
  var API = meta('ect-api-base');

  if (!liffId) {
    showGate('尚未設定 LIFF ID：本頁維持建置中降級，不載入 SDK、不送出任何請求。');
    return;
  }

  function loadSdk() {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = SDK;
      s.async = true;
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('sdk_load_failed')); };
      document.head.appendChild(s);
    });
  }

  function postSession(idToken) {
    return fetch(API + '/api/auth/line/session', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken: idToken })
    }).then(function (r) {
      if (!r.ok) throw new Error('session_failed');
      return r.json();
    });
  }

  // scanCode 僅 LINE App 內可用；其餘環境一律降級為「改用輸入券碼」。
  function bindScan() {
    if (!scanBtn) return;
    scanBtn.addEventListener('click', function () {
      var l = window.liff;
      var inClient = l && typeof l.isInClient === 'function' && l.isInClient();
      if (inClient && typeof l.scanCode === 'function') {
        l.scanCode().then(function (v) {
          if (scanNote) scanNote.textContent = '已讀取：' + String((v && v.value) || '');
        }).catch(function () {
          if (scanNote) scanNote.textContent = '掃碼未成功，請重試或改用輸入券碼。';
        });
      } else if (scanNote) {
        scanNote.textContent = '目前環境不支援掃碼，請在 LINE 中開啟或改用輸入券碼。';
      }
    });
  }

  setStatus('入口載入中…');
  loadSdk().then(function () {
    var l = window.liff;
    if (!l || typeof l.init !== 'function') throw new Error('sdk_unavailable');
    return l.init({ liffId: liffId }).then(function () {
      if (!l.isInClient()) {
        showGate('目前為外部瀏覽器，部分功能不可用；請在 LINE 中開啟，或使用網頁登入。');
        var a = document.createElement('a');
        a.className = 'btn';
        a.href = API + '/api/auth/line/start';
        a.textContent = '使用網頁登入';
        if (gate) gate.appendChild(a);
        return null;
      }
      if (!l.isLoggedIn()) { l.login(); return null; }
      var idToken = l.getIDToken();
      if (!idToken) throw new Error('no_id_token');
      return postSession(idToken);
    });
  }).then(function (data) {
    if (!data) return;
    showWallet('身份已驗證。功能按鈕於逐項放行後才會啟用。');
    bindScan();
  }).catch(function () {
    showGate('入口載入失敗，已回到建置中說明；請稍後再試或回到官網。');
  });
})();
