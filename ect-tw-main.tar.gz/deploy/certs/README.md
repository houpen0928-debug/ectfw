# deploy/certs/ — Cloudflare Origin CA 憑證放置區

本目錄**不入庫憑證本體**（根 `.gitignore` 已排除 `*.pem` / `*.key` / `*.p12`）。

上線前在 Cloudflare → SSL/TLS → Origin Server → Create Certificate 產生後放：

```
deploy/certs/origin.pem          # Origin Certificate
deploy/certs/origin.key          # Private Key
deploy/certs/origin-pull-ca.pem  # 選用：Authenticated Origin Pulls 的 CA（mTLS）
```

權限：`chmod 600 deploy/certs/origin.key`（VM 上）；nginx 容器以只讀掛載 `/etc/nginx/certs`。

⚠️ 這張憑證**只信任 Cloudflare**，瀏覽器直連 VM 公網 IP 會顯示不受信任——這是刻意設計（強制流量走 Cloudflare，隱藏真實 IP）。
