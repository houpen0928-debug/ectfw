# ECT-TW｜臺灣益卡通

**選我科技有限公司**｜保底流通券平台（臺灣）｜與大陸版 ecatong.com 並行的獨立系統。

> 法遵第一：**券長期有效、價值完整保留，殘值不歸零**。全站文案由 `config/copy.js` 統一管理，CI 自動掃描法規禁用語與大陸版語彙。
> 金流：**藍新 NewebPay 為主**（綠界保留為備選不刪）｜雲端：**GCP asia-east1 彰化**｜早期架設：**單台 e2-micro VM，月費 ≤ NT$380**（`docs/單VM上線SOP_v1.md`）。

## 現況（2026-11-25）

| 項目 | 狀態 |
|------|------|
| 平台主體 | ✅ 選我科技有限公司（台灣），統編／地址／代表人已回填 |
| 對外品牌 | ✅ **`TWECT`**（2026-11-25 老師建議「具 TWNCC 般正式層級語感」＋洪哥拍板；中文並用「益卡通／臺灣益卡通」）｜詳規格書 C.11 |
| 對外域名 | ✅ **`twect.com.tw`＋`益卡通.台灣`**（2026-11-25 送件受理＋**同日 TWNIC 文件審核通過、註冊程序完成**，案號 `20261125000422`，匯智資訊(Cloudmax)；✅ **NS 已切 Cloudflare（`byron`／`tani`）、zone 已激活、全球 NS 传播驗證通過**（11-25 17:38）；`益卡通.台灣` 留匯智做 301；11-24 暫定 `ect.tw` 已作廢）｜決策與商標風險詳規格書 C.11、律師清單 E 節；🔴 **網站未上線**：無 VM／A 記錄／SSL，`https://twect.com.tw` 不可訪問，藍新商店設定與 LIFF callback 繼續凍結 |
| 法遵意見書 | ✅ 律師已發包；清單 `docs/律師法遵確認清單_v1.md`（D 節：藍新代收代付紅線） |
| 新倉庫 | ✅ `houpen0928-debug/ect-tw`（私有，CI success） |
| 金流 / 雲端 | ✅ 藍新 NewebPay（主）／GCP 台灣 asia-east1；🟡 **GCP 專案 `ecttwprod` 已建立（2026-11-25，免費）**；🔴 **卡帳單**：帳戶 `0160C9-C215C6-E9FA8C` 逾期（Mastercard ••••8810 遭拒、欠款 $5,146）→ 建 VM 前須洪哥修付款；本機 Google 域通道不通，GCP 操作走 Console／Cloud Shell（詳 `docs/GCP專案建立操作清單_v1.md` 執行記錄） |
| 早期架設成本 | ✅ 單 VM ≈ NT$292/月（上限 380）；Cloud Run＋Cloud SQL 列為 M2 升級路徑 |
| M1 第一批 | ✅ **券引擎＋PG migration＋藍新 callback** |
| M1 生產可版 | ✅ **compose 生產可版＋nginx/TLS＋備份還原＋CI 紀律檢查** |
| M1 第二批 | ✅ **電子發票（可插拔）＋網頁核銷台＋004 migration＋發票/核銷軌跡** |
| M1 第二批加固 | ✅ **SAVEPOINT 交易隔離＋核銷台進 image（R17 靜態規則）** |
| M1 後段第一批 | ✅ **官網首頁＋後台骨架（法遵儀表置頂）＋公開文案端點＋文案/版本自動對撞（R18）** |
| M1 後段第二批 | ✅ **首頁落實（A2 六區）＋選我科技真實登記資料回填＋臺灣用語禁詞掃描** |
| M1 後段第三批 | ✅ **首頁最新版（academia 優化版）＋19 個 V2 文案鍵＋企業諮詢 mailto＋本機視覺驗證** |
| M1 後段待建 | ⏭️ 後台其餘三端／券廣場公開批次 API／App 雙端／律師意見書回填／TOTP 二階登入 |

## 快速開始（本機一鍵起全套，NT$ 0）

```bash
cp .env.example .env          # 填入藍新測試憑證、ECT_PG_PASSWORD、ECT_ADMIN_TOKEN
npm install
npm run verify                # 語法 + 法遵禁詞 + compose 紀律 + 76 支測試（69 pass / 7 CI-only skip）
npm run compose -- --selftest # 檢查器反向自測（確認規則真的會咬人）
# 本機免 DB 看頁面：ECT_ADMIN_TOKEN=xxx node src/server.js → / 官網、/admin/ 後台、/verify/ 核銷台
docker compose up -d --build  # postgres + app + nginx；app 啟動自動跑 db:migrate
curl http://127.0.0.1:8080/health
npm run db:backup             # 手動備份（上線由 cron 每日 03:17）
```

- 本機預設 `8080/8443`（避開 Windows 常被佔用的 80/443）；Postgres 只綁 `127.0.0.1:5433`。
- **上線**：`.env` 切 `NGINX_CONF=ssl`／`ECT_EDGE_PORT=80`／`ECT_TLS_PORT=443`，並放 Cloudflare Origin CA 憑證。
- 🔴 **動 GCP 資源（會計費）前一律先跟洪哥 confirm**；本倉庫目前**未建任何雲端資源、未產生費用**。

CI（`.github/workflows/ci.yml`）起 **postgres service** 跑真 DB：migration 冪等驗證＋端到端整合測試（含 004 欄位／發票入隊斷言）＋兩個檢查器反向自測＋health／官網／首頁法遵門面／後台總覽／核銷台／回呼 fail-closed 冒煙。

## 目錄

```
db/migrations/001_baseline.sql          v0.1 DDL（無 EXPIRED 終態、點數無 CASHOUT、append-only journal）
db/migrations/002_m1_ticket_engine.sql  M1：orders/newebpay_txn/payment_events/券價值快照/對帳視圖
db/migrations/003_fix_ticket_columns.sql  補 tickets.converted_at（不改已發布 002）
db/migrations/004_m1_invoice_verify.sql   M1 第二批：發票欄位/outbox/核銷軌跡/監控視圖
db/migrations/005_m2_transfer_dynamic.sql M2 批次A：轉移 token（單次/24h）＋ tickets.code_seq（舊碼作廢）
db/migrate.js                           版本化 runner（schema_migrations + checksum）
db/index.js                             pg Pool，參數綁定 + withTransaction
config/copy.js                          對外文案唯一來源（法遵）；entity 為平台主體真實登記資料
scripts/check-*                         語法／禁詞（含臺灣用語）／compose 紀律檢查（皆含反向自測）
scripts/backup.sh / restore.sh           pg_dump 每日備份（不額外跑容器）／需 YES 二次確認的還原
scripts/crontab.example                  VM 宿主每日備份 + 每週異地抓取
scripts/gcp-bootstrap.sh                冪等建專案（不代綁帳單、不建付費資源）
deploy/nginx/http.conf                  本機 / POC（純 HTTP）
deploy/nginx/ssl.conf                   上線（Cloudflare Origin CA，含 mTLS 註解）
docker-compose.yml / .dockerignore      生產可版（本機與上線同一份）
src/payments/newebpay.js                藍新：AES-256-CBC/TradeSha/MPG 表單/回呼解析（主力）
src/payments/ecpay.js                   綠界驗簽（備選保留，不刪）
src/payments/ezpay.js                   電子發票閘道：stub/http/ezpay 三通道、稅額拆分、fail-closed
src/engine/tickets.js                   券引擎：純函式狀態機 + PG 操作層 + 券碼查券（發行人隔離）+ TRANSFER 過戶重簽碼
src/engine/transfer.js                   轉移引擎：一次性領取 token → 原子交割；過期/取消＝券留原持有人（失敗補償）
src/engine/dynamicCode.js                動態碼防偽：HMAC 60 秒輪換；轉移後 seq 落後即拒（防截圖重放）
src/engine/payment.js                   背景通知清算：驗簽→查單→比金額→原子入帳發券
src/engine/invoice.js                   發票編排：交易內入隊（SAVEPOINT）→ 非阻塞開立 → 補開
src/routes/payment.js                   下單/查詢/notify/return/對帳
src/routes/verify.js                    核銷台 API（X-Verify-Key＋發行人隔離＋發票監控/補開；動態碼/靜態碼雙入口）
src/routes/transfer.js                   用戶端轉贈 API（X-User-Id 開發期門禁；批次B 換 LINE Login session）
src/routes/public.js                    官網公開文案端點（/api/public/site，含 entity 分組）
src/routes/admin.js                     後台總覽（/api/admin/overview，四個監控視圖＋明確轉型）
src/server.js                            Express（CSP 放行藍新；/verify／/admin／/ 三組 static；版本 0.4.0-m1）
tests/                                   76 支（69 本機 pass／7 CI-only 真 PG）
tests/site.test.js                      文案對撞／前端 CSP／後台金鑰／版本對撞／R18 交叉驗證
apps/web/                               官網首頁【最新版 academia 優化版】：雙欄首屏／三步驟／產學合作／企業諮詢 mailto／A2 六區＋頁尾主體法遵門面（V2 文案鍵 19 個）
apps/admin/                             後台骨架（sessionStorage 金鑰、法遵儀表置頂、發票補開）
apps/verify/                            零構建核銷台前端（外部 JS/CSS、textContent 防 XSS）
apps/app/                               App 雙端（M2，uniapp）
docs/                                    規格書 v1.2＋律師清單＋GCP 拓撲＋單 VM 上線 SOP＋專案建立清單
```

## 法規紅線（寫進 CI 的）

| 紅線 | 工程對應 |
|------|---------|
| 禮券不得記載使用期限 | `tickets.state` 無 EXPIRED；`grace_end` 只是優惠期間；文案庫講「長期有效」 |
| 殘值不得沒收 | 部分核銷 `residual_cents` 完整保留；`residual_monitor` 視圖監控零殘值違規 |
| 電支條例 §3(10) 排除 | 點數不可購買、不可換現、首批僅原廠商兌換；無 cashout API |
| 履約保障 | `vendors.trust_*` 逐檔券信託專戶登記＋存入憑證 |
| 代收未付餘額監控 | `payables_monitor` 視圖（法遵儀表） |
| 點數守恆 | `points_conservation` 視圖：帳本累計＝用戶餘額合計，drift 必須 0 |
| 🔴 藍新條款 11/17 | `orders.fee_scope` 區分平台服務費／券貨款；券貨款不經平台藍新代號（待律師 D 節回覆） |
| 平台非發行人 | 頁尾揭露平台營運主體；發行人為各檔券所載廠商，其名稱／地址／統編／代表人揭露於逐檔券公開頁（`web.issuerNote`） |
| 發票開立時點可切換 | `invoices.issue_point`＝ORDER／REDEEM，兩處皆埋 hook，切換不改程式（待律師 C2） |
| 發票失敗不影響主交易 | `maybeEnqueue` 以 SAVEPOINT 隔離；付款／核銷照常 commit，失敗記 `invoice_outbox` |
| 核銷可追溯 | `verify_operations` append-only，成功與拒絕皆留軌；`X-Verify-Key`＋發行人隔離 |
| 對外文案不漂移 | 官網／後台**所有** `data-copy` 靜態副本由 `tests/site.test.js` 逐字對撞 `config/copy.js`（數量由 CI 動態統計，文件不寫死），自檢含「改一個字必被抓」反向測試 |
| 臺灣用語門面 | `scripts/check-banned-words.js` 除法規禁用語外，另掃大陸版語彙（券種／提現／託管池／備案號／微信支付／有效期／到期日／即期）；`核銷` 刻意不列（門市內部工具合法，僅對客文案禁用） |
| 前端上線不 404 | **R17**（檔進 image）＋**R18**（`/verify`／`/admin`／`/` 三組 static 掛載）雙重靜態規則，各有獨立注入反向自測；`tests/site.test.js` 再用逐行精確比對第三種抓法交叉驗證 |

## 臺灣用語對照（CI 掃描詞表）

| 大陸版（禁用） | 臺灣版（對外） | 依據 |
|---|---|---|
| 券種／保底流通券 | 商品(服務)禮券、面額 | 定型化契約用語 |
| 到期／有效期／核銷（對客） | 優惠期間／長期有效／兌換 | 不得記載使用期限（規格書 §2.1） |
| 託管池 | 金融機構信託專戶、專款專用 | 履約保障五選一（§2.3） |
| 備案號 | 統一編號＋應記載事項標示 | §1.1 合規門面 |
| 錢包／提現 | 權益點數（不可購買、不可換現） | 電支條例 §3(10)（§2.4） |
| 微信支付／發票 | 藍新 NewebPay／電子發票・載具・捐贈碼 | §2.5、律師 C2 |

`scripts/check-banned-words.js` 詞表＝法規明文禁用語 11 詞＋大陸版語彙 8 詞（券種／提現／託管池／備案號／微信支付／有效期／到期日／即期），`--selftest` 對新詞另有 3 組命中自測。
⚠️ 掃描範圍為 `src`／`config`／`apps`；**根目錄本檔不在範圍內，才逐字列出禁用語供人工審查**；`apps/` 下的 README 會被掃，故用語對照只放這裡。
🔴 `核銷` **刻意不列**：門市核銷台是內部工具、用語合法，僅**對客**文案禁用（由 `data-copy` 統一控管）。

## 技術棧

Node.js 22 LTS · Express 4 · PostgreSQL 16 · 零構建前端（外部 JS/CSS、無 inline script、全程 `textContent`）· **藍新 NewebPay（金流）**＋ezPay 電子發票（可插拔，M1 第二批已落地）· uniapp（M2 App 雙端）· **GCP asia-east1**：早期單台 e2-micro VM（Cloudflare Origin CA ＋ docker compose），M2 再評估 Cloud Run＋Cloud SQL＋Secret Manager。

## 主檔與兩岸對照

- **規格書唯一主檔**：`docs/臺灣ECT_TW系統規劃與軟體規格書_v1_1.md`（檔名沿用，內容已升 **v1.2**；附錄 C 為 M1 落地紀錄）
- 大陸版 ECT 倉庫 docs 下僅留索引，避免兩岸口徑漂移
- 藍新規格權威來源：自家《藍新金流申請與嵌入 SOP》《藍新金流嵌入-實作與上線說明》（見附錄 C.2），優先於網路二手資料

## 已知限制（v0.4.0-m1）

- **官網首頁以 2026-11-21 的 academia 優化版為最新版**（來源見 `apps/web/README.md` 與規格書附錄 C.9）；企業諮詢採 mailto 僅開郵件草稿，**無收件 API、無資料儲存**，若需留紀錄須另設計並補個資告知
- 本批**未部署任何 GCP 資源、未連真實藍新、未產生費用**；動生產需洪哥再 confirm
- 本機無 docker，故 compose 只做**靜態紀律檢查**（18 項）＋檢查器反向自測；真 `docker compose up` 需在有 docker 的環境執行
- e2-micro 僅 **1GB RAM**，上線必加 1GB swap（SOP §3/§5）；`mem_limit` 由 CI 把關
- 🔴 **ezPay 電子發票官方技術文件尚未取得**：`provider=stub`（本機/CI）與 `provider=http`（自建加值中心 webhook）立即可用；`provider=ezpay` 在 `EZPAY_HOST` 未設時 **fail-closed，不會誤送猜測欄位**。拿到文件只需對齊 `toEzpayParams`／`parseIssueResponse` 兩處。**不宣稱已串接正式加值中心。**
- 🔴 **發票開立時點待律師意見書（清單 C2）**：`ECT_INVOICE_ISSUE_POINT=ORDER|REDEEM` 可切換，兩處 hook 皆已埋好，切換不需改程式
- 官網首頁已落實 **A2 六區**與後台**平台 HQ 骨架**；🔴 **券廣場公開批次 API、逐檔券公開頁、企業採購表單仍為待建**（首頁已誠實標註「建置中」，不做空殼電商分類）；後台其餘三端（廠商／企業／公益）、App 雙端屬 M1 後段／M2
- 🔴 後台目前僅 `X-Admin-Token` **單因子**；`apps/admin/README.md` 要求的**平台 HQ TOTP 二階登入尚未實作**，正式上線前須補（勿直接對外開放）
- `/api/admin/overview` 依賴 DB，無 DB 回 503（不影響官網、核銷台與公開 ESG）；CI 以真 PG 驗證 SQL
- 券貨款（TICKET_SALE）收款憑證流程待律師 D 節回覆後實作，目前僅記 `trust_receipt_ref`
- 綠界樣板保留為備選，未啟用時不影響主鏈路
- `.env` 不入庫、不進 image；**主體統編／地址／代表人已於 2026-11-20 依公司登記資料回填**（三份文件交叉核對），可用 `ECT_ENTITY_*` 覆蓋；🔴 客服申訴專線**暫用公司電話 02-28097206**，若另設專線請改 `.env`；正式金鑰長期應走 GCP Secret Manager
- 核銷台目前為**網頁版**（`apps/verify`）；`ECT_VERIFY_KEY`／`ECT_VERIFY_VENDOR_ID` 未設時 API 一律 503，上線前須於 `.env` 設定
- 🔴 個資邊界：OneDrive `選我科技` 資料夾含證件影像，**僅盤點檔名、未讀內容、絕不入庫**；本專案只使用公司登記公開事項
