'use strict';
// 對外文案唯一來源。CI 會掃描本檔（scripts/check-banned-words.js）。
// 鐵律：一律講「優惠期間」與「完整保留」，禁用語見 scripts/check-banned-words.js 詞表。

const COPY = {
  // 平台營運主體（選我科技有限公司）。2026-11-20 由 OneDrive 公司登記資料回填：
  // 設立登記表 115066755／核准函 新北府經商字第1158076186號／基本資料備查 v1.1 三份交叉一致。
  // ⚠️ 平台非禮券發行人；發行人為各檔券所載廠商，其資料揭露於逐檔券公開頁。
  // env 可覆蓋（正式環境走 .env／GCP Secret Manager），預設值即為已核對之登記資料。
  entity: {
    name: process.env.ECT_ENTITY_NAME || '選我科技有限公司',
    unifiedNo: process.env.ECT_ENTITY_UNIFIED_NO || '62023886',
    address: process.env.ECT_ENTITY_ADDRESS || '（251）新北市淡水區原德路1號地下1層',
    representative: process.env.ECT_ENTITY_REPRESENTATIVE || '洪承洋',
    servicePhone: process.env.ECT_ENTITY_SERVICE_PHONE || '02-28097206',
    serviceEmail: process.env.ECT_ENTITY_SERVICE_EMAIL || 'jasonhung@pickmyplus.com',
    labels: {
      name: '公司名稱',
      unifiedNo: '統一編號',
      address: '登記地址',
      representative: '代表人',
      servicePhone: '消費申訴（客服）專線',
      serviceEmail: '客服信箱',
    },
  },

  ticket: {
    graceLabel: '優惠期間',
    graceOngoing: '優惠期間內可兌換本券所載之商品或服務',
    graceEnded: '優惠期間已結束，本券仍可依保底價值兌換等值商品或服務',
    alwaysValid: '本券長期有效，未使用之價值完整保留，不會消失',
    residualKept: '部分兌換後之剩餘價值完整保留，可繼續兌換',
    faceItems: [
      '發行人名稱、地址、統一編號及代表人姓名',
      '面額',
      '發售編號及出售日',
      '使用方式',
      '消費申訴（客服）專線',
      '履約保障機制',
    ],
    trustNotice: '本券面額已存入發行人於金融機構開立之信託專戶，專款專用；逾保障期間發行人仍負履約責任',
  },

  // 權益告知（非催辦）：T-30 / T-7 / T-1
  graceNotice: {
    D30: '親愛的會員，您持有的票券優惠期間尚有 30 天，別忘了來兌換好禮；之後本券仍長期有效、價值完整保留。',
    D7: '溫柔提醒：優惠期間還有 7 天，歡迎安排時間兌換；錯過也沒關係，本券仍可保底兌換。',
    D1: '最後提醒：優惠期間明天結束，之後本券依然有效，可依保底價值兌換，或轉為點數、捐作公益。',
    RESULT: '您的權益已依指示處理完成，明細請至「我的點數」查看。',
  },

  points: {
    label: '點數',
    intro: '點數由票券未使用之價值轉換而來，長期有效、完整保留',
    exits: ['兌換指定廠商票券', '轉贈合作公益團體'],
    noCashout: '點數僅供兌換與公益轉贈，不提供換現',
    redeem: '使用點數兌換票券（等值兌換，價值不縮水）',
  },

  charity: {
    donateCode: '消費發票可直接捐給合作公益團體（財政部電子發票捐贈碼）',
    byUser: '捐贈由您主動發起，平台僅依指示代為撥付並揭露資訊',
  },

  refund: {
    within7: '購買後 7 日內未使用，可無條件全額退還',
    general: '未使用之票券得申請退還，返還價金程序與手續費上限依券面記載',
  },

  payment: {
    platformFee: '平台服務費',
    trustSettlement: '款項直接存入發行人於金融機構開立之信託專戶，專款專用',
    returnHint: '付款結果以系統通知為準，明細可至「我的券」查看',
  },

  verify: {
    title: 'ECT-TW 門市核銷台',
    lookupHint: '輸入或掃描票券代碼',
    residualLabel: '剩餘可兌換價值',
    redeemAction: '核銷',
    graceAction: '優惠期間結束',
    convertAction: '轉為點數',
    donateAction: '轉贈公益',
    tip: '核銷後之剩餘價值完整保留，可繼續兌換',
  },

  invoice: {
    title: '電子發票',
    pending: '發票開立處理中，不影響本次核銷',
    issued: '發票已開立',
    failed: '發票待補開立（已記錄，將自動重試）',
    donateHint: '可指定捐贈碼，將發票直接捐給合作公益團體',
    issuePointPending: '開立時點待法遵意見書確認（律師清單 C2），以系統設定為準',
  },

  // 官網首頁（apps/web）：此處為唯一文案來源，前端以 data-copy 對撞，禁止自行撰寫法遵語句
  web: {
    tagline: '讓每一張券，都有去處',
    heroTitle: '把用不到的券，變成剛剛好的善意',
    heroSub: '季節性票券不必躺到最後一刻。平台聚合企業、員工與店家的未使用價值，全部導向公益出口，零浪費、善的循環。',
    ctaPrimary: '逛券廣場',
    ctaSecondary: '企業採購諮詢',
    academiaV1: {
      "kicker": "ACADEMIA & RESEARCH",
      "title": "讓善意，有研究同行",
      "intro": "臺灣益卡通結合產學合作與實務思考，探索企業禮贈、票券使用與公益轉贈之間的連結。",
      "partner": "國立臺北科技大學・經營管理系",
      "teacher": "產學合作｜吳斯偉教授",
      "relationship": "臺灣益卡通與吳斯偉教授進行產學合作，結合學術研究與企業實務，探索企業禮贈、票券運作與公益轉贈的創新模式。",
      "focusTitle": "課題研究",
      "focusText": "圍繞企業社會責任（CSR）、ESG 與票券運作模式，探討企業與社會的價值連結。",
      "practiceTitle": "實務應用",
      "practiceText": "結合三節禮贈及福委採購需求，完善使用流程與資訊揭露。",
      "futureTitle": "產學交流",
      "futureText": "透過研究討論與實務回饋，持續精進平台服務。",

      "cta": "洽詢產學合作"
},
    brand: 'ECT-TW 臺灣益卡通',
    taglineV2: '企業禮贈・自主選用・公益轉贈',
    heroTitleV2: '企業送得好，員工用得巧，善意來得妙',
    heroSubV2: '臺灣益卡通串連企業禮贈、員工用券與公益轉贈，讓每一份心意都有合適的去處。',
    ctaPrimaryV2: '企業禮贈諮詢',
    ctaSecondaryV2: '了解使用方式',
    esgTitle: '公益實時沉澱',
    esgLabels: ['累計公益金額', '公益筆數', '零浪費率', '合作專案'],
    esgNote: '數字由平台帳本自動彙總，非人工填寫；讀取失敗時顯示「—」，不以估算值替代。',
    fourGoodTitle: '四好檢驗標準',
    fourGoodV2: [
      { title: '企業好', text: '三節採購不再囤券，未使用價值可轉公益、可追溯。' },
      { title: '廠商好', text: '券檔上架即揭露履約保障，核銷與對帳一次到位。' },
      { title: '員工好', text: '用得到的就拿去用，用不到的也不損失，價值完整保留。' },
      { title: '社會好', text: '由使用者自主選擇轉贈，讓未使用的價值延續為善意。' },
    ],
    lawTitle: '法遵三保證',
    lawLabels: ['長期有效', '價值完整保留', '發行人與履約保障'],
    disclosureTitle: '每檔券公開頁完整揭露',
    trustTitle: '履約保障機制',
    entriesTitle: '平台入口',
    entries: [
      { label: '官網首頁', note: '品牌與公開資訊' },
      { label: '管理後台', note: '平台 HQ／廠商／企業／公益四端' },
      { label: '門市核銷台', note: '券碼查券與五個狀態動作' },
      { label: 'App 雙端', note: 'iOS／Android（M2）' },
    ],
    footerNote: '平台主體為選我科技有限公司；券面應記載事項以各檔券公開頁為準。',

    // ---- A2 六區導覽分類（臺灣用語，2026-11-20）----
    nav: ['品牌主張', '逛禮券', '法遵與權益', '公益合作', '常見問答', '管理後台'],

    // 區 2｜找券：場景主軸，逐檔券公開頁尚未上線，先揭露分類方式與應記載事項
    marketTitle: '逛禮券・三節禮券',
    marketNote: '依臺灣企業禮贈場景分類；逐檔券公開頁建置中，本區先提供分類方式與應記載事項說明。',
    marketScenes: [
      { title: '春節禮贈', text: '年節送禮不再囤券，未使用價值可轉公益、可追溯。' },
      { title: '端午禮贈', text: '企業福委批量採購，員工用得到的就拿去用。' },
      { title: '中秋禮贈', text: '伴手禮與餐飲住宿券，面額與履約保障一次揭露。' },
      { title: '尾牙與福委', text: '員工人人領得到、用不完也不損失，價值完整保留。' },
    ],
    marketAxisTitle: '券廣場分類（雙軸）',
    marketAxisNote: '場景 × 權益狀態交叉；分類不以剩餘天數或失效與否區分，改以優惠期間、保底可兌換、可轉公益標示。',
    marketAxisScenes: ['春節', '端午', '中秋', '尾牙福委', '餐飲・住宿・伴手禮'],
    marketAxisRights: ['優惠期間內', '保底可兌換', '可轉公益'],

    // 區 4｜法遵與權益：獨立成專區，律師清單 A4/A5 全量上頁
    lawZoneTitle: '禮券定型化契約專區',
    lawZoneNote: '依《商品（服務）禮券定型化契約應記載及不得記載事項》揭露；平台為媒合與帳務服務者，非禮券發行人。',
    issuerTitle: '發行人與平台的分工',
    issuerNote: '禮券發行人為各檔券所載之廠商；發行人名稱、地址、統一編號及代表人姓名、面額、發售編號及出售日、使用方式、消費申訴專線、履約保障機制，全量揭露於各檔券公開頁。選我科技有限公司為平台營運主體，不當發行人、不代收券貨款。',
    refundTitle: '退券程序',
    serviceTitle: '消費申訴（客服）專線',
    serviceNote: '對券面記載、兌換或款項有疑義，請於服務時間來電或來信；平台登錄後協調發行人處理並回覆。',

    // 區 5｜雙公益通道（答案複用既有法遵文案，不另寫一份）
    charityTitle: '雙公益通道',
    charityNote: '未使用的券價值與消費發票，都能由您主動指定，導向合作公益團體。',
    charityChannelTitles: ['券價值轉贈', '發票捐贈碼'],

    // 常見問答：問題在此，答案一律指向既有法遵文案（data-copy 唯一來源）
    faqTitle: '常見問答',
    faqs: [
      '禮券可以放多久？',
      '優惠期間結束後還能兌換嗎？',
      '只用了部分，剩下的價值怎麼辦？',
      '點數可以換現金嗎？',
      '券款放在哪裡，安全嗎？',
      '買了沒使用可以退嗎？',
      '發票可以捐給公益團體嗎？',
    ],

    // 區 6｜角色捷徑（收在導覽與頁尾，不佔主視覺）
    rolesTitle: '角色捷徑',
    roles: [
      { label: '企業', note: '三節採購・福委批量' },
      { label: '員工', note: '我的券・我的點數' },
      { label: '廠商', note: '券檔上架・對帳' },
      { label: '公益團體', note: '受贈記錄・撥付進度' },
      { label: '門市', note: '券碼查券・兌換' },
    ],
    footerEntityTitle: '應記載事項・平台營運主體',
    statusBuilding: '建置中',
    lawPill: '應記載事項全量揭露',
    axisScenesLabel: '採購場景',
    axisRightsLabel: '權益狀態',
  },

  // 後台（apps/admin）：法遵儀表用語不得寫成財務 KPI
  admin: {
    title: 'ECT-TW 管理後台',
    loginHint: '請輸入平台管理員核發的 X-Admin-Token；僅存於本頁籤，不寫入長期儲存。',
    tokenLabel: '管理員金鑰',
    loginBtn: '進入後台',
    logoutBtn: '登出',
    complianceTitle: '法遵儀表（置頂）',
    complianceNote: '以下為合規監控值，非營運 KPI；異常須立即查明，不得調整數字掩蓋。',
    overviewTitle: '營運總覽',
    invoiceTitle: '電子發票監控',
    retryBtn: '重試待補開立',
    navTitle: '後台四端',
    nav: [
      { label: '平台 HQ', note: '廠商審核／券檔審批／清算／覆核（本批：總覽與發票）' },
      { label: '廠商子後台', note: '券檔／優惠期間／核銷記錄／對帳（M1 後段）' },
      { label: '企業採購戶', note: '批量採購／員工分發／三節預購（M1 後段）' },
      { label: '公益對帳端', note: '受贈記錄／撥付進度／回執（M1 後段）' },
    ],
    kpiLabels: {
      tickets: '票券總數', unbound: '待歸戶', vendors: '上架廠商', products: '上架券檔',
      ordersPaid: '已付款訂單', payableCents: '代收未付餘額', zeroResidual: '零殘值違規',
      drift: '點數守恆漂移', invoicePending: '發票待開立', invoiceFailed: '發票待補開',
      verifyOps: '核銷操作數',
    },
    emptyHint: '尚無資料',
    dbHint: '資料庫不可用，請檢查 /health/db',
    status: {
      loggedOut: '未登入', loading: '讀取中', ok: '已連線',
      unauthorized: '金鑰無效', dbUnavailable: '資料庫不可用',
    },
  },

  esg: { liveLabel: '公益實時沉澱' },
};

module.exports = COPY;

