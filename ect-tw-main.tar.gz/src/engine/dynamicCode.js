'use strict';
// 動態碼防偽（M2 批次A）：HMAC-SHA256(secret, ticketId|seq|window)，60 秒輪換。
// 防偽三層：① 截圖 60 秒失效（時間窗）② 轉移後作廢（code_seq 比對，舊碼一律拒）
// ③ 引擎層原子核銷（FOR UPDATE + 冪等，見 tickets.js）。
// 金鑰走環境變數 ECT_DYNAMIC_CODE_SECRET，不得硬編碼、不得入庫入版控。
const crypto = require('node:crypto');
const T = require('./tickets');

const PREFIX = 'ECTD1';
const WINDOW_MS = 60_000;
const TOLERANCE = 1; // 容忍前一個視窗（店員設備時鐘偏差）

function secretFromEnv(env = process.env) {
  const s = env.ECT_DYNAMIC_CODE_SECRET;
  if (typeof s !== 'string' || s.length < 16) {
    throw new T.EngineError('SECRET_UNSET', 'ECT_DYNAMIC_CODE_SECRET must be >= 16 chars');
  }
  return s;
}

function hmac(secret, ticketId, seq, window) {
  return crypto.createHmac('sha256', secret)
    .update(`${ticketId}|${seq}|${window}`)
    .digest('hex').slice(0, 16);
}

// 簽發：動態碼僅回傳一次，由前端即時畫成 QR；伺服器不儲存明碼。
function issueDynamicCode({ ticketId, codeSeq, secret, now = Date.now() }) {
  const id = Number(ticketId);
  const seq = Number(codeSeq);
  if (!Number.isInteger(id) || id <= 0) throw new T.EngineError('BAD_TICKET_ID', 'bad ticket id');
  if (!Number.isInteger(seq) || seq < 0) throw new T.EngineError('BAD_SEQ', 'bad code seq');
  const w = Math.floor(now / WINDOW_MS);
  return `${PREFIX}.${id}.${seq}.${w}.${hmac(secret, id, seq, w)}`;
}

// 驗簽：只驗簽名與時間窗；seq 是否仍有效由呼叫端在交易內比對 tickets.code_seq。
function verifyDynamicCode(code, { secret, now = Date.now() }) {
  if (typeof code !== 'string' || code.length < 10 || code.length > 128) {
    return { ok: false, reason: 'BAD_CODE' };
  }
  const parts = code.trim().split('.');
  if (parts.length !== 5 || parts[0] !== PREFIX) return { ok: false, reason: 'BAD_FORMAT' };
  const id = Number(parts[1]);
  const seq = Number(parts[2]);
  const w = Number(parts[3]);
  const mac = parts[4];
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: 'BAD_TICKET_ID' };
  if (!Number.isInteger(seq) || seq < 0) return { ok: false, reason: 'BAD_SEQ' };
  if (!Number.isInteger(w) || w < 0) return { ok: false, reason: 'BAD_WINDOW' };
  if (!/^[0-9a-f]{16}$/.test(mac)) return { ok: false, reason: 'BAD_MAC' };
  const cur = Math.floor(now / WINDOW_MS);
  if (w < cur - TOLERANCE || w > cur) return { ok: false, reason: 'CODE_EXPIRED' };
  const expect = hmac(secret, id, seq, w);
  const a = Buffer.from(mac, 'hex');
  const b = Buffer.from(expect, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { ok: false, reason: 'BAD_SIGNATURE' };
  }
  return { ok: true, ticketId: id, codeSeq: seq };
}

// ---- 核銷台整合：靜態券碼與動態碼統一入口 ----
// 動態碼路徑：驗簽 → 依 ticketId 直查（含發行人隔離）→ code_seq 比對（舊碼一律拒）。
// 靜態路徑：維持 code_hash 反查（原有行為不變）。
async function resolveTicketForVerify(client, code, expectedVendorId, opts = {}) {
  if (typeof code === 'string' && code.trim().startsWith(`${PREFIX}.`)) {
    const secret = secretFromEnv();
    const v = verifyDynamicCode(code, { secret });
    if (!v.ok) throw new T.EngineError(v.reason, `dynamic code rejected: ${v.reason}`);
    const tk = await T.findTicketById(client, v.ticketId, expectedVendorId, opts);
    if (Number(tk.code_seq) !== v.codeSeq) {
      throw new T.EngineError('SEQ_STALE', 'dynamic code is stale (ticket re-issued after transfer)');
    }
    return tk;
  }
  return T.findTicketByCode(client, code, expectedVendorId, opts);
}

module.exports = {
  PREFIX, WINDOW_MS, TOLERANCE,
  secretFromEnv, issueDynamicCode, verifyDynamicCode, resolveTicketForVerify,
};
