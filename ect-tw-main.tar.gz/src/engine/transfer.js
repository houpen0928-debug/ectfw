'use strict';
// 券轉移引擎（M2 批次A）：一次性領取 token（預設 24h、單次消費）→ 原子交割。
// 補償語義：token 過期／取消／被拒時，券留在原持有人手上、狀態不動（對應專利 v3 失敗補償狀態機）。
// 紀律：token 明文只在建立時回傳一次；DB 只存 sha256（與券碼同紀律）。
const crypto = require('node:crypto');
const { withTransaction } = require('../../db');
const T = require('./tickets');

const TTL_DEFAULT_MS = 24 * 60 * 60 * 1000;
const TTL_MIN_MS = 60_000;
const TTL_MAX_MS = 7 * 24 * 60 * 60 * 1000;

function checkTtl(ms) {
  const ttl = Number(ms);
  if (!Number.isInteger(ttl) || ttl < TTL_MIN_MS || ttl > TTL_MAX_MS) {
    throw new T.EngineError('BAD_TTL', 'ttl out of range');
  }
  return ttl;
}

// 發起轉贈：持有人身分校驗 + 券可轉狀態校驗 + 同券舊 PENDING token 冪等作廢（單一在途）
async function createTransferToken(client, ticketId, fromUserId, opts = {}) {
  const ttl = checkTtl(opts.ttlMs || TTL_DEFAULT_MS);
  const id = Number(ticketId);
  const uid = Number(fromUserId);
  if (!Number.isInteger(id) || id <= 0) throw new T.EngineError('BAD_TICKET_ID', 'bad ticket id');
  if (!Number.isInteger(uid) || uid <= 0) throw new T.EngineError('BAD_USER_ID', 'bad user id');

  const tk = await T.lockTicket(client, id);
  if (tk.owner_user_id == null || Number(tk.owner_user_id) !== uid) {
    throw new T.EngineError('NOT_OWNER', 'ticket belongs to another user');
  }
  if (tk.state !== T.STATES.BOUND && tk.state !== T.STATES.GRACE) {
    throw new T.EngineError('NOT_TRANSFERABLE', 'ticket state not transferable');
  }

  await client.query(
    `UPDATE transfer_tokens SET status='LAPSED' WHERE ticket_id=$1 AND status='PENDING'`,
    [id]
  );
  const token = crypto.randomBytes(24).toString('base64url');
  const r = await client.query(
    `INSERT INTO transfer_tokens(ticket_id, from_user_id, token_hash, expires_at)
     VALUES($1,$2,$3, now() + make_interval(secs => $4))
     RETURNING id, expires_at`,
    [id, uid, T.sha256(token), Math.floor(ttl / 1000)]
  );
  return { ticketId: id, state: tk.state, token, expiresAt: r.rows[0].expires_at };
}

// 領取：token 單次消費 → 過戶重簽新碼（同一交易，失敗全回滾）
async function claimTransferToken(client, token, toUserId) {
  if (typeof token !== 'string' || token.trim().length < 8 || token.length > 128) {
    throw new T.EngineError('BAD_TOKEN', 'invalid transfer token');
  }
  const to = Number(toUserId);
  if (!Number.isInteger(to) || to <= 0) throw new T.EngineError('BAD_USER_ID', 'bad user id');

  const r = await client.query(
    `SELECT id, ticket_id, from_user_id, status, expires_at FROM transfer_tokens
     WHERE token_hash=$1 FOR UPDATE`,
    [T.sha256(token.trim())]
  );
  if (!r.rowCount) throw new T.EngineError('TOKEN_NOT_FOUND', 'transfer token not found');
  const tok = r.rows[0];
  if (tok.status === 'CLAIMED') throw new T.EngineError('TOKEN_CONSUMED', 'token already claimed');
  if (tok.status !== 'PENDING') {
    throw new T.EngineError('TOKEN_CLOSED', `token is ${String(tok.status).toLowerCase()}`);
  }
  if (new Date(tok.expires_at).getTime() <= Date.now()) {
    await client.query(`UPDATE transfer_tokens SET status='LAPSED' WHERE id=$1`, [tok.id]);
    throw new T.EngineError('TOKEN_EXPIRED', 'transfer token expired');
  }
  const u = await client.query('SELECT id FROM users WHERE id=$1', [to]);
  if (!u.rowCount) throw new T.EngineError('USER_NOT_FOUND', 'recipient user not found');

  const out = await T.transferTicket(client, tok.ticket_id, tok.from_user_id, to, `claim:${to}`);
  await client.query(
    `UPDATE transfer_tokens SET status='CLAIMED', claimed_at=now() WHERE id=$1`,
    [tok.id]
  );
  return { ticketId: Number(tok.ticket_id), state: out.state, code: out.code, scratch: out.scratch, codeSeq: out.codeSeq };
}

// 取消：僅原發起人可取消 PENDING token
async function cancelTransferToken(client, token, fromUserId) {
  if (typeof token !== 'string' || token.trim().length < 8 || token.length > 128) {
    throw new T.EngineError('BAD_TOKEN', 'invalid transfer token');
  }
  const r = await client.query(
    `SELECT id, ticket_id, from_user_id, status FROM transfer_tokens
     WHERE token_hash=$1 FOR UPDATE`,
    [T.sha256(token.trim())]
  );
  if (!r.rowCount) throw new T.EngineError('TOKEN_NOT_FOUND', 'transfer token not found');
  const tok = r.rows[0];
  if (Number(tok.from_user_id) !== Number(fromUserId)) {
    throw new T.EngineError('NOT_OWNER', 'only the initiator can cancel');
  }
  if (tok.status !== 'PENDING') {
    throw new T.EngineError('TOKEN_CLOSED', `token is ${String(tok.status).toLowerCase()}`);
  }
  await client.query(`UPDATE transfer_tokens SET status='CANCELLED' WHERE id=$1`, [tok.id]);
  return { ticketId: Number(tok.ticket_id), status: 'CANCELLED' };
}

const tx = {
  create: (ticketId, uid, opts) => withTransaction((c) => createTransferToken(c, ticketId, uid, opts)),
  claim: (token, uid) => withTransaction((c) => claimTransferToken(c, token, uid)),
  cancel: (token, uid) => withTransaction((c) => cancelTransferToken(c, token, uid)),
};

module.exports = {
  TTL_DEFAULT_MS, TTL_MIN_MS, TTL_MAX_MS,
  createTransferToken, claimTransferToken, cancelTransferToken, tx,
};
