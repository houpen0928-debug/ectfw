'use strict';
// ECT-TW 券引擎：純函式狀態機（可離線單測）+ PG 操作層（FOR UPDATE、append-only journal）
// 法遵鐵律：無 EXPIRED 終態；GRACE = 優惠期間已結束、價值完整保留；部分核銷後 residual 可繼續兌換。
const crypto = require('node:crypto');
const { withTransaction } = require('../../db');

const STATES = Object.freeze({
  UNBOUND: 'UNBOUND',
  BOUND: 'BOUND',
  USED: 'USED',
  GRACE: 'GRACE',
  CONVERTED: 'CONVERTED',
  CHARITY: 'CHARITY',
});
const ACTIONS = Object.freeze({
  ISSUE: 'ISSUE',
  BIND: 'BIND',
  TRANSFER: 'TRANSFER',
  REDEEM: 'REDEEM',
  GRACE_ENTER: 'GRACE_ENTER',
  CONVERT: 'CONVERT',
  DONATE: 'DONATE',
});
const TERMINAL = new Set([STATES.USED, STATES.CONVERTED, STATES.CHARITY]);

class EngineError extends Error {
  constructor(code, message) {
    super(message || code);
    this.code = code;
  }
}

// ---- 純函式狀態機 ----
// ctx: { amountCents, residualCents, ownerUserId }
// 回傳 { ok, state, residualCents, reason, journal }
function transition(from, action, ctx = {}) {
  if (!Object.values(STATES).includes(from)) {
    return { ok: false, reason: 'BAD_STATE' };
  }
  const residual = Number(ctx.residualCents || 0);
  if (TERMINAL.has(from)) {
    return { ok: false, reason: 'TERMINAL_STATE' };
  }

  switch (action) {
    case ACTIONS.BIND:
      if (from !== STATES.UNBOUND) return { ok: false, reason: 'MUST_BE_UNBOUND' };
      if (!ctx.ownerUserId) return { ok: false, reason: 'OWNER_REQUIRED' };
      return { ok: true, state: STATES.BOUND, residualCents: residual, journal: ACTIONS.BIND };

    case ACTIONS.TRANSFER:
      // 轉移＝所有權過戶：狀態與殘值不變，只有持有人換人（原子交割在 PG 層）
      if (from !== STATES.BOUND && from !== STATES.GRACE) {
        return { ok: false, reason: 'MUST_BE_BOUND_OR_GRACE' };
      }
      if (!ctx.fromUserId || !ctx.toUserId) return { ok: false, reason: 'OWNER_REQUIRED' };
      if (Number(ctx.fromUserId) === Number(ctx.toUserId)) {
        return { ok: false, reason: 'SELF_TRANSFER' };
      }
      return { ok: true, state: from, residualCents: residual, journal: ACTIONS.TRANSFER };

    case ACTIONS.GRACE_ENTER:
      // 未歸戶 / 已歸戶皆可進入優惠期間結束態；價值一分不減
      if (from !== STATES.UNBOUND && from !== STATES.BOUND) {
        return { ok: false, reason: 'INVALID_GRACE_SOURCE' };
      }
      return { ok: true, state: STATES.GRACE, residualCents: residual, journal: ACTIONS.GRACE_ENTER };

    case ACTIONS.REDEEM: {
      if (from !== STATES.BOUND && from !== STATES.GRACE) {
        return { ok: false, reason: 'MUST_BE_BOUND_OR_GRACE' };
      }
      const amount = Number(ctx.amountCents);
      if (!Number.isInteger(amount) || amount <= 0) return { ok: false, reason: 'BAD_AMOUNT' };
      if (amount > residual) return { ok: false, reason: 'AMOUNT_EXCEEDS_RESIDUAL' };
      const left = residual - amount;
      // 全額核銷才進終態；部分核銷留原狀態、殘值完整保留
      return {
        ok: true,
        state: left === 0 ? STATES.USED : from,
        residualCents: left,
        journal: left === 0 ? 'REDEEM_FULL' : 'REDEEM_PARTIAL',
      };
    }

    case ACTIONS.CONVERT:
      if (from !== STATES.BOUND && from !== STATES.GRACE) {
        return { ok: false, reason: 'MUST_BE_BOUND_OR_GRACE' };
      }
      if (!ctx.ownerUserId) return { ok: false, reason: 'OWNER_REQUIRED' };
      if (residual <= 0) return { ok: false, reason: 'NO_RESIDUAL' };
      // 價值全額轉入點數，不作廢、不歸零消失
      return { ok: true, state: STATES.CONVERTED, residualCents: 0, journal: ACTIONS.CONVERT };

    case ACTIONS.DONATE:
      if (from !== STATES.BOUND && from !== STATES.GRACE) {
        return { ok: false, reason: 'MUST_BE_BOUND_OR_GRACE' };
      }
      if (residual <= 0) return { ok: false, reason: 'NO_RESIDUAL' };
      return { ok: true, state: STATES.CHARITY, residualCents: 0, journal: ACTIONS.DONATE };

    default:
      return { ok: false, reason: 'UNKNOWN_ACTION' };
  }
}

function sha256(s) {
  return crypto.createHash('sha256').update(s).digest('hex');
}

async function journal(client, ticketId, action, actor, payload = {}) {
  await client.query(
    'INSERT INTO ticket_chain(ticket_id, action, actor, payload) VALUES($1,$2,$3,$4)',
    [ticketId, action, actor || 'system', JSON.stringify(payload)]
  );
}

// ---- PG 操作層：全部接收 client，由呼叫端包在 withTransaction 內 ----

// 依已付款訂單發券：從 product 快照面額/保底，寫入券 + journal，回傳明文券碼（僅此一次）
async function issueTickets(client, { orderId, qty }) {
  const o = await client.query(
    'SELECT id, order_no, product_id, batch_id, vendor_id, qty, status FROM orders WHERE id=$1 FOR UPDATE',
    [orderId]
  );
  if (!o.rowCount) throw new EngineError('ORDER_NOT_FOUND', 'order not found');
  const order = o.rows[0];
  if (order.status !== 'PAID') throw new EngineError('ORDER_NOT_PAID', 'order not paid');
  if (order.qty !== qty) throw new EngineError('QTY_MISMATCH', 'issue qty != order qty');

  const p = await client.query(
    'SELECT id, vendor_id, face_value_cents, floor_value_cents, status FROM products WHERE id=$1',
    [order.product_id]
  );
  if (!p.rowCount) throw new EngineError('PRODUCT_NOT_FOUND', 'product not found');
  const product = p.rows[0];
  if (product.status !== 'ACTIVE') throw new EngineError('PRODUCT_NOT_ACTIVE', 'product not active');
  if (product.vendor_id !== order.vendor_id) throw new EngineError('VENDOR_MISMATCH', 'vendor mismatch');

  // 券面應記載事項 3（發售編號／出售日）：訂單未指定批次時，於發券當下建立專屬批次
  let batchId = order.batch_id;
  if (!batchId) {
    const nb = await client.query(
      `INSERT INTO batches(product_id, issue_no, sale_date, qty, status)
       VALUES($1,$2,CURRENT_DATE,$3,'ISSUED') RETURNING id`,
      [order.product_id, order.order_no, qty]
    );
    batchId = nb.rows[0].id;
    await client.query('UPDATE orders SET batch_id=$1 WHERE id=$2', [batchId, order.id]);
  } else {
    const b = await client.query('SELECT id, product_id FROM batches WHERE id=$1', [batchId]);
    if (!b.rowCount || b.rows[0].product_id !== order.product_id) {
      throw new EngineError('BATCH_PRODUCT_MISMATCH', 'batch does not belong to product');
    }
  }

  const issued = [];
  for (let i = 0; i < qty; i++) {
    const code = crypto.randomBytes(18).toString('base64url');
    const scratch = crypto.randomBytes(18).toString('base64url');
    const r = await client.query(
      `INSERT INTO tickets(batch_id, code_hash, scratch_hash, state, order_id,
                           face_value_cents, floor_value_cents, residual_cents)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, created_at`,
      [
        batchId, sha256(code), sha256(scratch), STATES.UNBOUND, order.id,
        product.face_value_cents, product.floor_value_cents, product.face_value_cents,
      ]
    );
    const ticketId = r.rows[0].id;
    await journal(client, ticketId, ACTIONS.ISSUE, 'engine', {
      order_no: order.id, face: product.face_value_cents, floor: product.floor_value_cents,
    });
    issued.push({ ticketId, code, scratch, faceCents: product.face_value_cents });
  }

  await client.query(
    "UPDATE orders SET status='FULFILLED', fulfilled_at=now() WHERE id=$1",
    [orderId]
  );
  return issued;
}

async function lockTicket(client, ticketId) {
  const r = await client.query(
    `SELECT id, state, owner_user_id, code_seq, face_value_cents, floor_value_cents, residual_cents
     FROM tickets WHERE id=$1 FOR UPDATE`,
    [ticketId]
  );
  if (!r.rowCount) throw new EngineError('TICKET_NOT_FOUND', 'ticket not found');
  const tk = r.rows[0];
  // PG BIGINT 經 node-pg 回傳為字串；在源頭統一轉數字，避免型別外洩到交易與 API 層
  return {
    ...tk,
    code_seq: tk.code_seq == null ? 0 : Number(tk.code_seq),
    face_value_cents: tk.face_value_cents == null ? null : Number(tk.face_value_cents),
    floor_value_cents: tk.floor_value_cents == null ? null : Number(tk.floor_value_cents),
    residual_cents: tk.residual_cents == null ? null : Number(tk.residual_cents),
  };
}

// 核銷台查券：券碼 sha256 反查 + 同一交易內比對發行人（防跨廠商核銷）
// 寫動作預設 FOR UPDATE OF t 先取鎖，讓後續 redeem/grace/convert/donate 接在同一把鎖內，避免 TOCTOU；
// 唯讀查券（lookup）以 opts.lock=false 關閉寫鎖，避免無謂的鎖競爭。
async function findTicketByCode(client, code, expectedVendorId, opts = {}) {
  if (typeof code !== 'string' || code.trim().length < 6 || code.length > 256) {
    throw new EngineError('BAD_CODE', 'invalid ticket code');
  }
  // 唯讀查詢（lookup）不該上寫鎖；寫動作才 FOR UPDATE
  const locking = opts.lock !== false ? 'FOR UPDATE OF t' : '';
  const r = await client.query(
    `SELECT t.id, t.state, t.owner_user_id, t.corp_account_id,
            t.face_value_cents, t.floor_value_cents, t.residual_cents,
            t.order_id, t.bound_at, t.grace_entered_at, t.used_at, t.created_at,
            p.vendor_id, p.name AS product_name, b.issue_no, b.sale_date
     FROM tickets t
     JOIN batches b ON b.id = t.batch_id
     JOIN products p ON p.id = b.product_id
     WHERE t.code_hash = $1 ${locking}`,
    [sha256(code.trim())]
  );
  if (!r.rowCount) throw new EngineError('TICKET_NOT_FOUND', 'ticket not found');
  const row = r.rows[0];
  if (expectedVendorId != null && Number(row.vendor_id) !== Number(expectedVendorId)) {
    throw new EngineError('VENDOR_MISMATCH', 'ticket belongs to another issuer');
  }
  // PG BIGINT 經 node-pg 回傳為字串，源頭統一轉數字
  return {
    ...row,
    vendor_id: Number(row.vendor_id),
    face_value_cents: row.face_value_cents == null ? null : Number(row.face_value_cents),
    floor_value_cents: row.floor_value_cents == null ? null : Number(row.floor_value_cents),
    residual_cents: row.residual_cents == null ? null : Number(row.residual_cents),
  };
}

function applyOrThrow(from, action, ctx) {
  const t = transition(from, action, ctx);
  if (!t.ok) throw new EngineError(t.reason, `transition rejected: ${t.reason}`);
  return t;
}

// ticketId 直查（動態碼核銷路徑）：發行人隔離 + 選擇性鎖定，語義與 findTicketByCode 對齊
async function findTicketById(client, ticketId, expectedVendorId, opts = {}) {
  const id = Number(ticketId);
  if (!Number.isInteger(id) || id <= 0) throw new EngineError('BAD_TICKET_ID', 'bad ticket id');
  const locking = opts.lock !== false ? 'FOR UPDATE OF t' : '';
  const r = await client.query(
    `SELECT t.id, t.state, t.owner_user_id, t.code_seq, t.corp_account_id,
            t.face_value_cents, t.floor_value_cents, t.residual_cents,
            t.order_id, t.bound_at, t.grace_entered_at, t.used_at, t.created_at,
            p.vendor_id, p.name AS product_name, b.issue_no, b.sale_date
     FROM tickets t
     JOIN batches b ON b.id = t.batch_id
     JOIN products p ON p.id = b.product_id
     WHERE t.id = $1 ${locking}`,
    [id]
  );
  if (!r.rowCount) throw new EngineError('TICKET_NOT_FOUND', 'ticket not found');
  const row = r.rows[0];
  if (expectedVendorId != null && Number(row.vendor_id) !== Number(expectedVendorId)) {
    throw new EngineError('VENDOR_MISMATCH', 'ticket belongs to another issuer');
  }
  return {
    ...row,
    vendor_id: Number(row.vendor_id),
    code_seq: row.code_seq == null ? 0 : Number(row.code_seq),
    face_value_cents: row.face_value_cents == null ? null : Number(row.face_value_cents),
    floor_value_cents: row.floor_value_cents == null ? null : Number(row.floor_value_cents),
    residual_cents: row.residual_cents == null ? null : Number(row.residual_cents),
  };
}

async function bindTicket(client, ticketId, userId, actor = 'user') {
  const tk = await lockTicket(client, ticketId);
  const t = applyOrThrow(tk.state, ACTIONS.BIND, {
    ownerUserId: userId, residualCents: tk.residual_cents,
  });
  await client.query(
    'UPDATE tickets SET state=$1, owner_user_id=$2, bound_at=now() WHERE id=$3',
    [t.state, userId, ticketId]
  );
  await journal(client, ticketId, t.journal, actor, { user_id: userId });
  return { state: t.state };
}

// 轉移（過戶）：同一交易內鎖券 → 狀態機 → 重簽新碼。
// 防盜核銷關鍵：code_hash/scratch_hash 一併換新、code_seq+1，
// 轉出人手上的舊靜態碼（code_hash 已換）與舊動態碼（seq 落後）同時作廢。
async function transferTicket(client, ticketId, fromUserId, toUserId, actor = 'user') {
  const id = Number(ticketId);
  if (!Number.isInteger(id) || id <= 0) throw new EngineError('BAD_TICKET_ID', 'bad ticket id');
  const to = Number(toUserId);
  if (!Number.isInteger(to) || to <= 0) throw new EngineError('BAD_RECIPIENT', 'bad recipient user id');
  const tk = await lockTicket(client, id);
  if (tk.owner_user_id == null || Number(tk.owner_user_id) !== Number(fromUserId)) {
    throw new EngineError('NOT_OWNER', 'ticket belongs to another user');
  }
  const t = applyOrThrow(tk.state, ACTIONS.TRANSFER, {
    fromUserId: Number(fromUserId), toUserId: to, residualCents: tk.residual_cents,
  });
  const newCode = crypto.randomBytes(18).toString('base64url');
  const newScratch = crypto.randomBytes(18).toString('base64url');
  const seq = tk.code_seq + 1;
  await client.query(
    `UPDATE tickets SET owner_user_id=$1, code_hash=$2, scratch_hash=$3, code_seq=$4
     WHERE id=$5`,
    [to, sha256(newCode), sha256(newScratch), seq, id]
  );
  await journal(client, id, t.journal, actor, {
    from_user_id: Number(fromUserId), to_user_id: to, code_seq: seq,
  });
  // 新券碼明文僅此一次回傳（轉入人領取時收 到），DB 只存雜湊
  return { state: t.state, residualCents: tk.residual_cents, code: newCode, scratch: newScratch, codeSeq: seq };
}

// 核銷：部分核銷 residual 保留；全額核銷寫 settlements（廠商應收，T+1 清算）
async function redeemTicket(client, ticketId, amountCents, actor = 'vendor') {
  const tk = await lockTicket(client, ticketId);
  const t = applyOrThrow(tk.state, ACTIONS.REDEEM, {
    amountCents, residualCents: tk.residual_cents,
  });
  const terminal = t.state === STATES.USED;
  await client.query(
    `UPDATE tickets SET state=$1, residual_cents=$2, used_at=CASE WHEN $3 THEN now() ELSE used_at END,
                        terminal_at=CASE WHEN $3 THEN now() ELSE terminal_at END
     WHERE id=$4`,
    [t.state, t.residualCents, terminal, ticketId]
  );
  // settlements 需 vendor_id：由 batch→product 反查
  const v = await client.query(
    `SELECT p.vendor_id FROM tickets t
     JOIN batches b ON b.id=t.batch_id JOIN products p ON p.id=b.product_id
     WHERE t.id=$1`,
    [ticketId]
  );
  const vendorId = v.rowCount ? v.rows[0].vendor_id : null;
  if (vendorId) {
    await client.query(
      `INSERT INTO settlements(vendor_id, ticket_id, gross_cents, platform_fee_cents, net_cents, status)
       VALUES($1,$2,$3,0,$3,'PENDING')`,
      [vendorId, ticketId, amountCents]
    );
  }
  await journal(client, ticketId, t.journal, actor, { amount_cents: amountCents, left: t.residualCents });
  return { state: t.state, residualCents: t.residualCents };
}

async function graceEnter(client, ticketId, actor = 'scheduler') {
  const tk = await lockTicket(client, ticketId);
  if (tk.state === STATES.GRACE) return { state: tk.state, idempotent: true };
  const t = applyOrThrow(tk.state, ACTIONS.GRACE_ENTER, { residualCents: tk.residual_cents });
  await client.query(
    'UPDATE tickets SET state=$1, grace_entered_at=now() WHERE id=$2',
    [t.state, ticketId]
  );
  await journal(client, ticketId, t.journal, actor, { note: '優惠期間結束，價值完整保留' });
  return { state: t.state };
}

// 轉點數：residual 全額入 users.points_balance_cents + points_ledger（balance_after 對帳）
async function convertToPoints(client, ticketId, userId) {
  const tk = await lockTicket(client, ticketId);
  if (tk.owner_user_id && Number(tk.owner_user_id) !== Number(userId)) {
    throw new EngineError('NOT_OWNER', 'ticket belongs to another user');
  }
  const t = applyOrThrow(tk.state, ACTIONS.CONVERT, {
    ownerUserId: userId, residualCents: tk.residual_cents,
  });
  const amount = tk.residual_cents;
  const bal = await client.query(
    'UPDATE users SET points_balance_cents = points_balance_cents + $1 WHERE id=$2 RETURNING points_balance_cents',
    [amount, userId]
  );
  if (!bal.rowCount) throw new EngineError('USER_NOT_FOUND', 'user not found');
  await client.query(
    `INSERT INTO points_ledger(user_id, delta_cents, balance_after_cents, reason, ref)
     VALUES($1,$2,$3,'GRACE_CONVERT',$4)`,
    [userId, amount, bal.rows[0].points_balance_cents, String(ticketId)]
  );
  await client.query(
    "UPDATE tickets SET state=$1, residual_cents=0, converted_at=now(), terminal_at=now() WHERE id=$2",
    [t.state, ticketId]
  );
  await journal(client, ticketId, t.journal, 'user', { user_id: userId, amount_cents: amount });
  return { state: t.state, creditedCents: amount, balanceCents: Number(bal.rows[0].points_balance_cents) };
}

async function donateToCharity(client, ticketId, partnerId, userId = null) {
  const tk = await lockTicket(client, ticketId);
  const t = applyOrThrow(tk.state, ACTIONS.DONATE, { residualCents: tk.residual_cents });
  const amount = tk.residual_cents;
  const p = await client.query('SELECT id FROM charity_partners WHERE id=$1', [partnerId]);
  if (!p.rowCount) throw new EngineError('PARTNER_NOT_FOUND', 'charity partner not found');
  await client.query(
    `INSERT INTO donations(user_id, ticket_id, partner_id, amount_cents, path)
     VALUES($1,$2,$3,$4,'USER_CHOICE')`,
    [userId, ticketId, partnerId, amount]
  );
  await client.query(
    "UPDATE tickets SET state=$1, residual_cents=0, terminal_at=now() WHERE id=$2",
    [t.state, ticketId]
  );
  await journal(client, ticketId, t.journal, 'user', { partner_id: partnerId, amount_cents: amount });
  return { state: t.state, donatedCents: amount };
}

// ---- 交易包裝（對外便捷入口）----
const tx = {
  issue: (input) => withTransaction((c) => issueTickets(c, input)),
  bind: (id, uid, actor) => withTransaction((c) => bindTicket(c, id, uid, actor)),
  transfer: (id, from, to, actor) => withTransaction((c) => transferTicket(c, id, from, to, actor)),
  redeem: (id, amt, actor) => withTransaction((c) => redeemTicket(c, id, amt, actor)),
  graceEnter: (id, actor) => withTransaction((c) => graceEnter(c, id, actor)),
  convert: (id, uid) => withTransaction((c) => convertToPoints(c, id, uid)),
  donate: (id, pid, uid) => withTransaction((c) => donateToCharity(c, id, pid, uid)),
};

module.exports = {
  STATES, ACTIONS, TERMINAL, EngineError, transition, sha256,
  issueTickets, findTicketByCode, findTicketById, bindTicket, transferTicket, redeemTicket,
  graceEnter, convertToPoints, donateToCharity, lockTicket,
  tx,
};
