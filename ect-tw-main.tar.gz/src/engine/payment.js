'use strict';
// 藍新背景通知清算：驗簽 → 查單 → 金額比對 → 單一交易入帳＋發券。
// 直接呼叫真實函式即可測試（不需 HTTP），對應自家 SOP「四層驗證」的程式層。
const { withTransaction } = require('../../db');
const { parseNotify } = require('../payments/newebpay');
const { issueTickets } = require('./tickets');
const invoice = require('./invoice');

async function logEvent(client, orderNo, event, detail, payload = {}) {
  await client.query(
    'INSERT INTO payment_events(order_no, event, detail, payload) VALUES($1,$2,$3,$4)',
    [orderNo || null, event, detail || null, JSON.stringify(payload)]
  );
}

// 由 route 傳入已解析的 form 與 cfg；回傳 { ok, reason, orderNo, issued }
async function settleNotify(form, cfg) {
  const parsed = parseNotify(form, cfg);
  const orderNo = parsed.result?.MerchantOrderNo || null;

  if (!parsed.ok) {
    // 稽核留痕 fire-and-forget：DB 故障不影響拒絕判定（fail-closed 優先）
    withTransaction((c) => logEvent(c, orderNo, parsed.reason, '背景通知驗簽/解密失敗', {
      Status: parsed.outer.Status,
    })).catch(() => {});
    return { ok: false, reason: parsed.reason, orderNo };
  }

  return withTransaction(async (client) => {
    const { result } = parsed;
    await logEvent(client, orderNo, 'NOTIFY_RECEIVED', '驗簽通過', {
      Status: result.Status, Amt: result.Amt, TradeNo: result.TradeNo,
    });

    if (result.Status !== 'SUCCESS') {
      await logEvent(client, orderNo, 'NOT_SUCCESS', `交易狀態 ${result.Status}`, { Message: result.Message });
      return { ok: false, reason: 'NOT_SUCCESS', orderNo };
    }

    // 冪等：同一 MerchantOrderNo 已入帳 → 不再發券
    const dup = await client.query(
      'SELECT id, status FROM newebpay_txn WHERE merchant_order_no=$1',
      [orderNo]
    );
    if (dup.rowCount) {
      await logEvent(client, orderNo, 'DUPLICATE', '重送通知，略過');
      return { ok: true, reason: 'DUPLICATE', orderNo, issued: [] };
    }

    const o = await client.query(
      `SELECT id, order_no, qty, amount_cents, fee_scope, status, vendor_id
       FROM orders WHERE order_no=$1 FOR UPDATE`,
      [orderNo]
    );
    if (!o.rowCount) {
      await logEvent(client, orderNo, 'ORDER_NOT_FOUND', '訂單不存在');
      return { ok: false, reason: 'ORDER_NOT_FOUND', orderNo };
    }
    const order = o.rows[0];

    // 收款主體紅線：平台商店代號只收平台服務費；券貨款走廠商信託專戶，不進此通道
    if (order.fee_scope !== 'PLATFORM_FEE') {
      await logEvent(client, orderNo, 'FEE_SCOPE_REJECT', '券貨款不經平台藍新代號', {
        fee_scope: order.fee_scope,
      });
      return { ok: false, reason: 'FEE_SCOPE_REJECT', orderNo };
    }

    // 金額不符：拒絕且訂單保持未付款（SOP §五 #19-20）
    const paidCents = Math.round(Number(result.Amt) * 100);
    if (!Number.isFinite(paidCents) || paidCents !== Number(order.amount_cents)) {
      await logEvent(client, orderNo, 'AMOUNT_MISMATCH', '回呼金額與訂單不符', {
        paid_cents: paidCents, order_cents: Number(order.amount_cents),
      });
      return { ok: false, reason: 'AMOUNT_MISMATCH', orderNo };
    }

    if (order.status !== 'PENDING') {
      await logEvent(client, orderNo, 'ORDER_STATE_REJECT', `訂單狀態 ${order.status}`, {});
      return { ok: false, reason: 'ORDER_STATE_REJECT', orderNo };
    }

    await client.query(
      `INSERT INTO newebpay_txn(ref_kind, ref_id, merchant_order_no, trade_no, amt_cents,
                                status, pay_time, payload)
       VALUES('ORDER',$1,$2,$3,$4,'PAID', now(), $5)`,
      [order.id, orderNo, result.TradeNo || null, paidCents, JSON.stringify(result)]
    );
    await client.query("UPDATE orders SET status='PAID' WHERE id=$1", [order.id]);

    // 同一交易內發券（付款成功 → 券產生，原子）
    const issued = await issueTickets(client, { orderId: order.id, qty: order.qty });
    await logEvent(client, orderNo, 'PAID', '入帳並發券完成', {
      tickets: issued.length, trade_no: result.TradeNo,
    });

    // 發票：一張訂單一張（不論發券張數）；開立點為 ORDER 時才入隊。
    // 任何發票異常都只留痕、不回滾付款交易（fail-safe）。
    let invoiceId = null;
    try {
      const inv = await invoice.maybeEnqueue(client, 'ORDER', {
        orderNo, vendorId: order.vendor_id,
        amountCents: Number(order.amount_cents),
        ticketId: issued.length ? issued[0].ticketId : null,
        itemName: 'ECT-TW 票券',
      });
      invoiceId = inv ? inv.id : null;
    } catch (err) {
      await logEvent(client, orderNo, 'INVOICE_ENQUEUE_FAILED', err.message);
    }
    return { ok: true, reason: 'PAID', orderNo, issued, invoiceId };
  });
}

module.exports = { settleNotify, logEvent };
