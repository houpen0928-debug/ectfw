'use strict';
// 電子發票編排層：交易內入隊（必定成功）→ 交易後非阻塞開立（失敗記 outbox 待補）。
// 鐵律：發票失敗不影響付款入帳與核銷；開立時點由 ECT_INVOICE_ISSUE_POINT 決定（律師 C2 待確認）。
const { query, withTransaction } = require('../../db');
const ezpay = require('../payments/ezpay');

const MAX_ATTEMPTS = 5;
const inflight = new Set();
let spSeq = 0; // SAVEPOINT 名稱唯一化：同一交易若有多個 hook 也不會互相覆蓋

function configFromEnv() {
  return ezpay.configFromEnv();
}

function issuePoint() {
  return configFromEnv().issuePoint;
}

async function logOutbox(client, { invoiceId, ticketId, orderNo, event, detail, payload = {} }) {
  await client.query(
    `INSERT INTO invoice_outbox(invoice_id, ticket_id, order_no, event, detail, payload)
     VALUES($1,$2,$3,$4,$5,$6)`,
    [invoiceId || null, ticketId || null, orderNo || null, event, detail || null, JSON.stringify(payload)]
  );
}

/**
 * 在同一交易內建立發票待開立單（冪等）。回傳 { id, duplicate } 或 null（非本時點）。
 * 呼叫端必須傳入 withTransaction 的 client，確保與發券／核銷同一交易。
 */
async function enqueueInvoice(client, input) {
  const cfg = configFromEnv();
  const req = ezpay.buildInvoiceRequest({ ...input, issuePoint: input.issuePoint || cfg.issuePoint }, cfg);
  const r = await client.query(
    `INSERT INTO invoices(ticket_id, vendor_id, order_no, idempotency_key, issue_point,
                          provider, type, amount_cents, carrier_id, donate_code, status, payload)
     VALUES($1,$2,$3,$4,$5,$6,'ISSUE',$7,$8,$9,'PENDING',$10)
     ON CONFLICT (idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING
     RETURNING id`,
    [
      req.ticketId, req.vendorId, req.orderNo, req.idempotencyKey, req.issuePoint,
      req.provider, req.amountCents, req.carrierId || null, req.donateCode || null,
      JSON.stringify(req),
    ]
  );
  if (r.rowCount) {
    const id = Number(r.rows[0].id);
    await logOutbox(client, {
      invoiceId: id, ticketId: req.ticketId, orderNo: req.orderNo, event: 'QUEUED',
      detail: `開立點 ${req.issuePoint}／provider ${req.provider}`, payload: { ref: req.ref },
    });
    return { id, duplicate: false };
  }
  const existing = await client.query(
    'SELECT id FROM invoices WHERE idempotency_key=$1', [req.idempotencyKey]
  );
  return { id: Number(existing.rows[0].id), duplicate: true };
}

/**
 * 依設定決定是否在這個時點開立。非本時點留 SKIPPED 軌跡，避免日後查帳誤以為漏開。
 * point: 'ORDER'（付款發券後）或 'REDEEM'（核銷後）
 *
 * 🔴 交易安全（P0）：本函式被呼叫在「付款入帳／門市核銷」的同一交易內。
 *    PostgreSQL 任一 statement 錯誤會把整個 transaction 標為 aborted，
 *    之後連寫 outbox 留痕都會失敗，最後把付款／核銷一起回滾 —— 違反
 *    「發票失敗不影響主鏈路」鐵律。故以 SAVEPOINT 隔離：出錯先 ROLLBACK TO，
 *    讓交易恢復可用再留痕，主交易照樣 commit。
 */
async function maybeEnqueue(client, point, input) {
  const cfg = configFromEnv();
  const sp = `ect_invoice_${++spSeq}`;
  let saved = false;
  try {
    await client.query(`SAVEPOINT ${sp}`);
    saved = true;
    if (cfg.issuePoint !== point) {
      await logOutbox(client, {
        ticketId: input.ticketId || null, orderNo: input.orderNo || null, event: 'SKIPPED',
        detail: `開立點為 ${cfg.issuePoint}，非 ${point}`,
        payload: { amountCents: input.amountCents, point },
      });
      return null;
    }
    return await enqueueInvoice(client, { ...input, issuePoint: point });
  } catch (err) {
    // 先解除 aborted 狀態，否則下一句 INSERT 也必定失敗
    if (saved) {
      try { await client.query(`ROLLBACK TO SAVEPOINT ${sp}`); } catch (_) { /* 已盡力 */ }
    }
    // 正規化失敗（非整元、捐贈碼錯）或 DB 寫入失敗（vendor_id 缺、約束衝突）都要留痕
    try {
      await logOutbox(client, {
        ticketId: input.ticketId || null, orderNo: input.orderNo || null,
        event: 'FAILED', detail: `發票入隊失敗：${err.message}`.slice(0, 400),
        payload: { amountCents: input.amountCents, point, reason: err.message },
      });
    } catch (_) { /* 連留痕都失敗也不能拖垮主交易 */ }
    return null; // fail-safe：主交易（付款／核銷）照常 commit
  } finally {
    if (saved) {
      try { await client.query(`RELEASE SAVEPOINT ${sp}`); } catch (_) { /* 已盡力 */ }
    }
  }
}

function parsePayload(v) {
  if (v && typeof v === 'object') return v;
  try { return JSON.parse(v || '{}'); } catch (_) { return {}; }
}

/** 實際開立一張發票；不論成功失敗都更新狀態並寫 outbox，永不向上拋。 */
async function processInvoice(invoiceId, cfg = configFromEnv()) {
  const id = Number(invoiceId);
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: 'BAD_INVOICE_ID' };
  if (inflight.has(id)) return { ok: false, reason: 'IN_FLIGHT' };
  inflight.add(id);
  try {
    const r = await query('SELECT * FROM invoices WHERE id=$1', [id]);
    if (!r.rowCount) return { ok: false, reason: 'INVOICE_NOT_FOUND' };
    const inv = r.rows[0];
    if (inv.status === 'ISSUED') return { ok: true, reason: 'ALREADY_ISSUED', invoiceNo: inv.invoice_no };
    if (Number(inv.attempts) >= MAX_ATTEMPTS) {
      return { ok: false, reason: 'MAX_ATTEMPTS', attempts: Number(inv.attempts) };
    }
    const req = parsePayload(inv.payload);
    let out;
    try {
      out = await ezpay.sendIssue(req, cfg);
    } catch (err) {
      out = { ok: false, reason: 'SEND_EXCEPTION', message: err.message };
    }

    if (out.ok) {
      await query(
        `UPDATE invoices SET status='ISSUED', invoice_no=$1, ecpay_invoice_no=$1,
                             invoice_date=$2, random_number=$3, issued_at=now(),
                             attempts=attempts+1, last_error=NULL,
                             payload=payload || $4::jsonb, updated_at=now()
         WHERE id=$5`,
        [out.invoiceNo || null, out.invoiceDate || null, out.randomNumber || null,
         JSON.stringify({ result: out }), id]
      );
      await withTransaction((c) => logOutbox(c, {
        invoiceId: id, ticketId: inv.ticket_id, orderNo: inv.order_no, event: 'SENT',
        detail: out.simulated ? '模擬開立' : '加值中心回覆成功',
        payload: { invoiceNo: out.invoiceNo, simulated: !!out.simulated },
      }));
    } else {
      await query(
        `UPDATE invoices SET status='FAILED', attempts=attempts+1, last_error=$1, updated_at=now()
         WHERE id=$2`,
        [String(out.reason || 'FAILED').slice(0, 200) + (out.message ? `: ${out.message}` : ''), id]
      );
      await withTransaction((c) => logOutbox(c, {
        invoiceId: id, ticketId: inv.ticket_id, orderNo: inv.order_no, event: 'FAILED',
        detail: String(out.reason || 'FAILED'), payload: { message: out.message || '' },
      }));
    }
    return { ok: out.ok, reason: out.reason || (out.ok ? 'ISSUED' : 'FAILED'), ...out };
  } catch (err) {
    // DB 異常也不外拋：發票永遠不該拖垮主鏈路
    console.error('[invoice] process failed', id, err.message);
    return { ok: false, reason: 'PROCESS_EXCEPTION', message: err.message };
  } finally {
    inflight.delete(id);
  }
}

/** 交易 commit 後呼叫：非阻塞開立。同一 id 重複呼叫由 inflight 擋下。 */
function fireInvoice(invoiceId) {
  const id = Number(invoiceId);
  if (!Number.isInteger(id) || id <= 0) return;
  setImmediate(() => {
    processInvoice(id).catch((err) => console.error('[invoice] fire failed', id, err.message));
  });
}

/** 管理端補開：把 PENDING/FAILED 且未達上限的發票重跑一輪。 */
async function retryPending(limit = 20) {
  const n = Math.min(Math.max(Number(limit) || 20, 1), 100);
  const r = await query(
    `SELECT id FROM invoices WHERE status IN ('PENDING','FAILED') AND attempts < $1
     ORDER BY created_at LIMIT $2`,
    [MAX_ATTEMPTS, n]
  );
  const results = [];
  for (const row of r.rows) {
    // eslint-disable-next-line no-await-in-loop
    results.push({ id: Number(row.id), ...(await processInvoice(Number(row.id))) });
  }
  return results;
}

async function getInvoiceByTicket(ticketId) {
  const r = await query(
    `SELECT id, order_no, invoice_no, invoice_date, status, amount_cents, carrier_id,
            donate_code, provider, issue_point, attempts, last_error, created_at, issued_at
     FROM invoices WHERE ticket_id=$1 ORDER BY created_at DESC LIMIT 1`,
    [ticketId]
  );
  return r.rowCount ? r.rows[0] : null;
}

module.exports = {
  MAX_ATTEMPTS, configFromEnv, issuePoint,
  enqueueInvoice, maybeEnqueue, processInvoice, fireInvoice,
  retryPending, getInvoiceByTicket, logOutbox,
};
