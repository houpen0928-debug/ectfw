'use strict';
// 批次②身份路由骨架：LINE Login（外部瀏覽器 OAuth）＋ LIFF（ID token 換 session）＋ /me ＋ logout。
// 🔴 雙重 fail-closed：① LINE 設定／session 金鑰未齊 → 503；② nginx 唯讀白名單未放行 /api/auth/* → 公網 404。
// 🔴 不回傳 id_token／access_token／channel secret／原始 LINE 錯誤給前端。
const express = require('express');
const S = require('../auth/session');
const L = require('../auth/line');
const db = require('../../db');

const router = express.Router();
const KNOWN = new Set([
  'BAD_ISSUER', 'BAD_AUDIENCE', 'TOKEN_EXPIRED', 'BAD_SUBJECT', 'BAD_NONCE',
  'BAD_ID_TOKEN', 'ID_TOKEN_REJECTED', 'BAD_VERIFY_RESPONSE',
  'BAD_CODE', 'TOKEN_EXCHANGE_FAILED', 'NO_ID_TOKEN',
  'SESSION_SECRET_UNSET', 'LINE_CONFIG_UNSET',
]);

function configOr503(res) {
  let cfg, secret;
  try { cfg = L.lineConfigFromEnv(process.env); } catch {
    res.status(503).json({ error: 'line_not_configured' });
    return null;
  }
  try { secret = S.sessionSecretFromEnv(process.env); } catch {
    res.status(503).json({ error: 'session_unavailable' });
    return null;
  }
  return { cfg, secret };
}

function sessionTtl() {
  const n = Number(process.env.ECT_SESSION_TTL_MS);
  return Number.isFinite(n) && n >= 60_000 && n <= 30 * 24 * 60 * 60 * 1000
    ? n : S.DEFAULT_TTL_MS;
}

function landingUrl() {
  return String(process.env.ECT_LINE_LANDING_URL || 'https://www.twect.com.tw/liff/').trim();
}

function errorResponse(res, err) {
  if (KNOWN.has(err.code)) return res.status(401).json({ error: 'auth_failed' });
  console.error('[auth]', err && err.message);
  return res.status(502).json({ error: 'auth_unavailable' });
}

// LIFF 頁在 Pages（www），API 在 VM（api）→ 跨域。帶 credentials 時不可用 '*'，
// 只放行 ECT_LIFF_ORIGIN 白名單；未設即 503（不猜測來源）。
function liffCors(req, res, next) {
  const allowed = String(process.env.ECT_LIFF_ORIGIN || '').trim();
  if (!allowed) return res.status(503).json({ error: 'liff_origin_unset' });
  const origin = req.headers.origin;
  if (origin && origin !== allowed) return res.status(403).json({ error: 'origin_not_allowed' });
  if (origin === allowed) {
    res.set('Access-Control-Allow-Origin', allowed);
    res.set('Access-Control-Allow-Credentials', 'true');
    res.set('Vary', 'Origin');
    if (req.method === 'OPTIONS') {
      res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
      res.set('Access-Control-Allow-Headers', 'Content-Type');
      return res.status(204).end();
    }
  }
  return next();
}

router.options('/api/auth/line/session', liffCors, (_req, res) => res.status(204).end());

// 外部瀏覽器：導向 LINE 授權頁。state/nonce 簽進 httpOnly cookie，callback 比對。
router.get('/api/auth/line/start', (_req, res) => {
  const c = configOr503(res);
  if (!c) return;
  const { state, nonce, token } = S.issueOAuthState({ secret: c.secret });
  res.append('Set-Cookie', S.cookieString(S.OAUTH_STATE_COOKIE, token, { maxAgeMs: S.STATE_TTL_MS }));
  return res.redirect(302, L.buildAuthorizeUrl({ ...c.cfg, state, nonce }));
});

router.get('/api/auth/line/callback', async (req, res) => {
  const c = configOr503(res);
  if (!c) return;
  const cookies = S.parseCookies(req.headers.cookie);
  const st = S.readOAuthState(cookies[S.OAUTH_STATE_COOKIE], c.secret);
  const state = typeof req.query.state === 'string' ? req.query.state : '';
  if (!st || st.state !== state) return res.status(401).json({ error: 'state_mismatch' });
  const code = typeof req.query.code === 'string' ? req.query.code : '';
  try {
    const tok = await L.exchangeCode({ code, cfg: c.cfg });
    const who = await L.verifyIdToken({
      idToken: tok.id_token, cfg: c.cfg, expectedNonce: st.nonce,
    });
    const uid = await L.resolveOrCreateUser({
      lineUid: who.lineUid, displayName: who.displayName, db,
    });
    const sid = S.issueSession({ uid, lineUid: who.lineUid, secret: c.secret, ttlMs: sessionTtl() });
    res.append('Set-Cookie', S.cookieString(S.SESSION_COOKIE, sid, { maxAgeMs: sessionTtl() }));
    res.append('Set-Cookie', S.clearCookieString(S.OAUTH_STATE_COOKIE));
    return res.redirect(302, landingUrl());
  } catch (err) {
    return errorResponse(res, err);
  }
});

// LIFF 內：liff.getIDToken() → 換 session cookie。之後所有 /api/transfer/* 走 cookie。
router.post('/api/auth/line/session', liffCors, async (req, res) => {
  const c = configOr503(res);
  if (!c) return;
  const idToken = typeof req.body?.idToken === 'string' ? req.body.idToken : '';
  try {
    const who = await L.verifyIdToken({ idToken, cfg: c.cfg });
    const uid = await L.resolveOrCreateUser({
      lineUid: who.lineUid, displayName: who.displayName, db,
    });
    const sid = S.issueSession({ uid, lineUid: who.lineUid, secret: c.secret, ttlMs: sessionTtl() });
    res.append('Set-Cookie', S.cookieString(S.SESSION_COOKIE, sid, { maxAgeMs: sessionTtl() }));
    return res.json({ ok: true, userId: uid });
  } catch (err) {
    return errorResponse(res, err);
  }
});

router.get('/api/auth/me', S.requireSession, (req, res) => {
  res.json({ ok: true, userId: req.userId, lineUid: req.session.lineUid || null });
});

router.post('/api/auth/logout', (_req, res) => {
  res.append('Set-Cookie', S.clearCookieString(S.SESSION_COOKIE));
  return res.json({ ok: true });
});

module.exports = router;
