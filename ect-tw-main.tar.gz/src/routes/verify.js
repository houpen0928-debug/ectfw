'use strict';
// 門市核銷台 API：券碼查券 + 五個狀態機動作，全部複用 src/engine/tickets.js。
// 安全：X-Verify-Key 定時常數比對 + 發行人隔離（A 廠商的核銷台查不到／核不了 B 廠商的券）。
// 法遵：無「到期」語義；GRACE 只代表優惠期間結束，價值完整保留。
const crypto = require('node:crypto');
const express = require('express');
const { query, withTransaction } = require('../../db');
const T = require('../engine/tickets');
const DYN = require('../engine/dynamicCode');
const invoice = require('../engine/invoice');
const COPY = require('../../config/copy');

const router = express.Router();

function constantTimeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || !a || !b) return false;
  const x = Buffer.from(a, 'utf8');
  const y = Buffer.from(b, 'utf8');
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function cleanText(v, max = 64) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);
}

// 純函式，供單元測試直接驗證（不依賴 express）
function checkVerifyHeaders(headers = {}, env = process.env) {
  const key = env.ECT_VERIFY_KEY;
  if (!key) return { ok: false, status: 503, error: 'VERIFY_KEY_UNSET' };
  if (!constantTimeEqual(String(headers['x-verify-key'] || ''), String(key))) {
    return { ok: false, status: 401, error: 'unauthorized' };
  }
  const vendorId = Number(env.ECT_VERIFY_VENDOR_ID || 0);
  if (!Number.isInteger(vendorId) || vendorId < 1) {
    return { ok: false, status: 503, error: 'VERIFY_VENDOR_UNSET' };
  }
  return { ok: true, vendorId, staff: cleanText(headers['x-verify-staff']) || 'staff' };
}

function verifyGate(req, res, next) {
  const c = checkVerifyHeaders(req.headers);
  if (!c.ok) return res.status(c.status).json({ error: c.error });
  req.verify = c;
  return next();
}

function adminGate(req, res, next) {
  const token = process.env.ECT_ADMIN_TOKEN;
  if (!token) return res.status(503).json({ error: 'ADMIN_TOKEN_UNSET' });
  if (!constantTimeEqual(String(req.get('X-Admin-Token') || ''), String(token))) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  return next();
}

const actorOf = (req) => `verify:${req.verify.vendorId}:${req.verify.staff}`;

async function assertTicketVendor(ticketId, vendorId) {
  const id = Number(ticketId);
  if (!Number.isInteger(id) || id <= 0) throw new T.EngineError('BAD_TICKET_ID', 'bad ticket id');
  const r = await query(
    `SELECT p.vendor_id FROM tickets t
     JOIN batches b ON b.id=t.batch_id JOIN products p ON p.id=b.product_id
     WHERE t.id=$1`,
    [id]
  );
  if (!r.rowCount) throw new T.EngineError('TICKET_NOT_FOUND', 'ticket not found');
  if (Number(r.rows[0].vendor_id) !== Number(vendorId)) {
    throw new T.EngineError('VENDOR_MISMATCH', 'ticket belongs to another issuer');
  }
  return id;
}

// 公開設定：前端先載入文案與開立點；不含任何憑證
router.get('/api/verify/config', (_req, res) => {
  res.json({
    title: COPY.verify.title,
    entity: COPY.entity.name,
    states: T.STATES,
    actions: T.ACTIONS,
    issuePoint: invoice.issuePoint(),
    provider: invoice.configFromEnv().provider,
    version: '0.4.0-m1',
    copy: {
      alwaysValid: COPY.ticket.alwaysValid,
      residualKept: COPY.ticket.residualKept,
      graceEnded: COPY.ticket.graceEnded,
      noCashout: COPY.points.noCashout,
      invoicePending: COPY.invoice.pending,
      invoiceNote: COPY.invoice.issuePointPending,
      donateHint: COPY.charity.donateCode,
    },
  });
});

// 查券：唯讀，不上寫鎖
router.post('/api/verify/lookup', verifyGate, async (req, res) => {
  try {
    const tk = await withTransaction((client) =>
      DYN.resolveTicketForVerify(client, req.body?.code, req.verify.vendorId, { lock: false }));
    return res.json({ ok: true, ticket: tk, invoice: await invoice.getInvoiceByTicket(Number(tk.id)) });
  } catch (err) {
    const known = err instanceof T.EngineError;
    return res.status(known ? 409 : 500).json({
      ok: false, error: known ? err.code : 'INTERNAL_ERROR', message: err.message,
    });
  }
});

/** 統一動作包裝：查券(含發行人隔離) → 狀態機動作 → 留軌；拒絕也留軌。 */
async function runAction(req, res, action, handler) {
  let ticketId = null;
  try {
    const out = await withTransaction(async (client) => {
      const tk = await DYN.resolveTicketForVerify(client, req.body?.code, req.verify.vendorId);
      ticketId = Number(tk.id);
      const result = await handler(client, tk, req.body || {});
      await client.query(
        `INSERT INTO verify_operations(ticket_id, vendor_id, staff, action, amount_cents, result, detail)
         VALUES($1,$2,$3,$4,$5,'OK',$6)`,
        [ticketId, req.verify.vendorId, req.verify.staff, action,
          result.amountCents == null ? null : Number(result.amountCents),
          JSON.stringify(result).slice(0, 500)]
      );
      return result;
    });
    if (out.invoiceId) invoice.fireInvoice(out.invoiceId); // commit 後才開立，失敗記 outbox
    return res.json({ ok: true, action, ...out });
  } catch (err) {
    const known = err instanceof T.EngineError;
    const code = known ? err.code : 'INTERNAL_ERROR';
    if (ticketId) {
      query(
        `INSERT INTO verify_operations(ticket_id, vendor_id, staff, action, amount_cents, result, detail)
         VALUES($1,$2,$3,$4,$5,'REJECTED',$6)`,
        [ticketId, req.verify.vendorId, req.verify.staff, action,
          Number(req.body?.amountCents) || null, code]
      ).catch(() => {});
    }
    return res.status(known ? 409 : 500).json({ ok: false, error: code, message: err.message });
  }
}

// 核銷（可部分）：金額以「分」為整數；不給金額時預設用完整剩餘價值
router.post('/api/verify/redeem', verifyGate, (req, res) =>
  runAction(req, res, 'REDEEM', async (client, tk, body) => {
    const amt = body.amountCents == null ? tk.residual_cents : Number(body.amountCents);
    if (!Number.isInteger(amt) || amt <= 0) throw new T.EngineError('BAD_AMOUNT', '金額須為正整數（分）');
    if (amt > tk.residual_cents) throw new T.EngineError('AMOUNT_EXCEEDS_RESIDUAL', '金額超過剩餘價值');
    const out = await T.redeemTicket(client, tk.id, amt, actorOf(req));

    // 發票（開立點 REDEEM 時才生效）：ref 帶核銷前殘值 → 多次部分核銷各開一張，重送不重複
    let invoiceId = null;
    try {
      const inv = await invoice.maybeEnqueue(client, 'REDEEM', {
        ref: `R${tk.id}X${tk.residual_cents}`,
        ticketId: tk.id, vendorId: tk.vendor_id, amountCents: amt,
        itemName: tk.product_name || 'ECT-TW 票券',
        carrierId: body.carrierId, donateCode: body.donateCode,
        buyerUnifiedNo: body.buyerUnifiedNo,
      });
      invoiceId = inv ? inv.id : null;
    } catch (_) { /* fail-safe：發票異常不回滾核銷 */ }
    return { ...out, amountCents: amt, invoiceId };
  }));

// 優惠期間結束（價值一分不減）
router.post('/api/verify/grace', verifyGate, (req, res) =>
  runAction(req, res, 'GRACE_ENTER', (client, tk) =>
    T.graceEnter(client, tk.id, actorOf(req))));

// 剩餘價值轉點數：持有人只取券本身的 owner，不接受客戶端指定 userId（防轉到他人帳戶）
router.post('/api/verify/convert', verifyGate, (req, res) =>
  runAction(req, res, 'CONVERT', (client, tk) => {
    const uid = Number(tk.owner_user_id);
    if (!Number.isInteger(uid) || uid <= 0) {
      throw new T.EngineError('OWNER_REQUIRED', '票券尚未歸戶，無法轉為點數');
    }
    return T.convertToPoints(client, tk.id, uid);
  }));

// 剩餘價值轉公益：partnerId 需為已登錄的合作團體（由 donateToCharity 查核）
router.post('/api/verify/donate', verifyGate, (req, res) =>
  runAction(req, res, 'DONATE', (client, tk, body) => {
    const pid = Number(body.partnerId || process.env.ECT_VERIFY_DEFAULT_PARTNER_ID || 0);
    if (!Number.isInteger(pid) || pid <= 0) {
      throw new T.EngineError('PARTNER_REQUIRED', '請指定合作公益團體');
    }
    return T.donateToCharity(client, tk.id, pid, tk.owner_user_id || null);
  }));

router.get('/api/verify/partners', verifyGate, async (_req, res) => {
  try {
    const r = await query('SELECT id, name, donate_code FROM charity_partners ORDER BY name');
    return res.json({ ok: true, partners: r.rows });
  } catch (err) {
    return res.status(500).json({ ok: false, error: 'INTERNAL_ERROR', message: err.message });
  }
});

router.get('/api/verify/journal/:ticketId', verifyGate, async (req, res) => {
  try {
    const id = await assertTicketVendor(req.params.ticketId, req.verify.vendorId);
    const r = await query(
      `SELECT action, actor, payload, created_at FROM ticket_chain
       WHERE ticket_id=$1 ORDER BY created_at, id`,
      [id]
    );
    return res.json({ ok: true, journal: r.rows });
  } catch (err) {
    const known = err instanceof T.EngineError;
    return res.status(known ? 409 : 500).json({ ok: false, error: known ? err.code : 'INTERNAL_ERROR' });
  }
});

router.get('/api/verify/invoice/:ticketId', verifyGate, async (req, res) => {
  try {
    const id = await assertTicketVendor(req.params.ticketId, req.verify.vendorId);
    return res.json({ ok: true, invoice: await invoice.getInvoiceByTicket(id) });
  } catch (err) {
    const known = err instanceof T.EngineError;
    return res.status(known ? 409 : 500).json({ ok: false, error: known ? err.code : 'INTERNAL_ERROR' });
  }
});

// ---- 管理端：發票監控與補開 ----
router.get('/api/admin/invoices', adminGate, async (req, res) => {
  try {
    const status = cleanText(req.query.status, 16);
    const r = status
      ? await query(
          `SELECT * FROM invoices WHERE status=$1 ORDER BY created_at DESC LIMIT 100`, [status])
      : await query(`SELECT * FROM invoices ORDER BY created_at DESC LIMIT 100`);
    const m = await query('SELECT * FROM invoice_monitor');
    return res.json({ ok: true, invoices: r.rows, monitor: m.rows[0] || null });
  } catch (err) {
    return res.status(500).json({ ok: false, error: 'INTERNAL_ERROR', message: err.message });
  }
});

router.post('/api/admin/invoices/retry', adminGate, async (req, res) => {
  try {
    const results = await invoice.retryPending(req.body?.limit);
    return res.json({ ok: true, results });
  } catch (err) {
    return res.status(500).json({ ok: false, error: 'INTERNAL_ERROR', message: err.message });
  }
});

module.exports = router;
module.exports.checkVerifyHeaders = checkVerifyHeaders;
module.exports.constantTimeEqual = constantTimeEqual;
module.exports.adminGate = adminGate;
