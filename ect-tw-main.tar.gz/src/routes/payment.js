'use strict';
// 訂單 + 藍新 callback 路由
// 收款紅線：僅 PLATFORM_FEE 訂單走平台藍新商店代號；券貨款（TICKET_SALE）走廠商信託專戶。
const express = require('express');
const { query } = require('../../db');
const {
  configFromEnv, merchantOrderNo, createMpgForm, parseFormBody,
} = require('../payments/newebpay');
const { settleNotify } = require('../engine/payment');
const invoice = require('../engine/invoice');
const COPY = require('../../config/copy');

const router = express.Router();

// 回呼只用自解析 form-urlencoded：不依賴 multipart，藍新 server-to-server 不帶 Origin
const rawForm = express.text({ type: () => true, limit: '64kb' });

function adminGate(req, res, next) {
  const token = process.env.ECT_ADMIN_TOKEN;
  if (!token) return res.status(503).json({ error: 'ADMIN_TOKEN_UNSET' });
  if (req.get('X-Admin-Token') !== token) return res.status(401).json({ error: 'unauthorized' });
  return next();
}

// 建立訂單（金額由 DB 的 product 決定，不接受客戶端傳金額 → 防竄改）
router.post('/api/orders', adminGate, async (req, res, next) => {
  try {
    const { productId, userId = null, qty = 1, feeScope = 'PLATFORM_FEE' } = req.body || {};
    if (!Number.isInteger(productId) || !Number.isInteger(qty) || qty < 1) {
      return res.status(400).json({ error: 'BAD_INPUT' });
    }
    if (!['PLATFORM_FEE', 'TICKET_SALE'].includes(feeScope)) {
      return res.status(400).json({ error: 'BAD_FEE_SCOPE' });
    }
    const p = await query(
      `SELECT id, vendor_id, face_value_cents, status, name FROM products WHERE id=$1`,
      [productId]
    );
    if (!p.rowCount) return res.status(404).json({ error: 'PRODUCT_NOT_FOUND' });
    if (p.rows[0].status !== 'ACTIVE') return res.status(409).json({ error: 'PRODUCT_NOT_ACTIVE' });
    const product = p.rows[0];
    const amountCents = Number(product.face_value_cents) * qty;
    const orderNo = merchantOrderNo('ECT');

    await query(
      `INSERT INTO orders(order_no, user_id, product_id, vendor_id, qty, amount_cents, fee_scope, status)
       VALUES($1,$2,$3,$4,$5,$6,$7,'PENDING')`,
      [orderNo, userId, productId, product.vendor_id, qty, amountCents, feeScope]
    );

    // 券貨款不經平台：只回訂單，不產生藍新表單
    if (feeScope === 'TICKET_SALE') {
      return res.status(201).json({
        orderNo, amountCents, feeScope,
        settlement: COPY.payment.trustSettlement,
        note: '券貨款直接進發行人信託專戶，平台不代收代付；待法遵意見書確認憑證流程',
      });
    }

    const cfg = configFromEnv();
    let form = null;
    try {
      form = createMpgForm(
        { merchantOrderNo: orderNo, amountCents, itemDesc: product.name.slice(0, 50) }, cfg
      );
    } catch (err) {
      // fail-closed：金鑰未設定不阻塞建單，但明確回報尚不可付款
      return res.status(201).json({
        orderNo, amountCents, feeScope, payable: false, reason: err.message,
      });
    }
    return res.status(201).json({
      orderNo, amountCents, feeScope, payable: true,
      action: form.action, fields: form.fields,
    });
  } catch (err) {
    return next(err);
  }
});

router.get('/api/orders/:orderNo', adminGate, async (req, res, next) => {
  try {
    const o = await query(
      `SELECT order_no, qty, amount_cents, fee_scope, status, created_at, fulfilled_at
       FROM orders WHERE order_no=$1`,
      [req.params.orderNo]
    );
    if (!o.rowCount) return res.status(404).json({ error: 'ORDER_NOT_FOUND' });
    const t = await query(
      `SELECT count(*)::int AS tickets,
              coalesce(sum(residual_cents),0)::bigint AS residual
       FROM tickets t JOIN orders o ON o.id=t.order_id WHERE o.order_no=$1`,
      [req.params.orderNo]
    );
    return res.json({ order: o.rows[0], tickets: t.rows[0] });
  } catch (err) {
    return next(err);
  }
});

// 背景通知：唯一入帳依據（驗簽／解密／金額比對／冪等／原子發券）
router.post('/pay/newebpay/notify', rawForm, async (req, res) => {
  const form = parseFormBody(req.body);
  try {
    const r = await settleNotify(form, configFromEnv());
    // 交易已 commit 才非阻塞開立發票；失敗記 outbox，不影響回呼結果
    if (r.invoiceId) invoice.fireInvoice(r.invoiceId);
    // 藍新不要求特定回應；非成功也回 200 讓藍新停止重送，詳細原因記在 payment_events
    return res.type('text/plain').send(r.ok ? 'OK' : `REJECT:${r.reason}`);
  } catch (err) {
    console.error('[newebpay:notify]', err.message);
    return res.status(500).type('text/plain').send('ERROR');
  }
});

// 前景導回：只顯示結果、不入帳（避免與背景通知重複發券）
router.post('/pay/newebpay/return', rawForm, (req, res) => {
  const form = parseFormBody(req.body);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
  const status = esc(form.Status);
  res.type('html').send(
    `<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><title>付款結果</title>` +
    `<body><h1>${status === 'SUCCESS' ? '付款完成' : '付款未完成'}</h1>` +
    `<p>${COPY.payment.returnHint}</p></body></html>`
  );
});

// 對帳查詢：交易留痕 + 事件軌跡
router.get('/api/admin/payments/:orderNo', adminGate, async (req, res, next) => {
  try {
    const txn = await query(
      `SELECT merchant_order_no, trade_no, amt_cents, status, pay_time
       FROM newebpay_txn WHERE merchant_order_no=$1`,
      [req.params.orderNo]
    );
    const evts = await query(
      `SELECT event, detail, created_at FROM payment_events
       WHERE order_no=$1 ORDER BY created_at, id`,
      [req.params.orderNo]
    );
    return res.json({ txn: txn.rows, events: evts.rows });
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
module.exports.adminGate = adminGate;
module.exports.rawForm = rawForm;
