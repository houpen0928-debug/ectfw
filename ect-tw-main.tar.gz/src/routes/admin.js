'use strict';
// 後台總覽：法遵儀表置頂（代收未付餘額／零殘值違規／點數守恆），再給營運 KPI。
// 全部為固定常數查詢、無任何使用者輸入，故單一 SQL 以 scalar subquery 一次取回；
// ::int / ::bigint 明確轉型，避免 PG BIGINT 被 node-postgres 轉成字串污染前端數字。
const express = require('express');
const { query } = require('../../db');
const { adminGate } = require('./verify');
const { VERSION } = require('./public');

const router = express.Router();

const OVERVIEW_SQL = `SELECT
  (SELECT count(*) FROM tickets)::int                                   AS tickets,
  (SELECT count(*) FROM tickets WHERE state = 'UNBOUND')::int          AS unbound,
  (SELECT count(*) FROM vendors WHERE status = 'ACTIVE')::int          AS vendors,
  (SELECT count(*) FROM products WHERE status = 'ACTIVE')::int         AS products,
  (SELECT count(*) FROM orders WHERE status IN ('PAID','FULFILLED'))::int AS orders_paid,
  (SELECT count(*) FROM verify_operations)::int                        AS verify_ops,
  (SELECT payable_cents FROM payables_monitor)::bigint                 AS payable_cents,
  (SELECT pending_count FROM payables_monitor)::int                    AS payable_pending,
  (SELECT zero_residual_violations FROM residual_monitor)::int        AS zero_residual_violations,
  (SELECT live_count FROM residual_monitor)::int                       AS live_tickets,
  (SELECT drift_cents FROM points_conservation)::bigint                AS points_drift_cents,
  (SELECT pending_count FROM invoice_monitor)::int                     AS invoice_pending,
  (SELECT failed_count FROM invoice_monitor)::int                      AS invoice_failed,
  (SELECT issued_count FROM invoice_monitor)::int                      AS invoice_issued`;

// 純函式：把 DB 列轉成前端欄位並強制數值型別，便於單元測試
function shapeOverview(row = {}) {
  const n = (v) => Number(v || 0);
  return {
    kpi: {
      tickets: n(row.tickets),
      unbound: n(row.unbound),
      vendors: n(row.vendors),
      products: n(row.products),
      ordersPaid: n(row.orders_paid),
      verifyOps: n(row.verify_ops),
    },
    compliance: {
      payableCents: n(row.payable_cents),
      payablePending: n(row.payable_pending),
      zeroResidualViolations: n(row.zero_residual_violations),
      liveTickets: n(row.live_tickets),
      pointsDriftCents: n(row.points_drift_cents),
    },
    invoice: {
      pending: n(row.invoice_pending),
      failed: n(row.invoice_failed),
      issued: n(row.invoice_issued),
    },
  };
}

router.get('/api/admin/overview', adminGate, async (_req, res) => {
  try {
    const r = await query(OVERVIEW_SQL);
    return res.json({
      ok: true,
      version: VERSION,
      generatedAt: new Date().toISOString(),
      ...shapeOverview(r.rows[0]),
    });
  } catch (err) {
    return res.status(503).json({ ok: false, error: 'DB_UNAVAILABLE', message: err.message });
  }
});

module.exports = router;
module.exports.OVERVIEW_SQL = OVERVIEW_SQL;
module.exports.shapeOverview = shapeOverview;
