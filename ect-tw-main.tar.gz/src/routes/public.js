'use strict';
// 官網公開文案端點：前端所有法遵語句的唯一來源。
// 前端以 data-copy="ticket.alwaysValid" 標註，並由 tests/site.test.js 與 COPY 自動對撞，
// 避免 HTML 內的 fallback 文案與 config/copy.js 漂移（洪哥鐵律：文件內容要能自動對撞）。
const express = require('express');
const COPY = require('../../config/copy');

const VERSION = '0.4.0-m1';

// 純函式，方便單元測試直接驗證；只輸出對外文案，不含任何憑證或環境變數敏感值
function buildSiteConfig(copy = COPY) {
  return {
    version: VERSION,
    entity: copy.entity.name,
    copy: {
      // 平台營運主體為公開登記資料（非憑證），頁尾以 data-copy="entity.*" 對撞並可被本端點覆寫
      entity: copy.entity,
      ticket: copy.ticket,
      points: copy.points,
      charity: copy.charity,
      refund: copy.refund,
      payment: copy.payment,
      verify: copy.verify,
      invoice: copy.invoice,
      web: copy.web,
      admin: copy.admin,
      esg: copy.esg,
    },
  };
}

const router = express.Router();

router.get('/api/public/site', (_req, res) => {
  res.set('Cache-Control', 'public, max-age=60');
  res.json(buildSiteConfig());
});

module.exports = router;
module.exports.buildSiteConfig = buildSiteConfig;
module.exports.VERSION = VERSION;
