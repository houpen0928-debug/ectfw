'use strict';
// 用戶端轉贈 API（M2 批次A）：發起 / 領取 / 取消 + 動態碼簽發（LIFF 前端畫 QR 用）。
// 身分：X-User-Id 為開發期門禁（批次B 換 LINE Login session 後廢棄此 header）。
// 紀律：token 與新券碼明文都只在回應中出現一次，DB 只存雜湊。
const express = require('express');
const { query, withTransaction } = require('../../db');
const T = require('../engine/tickets');
const transfer = require('../engine/transfer');
const dyn = require('../engine/dynamicCode');

const router = express.Router();

function userGate(req, res, next) {
  const uid = Number(req.get('x-user-id'));
  if (!Number.isInteger(uid) || uid <= 0) return res.status(401).json({ error: 'unauthorized' });
  req.userId = uid;
  return next();
}

function sendResult(res, out) {
  return res.json({ ok: true, ...out });
}

function handleError(res, err) {
  const known = err instanceof T.EngineError;
  return res.status(known ? 409 : 500).json({
    ok: false, error: known ? err.code : 'INTERNAL_ERROR', message: err.message,
  });
}

// 發起轉贈：回傳一次性領取 token（24h 內有效；新 token 會自動作廢同券舊 PENDING token）
router.post('/api/transfer/create', userGate, async (req, res) => {
  try {
    const ticketId = Number(req.body?.ticketId);
    if (!Number.isInteger(ticketId) || ticketId <= 0) {
      throw new T.EngineError('BAD_TICKET_ID', 'ticketId must be a positive integer');
    }
    const out = await transfer.tx.create(ticketId, req.userId);
    return sendResult(res, out);
  } catch (err) {
    return handleError(res, err);
  }
});

// 領取：單次消費；成功即過戶並回傳重簽後的新券碼（僅此一次）
router.post('/api/transfer/claim', userGate, async (req, res) => {
  try {
    const out = await transfer.tx.claim(String(req.body?.token || ''), req.userId);
    return sendResult(res, out);
  } catch (err) {
    return handleError(res, err);
  }
});

// 取消：僅發起人本人
router.post('/api/transfer/cancel', userGate, async (req, res) => {
  try {
    const out = await transfer.tx.cancel(String(req.body?.token || ''), req.userId);
    return sendResult(res, out);
  } catch (err) {
    return handleError(res, err);
  }
});

// 動態碼簽發：持有人即時出示（60 秒輪換）；非持有人 / 終態券一律拒
router.post('/api/transfer/dynamic-code', userGate, async (req, res) => {
  try {
    const ticketId = Number(req.body?.ticketId);
    if (!Number.isInteger(ticketId) || ticketId <= 0) {
      throw new T.EngineError('BAD_TICKET_ID', 'ticketId must be a positive integer');
    }
    const tk = await withTransaction((client) => T.findTicketById(client, ticketId, null, { lock: false }));
    if (tk.owner_user_id == null || Number(tk.owner_user_id) !== req.userId) {
      throw new T.EngineError('NOT_OWNER', 'ticket belongs to another user');
    }
    if (T.TERMINAL.has(tk.state)) {
      throw new T.EngineError('TERMINAL_STATE', 'ticket is already closed');
    }
    const code = dyn.issueDynamicCode({
      ticketId, codeSeq: tk.code_seq, secret: dyn.secretFromEnv(),
    });
    return sendResult(res, { ticketId, state: tk.state, code, windowMs: dyn.WINDOW_MS });
  } catch (err) {
    return handleError(res, err);
  }
});

module.exports = router;
module.exports.userGate = userGate;
