'use strict';
// 藍新 NewebPay（MPG / NDNF）工具層 — 依 選我科技《藍新金流申請與嵌入 SOP》v1.0 §四 與
// 《藍新金流嵌入-實作與上線說明》v2 §四 實作，非網路二手資料。
//
// 規格錨點：
//   TradeInfo = AES-256-CBC(queryString, HashKey, HashIV) + PKCS7 → 小寫 hex
//   TradeSha  = SHA256("HashKey={k}&{TradeInfo}&HashIV={iv}") → 大寫 hex
//   外層 5 欄：MerchantID / TradeInfo / TradeSha / Version=2.0 / EncryptType=0
//   MerchantOrderNo ≤30 英數（尾加 5 碼隨機防撞號）；NotifyURL/ReturnURL 僅 80/443
//   背景通知 NotifyURL 為唯一入帳依據；回呼自解析 form-urlencoded，不依賴 multipart
const crypto = require('node:crypto');

const HOSTS = Object.freeze({
  sandbox: 'https://ccore.newebpay.com/MPG/mpg_gateway',
  production: 'https://core.newebpay.com/MPG/mpg_gateway',
});

function configFromEnv(env = process.env) {
  return {
    merchantId: env.NEWEBPAY_MERCHANT_ID || '',
    hashKey: env.NEWEBPAY_HASH_KEY || '',
    hashIV: env.NEWEBPAY_HASH_IV || '',
    enabled: env.NEWEBPAY_ENABLED === '1',
    sandbox: env.NEWEBPAY_SANDBOX !== '0',
    returnURL: env.NEWEBPAY_RETURN_URL || '',
    notifyURL: env.NEWEBPAY_NOTIFY_URL || '',
    clientBackURL: env.NEWEBPAY_CLIENT_BACK_URL || '',
  };
}

// fail-closed：金鑰缺失/長度錯/未啟用 一律拒絕，不產生可送出的表單
// 註：SOP 踩雷表 #7 記「HashKey 16/24/32 皆可」是 Python cryptography 動態 AES 的規則；
//     Node 'aes-256-cbc' 固定 32 bytes key、16 bytes IV。藍新正式區 HashKey 本為 32 碼，實務一致。
function assertConfig(cfg) {
  if (!cfg.enabled) throw new Error('NEWEBPAY_DISABLED');
  if (!cfg.merchantId) throw new Error('BAD_MERCHANT_ID');
  if (Buffer.byteLength(cfg.hashKey, 'utf8') !== 32) throw new Error('BAD_HASH_KEY');
  if (Buffer.byteLength(cfg.hashIV, 'utf8') !== 16) throw new Error('BAD_HASH_IV');
  return cfg;
}

function buildQuery(params) {
  return Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join('&');
}

function parseQuery(qs) {
  const out = {};
  for (const pair of String(qs).split('&')) {
    if (!pair) continue;
    const i = pair.indexOf('=');
    const k = i < 0 ? pair : pair.slice(0, i);
    const v = i < 0 ? '' : pair.slice(i + 1);
    try {
      out[decodeURIComponent(k.replace(/\+/g, ' '))] = decodeURIComponent(v.replace(/\+/g, ' '));
    } catch (_) {
      out[k] = v;
    }
  }
  return out;
}

// AES-256-CBC + PKCS7（Node 預設 autoPadding，與藍新官方 PHP openssl_encrypt 一致）→ 小寫 hex
function encryptTradeInfo(params, hashKey, hashIV) {
  const qs = typeof params === 'string' ? params : buildQuery(params);
  const cipher = crypto.createCipheriv(
    'aes-256-cbc', Buffer.from(hashKey, 'utf8'), Buffer.from(hashIV, 'utf8')
  );
  return cipher.update(qs, 'utf8', 'hex') + cipher.final('hex');
}

function decryptTradeInfo(hex, hashKey, hashIV) {
  if (typeof hex !== 'string' || !/^[0-9a-fA-F]+$/.test(hex) || hex.length % 32 !== 0) {
    throw new Error('BAD_TRADEINFO_HEX');
  }
  const decipher = crypto.createDecipheriv(
    'aes-256-cbc', Buffer.from(hashKey, 'utf8'), Buffer.from(hashIV, 'utf8')
  );
  const qs = decipher.update(hex, 'hex', 'utf8') + decipher.final('utf8');
  return parseQuery(qs);
}

function buildTradeSha(tradeInfo, hashKey, hashIV) {
  return crypto
    .createHash('sha256')
    .update(`HashKey=${hashKey}&${tradeInfo}&HashIV=${hashIV}`)
    .digest('hex')
    .toUpperCase();
}

// 定時常數比較，防時序攻擊
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const x = Buffer.from(a.toUpperCase());
  const y = Buffer.from(b.toUpperCase());
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function verifyTradeSha(tradeInfo, tradeSha, hashKey, hashIV) {
  if (!tradeSha) return false;
  return safeEqual(buildTradeSha(tradeInfo, hashKey, hashIV), tradeSha);
}

// MerchantOrderNo ≤30 英數，尾加 5 碼隨機避免同秒撞號
function merchantOrderNo(prefix = 'ECT', now = Date.now()) {
  const base = String(prefix).replace(/[^A-Za-z0-9]/g, '').slice(0, 12) || 'ECT';
  const stamp = String(Math.floor(now / 1000)).slice(-10);
  const rand = crypto.randomInt(0, 100000).toString().padStart(5, '0');
  return `${base}${stamp}${rand}`.slice(0, 30);
}

function twTimestamp(now = Date.now()) {
  return String(Math.floor(now / 1000));
}

// 產生 MPG 幕前表單（外層 5 欄）。Amt 單位為「元」整數；呼叫端以 cents/100 傳入。
function createMpgForm(order, cfg) {
  assertConfig(cfg);
  const amt = Math.round(Number(order.amountCents) / 100);
  if (!Number.isInteger(amt) || amt <= 0) throw new Error('BAD_AMOUNT');
  if (order.merchantOrderNo && !/^[A-Za-z0-9]{1,30}$/.test(order.merchantOrderNo)) {
    throw new Error('BAD_MERCHANT_ORDER_NO');
  }
  const inner = {
    MerchantID: cfg.merchantId,
    RespondType: 'JSON',
    TimeStamp: twTimestamp(),
    Version: '2.0',
    MerchantOrderNo: order.merchantOrderNo || merchantOrderNo('ECT'),
    Amt: amt,
    ItemDesc: order.itemDesc || 'TWECT 平台服務',
    ReturnURL: order.returnURL || cfg.returnURL,
    NotifyURL: order.notifyURL || cfg.notifyURL,
    ClientBackURL: order.clientBackURL || cfg.clientBackURL,
    Email: order.email || '',
    LoginType: 0,
    CREDIT: 1,
  };
  if (!inner.NotifyURL) throw new Error('NOTIFY_URL_REQUIRED');
  const TradeInfo = encryptTradeInfo(inner, cfg.hashKey, cfg.hashIV);
  const TradeSha = buildTradeSha(TradeInfo, cfg.hashKey, cfg.hashIV);
  return {
    action: cfg.sandbox ? HOSTS.sandbox : HOSTS.production,
    fields: {
      MerchantID: cfg.merchantId,
      TradeInfo,
      TradeSha,
      Version: '2.0',
      EncryptType: '0',
    },
    inner,
  };
}

// 回呼解析：驗證 TradeSha → 解密 TradeInfo。回 { ok, reason, outer, result }
function parseNotify(form, cfg) {
  const outer = {
    Status: form.Status,
    MerchantID: form.MerchantID,
    TradeInfo: form.TradeInfo,
    TradeSha: form.TradeSha,
    Version: form.Version,
  };
  if (!cfg.enabled) return { ok: false, reason: 'FAIL_CLOSED', outer };
  // 金鑰組態不合法時明確拒絕，不讓底層 crypto 拋出難以判讀的例外
  if (Buffer.byteLength(cfg.hashKey || '', 'utf8') !== 32 ||
      Buffer.byteLength(cfg.hashIV || '', 'utf8') !== 16) {
    return { ok: false, reason: 'BAD_KEY_CONFIG', outer };
  }
  if (outer.MerchantID !== cfg.merchantId) return { ok: false, reason: 'MERCHANT_ID_MISMATCH', outer };
  if (!outer.TradeInfo || !verifyTradeSha(outer.TradeInfo, outer.TradeSha, cfg.hashKey, cfg.hashIV)) {
    return { ok: false, reason: 'BAD_SIGNATURE', outer };
  }
  let result;
  try {
    result = decryptTradeInfo(outer.TradeInfo, cfg.hashKey, cfg.hashIV);
  } catch (_) {
    return { ok: false, reason: 'BAD_PAYLOAD', outer };
  }
  if (result.MerchantID && result.MerchantID !== cfg.merchantId) {
    return { ok: false, reason: 'INNER_MERCHANT_MISMATCH', outer, result };
  }
  return { ok: true, reason: 'OK', outer, result };
}

// 自解析 application/x-www-form-urlencoded（SOP §2.5：不依賴 multipart）
function parseFormBody(raw) {
  if (raw && typeof raw === 'object' && !Buffer.isBuffer(raw)) return raw;
  return parseQuery(typeof raw === 'string' ? raw : String(raw || ''));
}

module.exports = {
  HOSTS, configFromEnv, assertConfig, buildQuery, parseQuery,
  encryptTradeInfo, decryptTradeInfo, buildTradeSha, verifyTradeSha, safeEqual,
  merchantOrderNo, twTimestamp, createMpgForm, parseNotify, parseFormBody,
};
