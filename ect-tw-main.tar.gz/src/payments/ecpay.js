'use strict';
// 綠界 ECPay 串接樣板：CheckMacValue 產生／驗簽（AIO 金流 + 電子發票共用簽章規則）
// 規則：參數依 key 不分大小寫排序 → HashKey=..&k=v..&HashIV=.. → URL encode → 轉小寫
//       → .NET 相容字元還原 → SHA256 → 大寫十六進位
// ⚠️ M0 待辦：以綠界官方測試範例參數做一次外部交叉驗證（本檔目前僅自洽往返驗證）
const crypto = require('node:crypto');

function ecpayUrlEncode(value) {
  let s = encodeURIComponent(String(value)).toLowerCase();
  return s
    .replace(/%2d/g, '-')
    .replace(/%5f/g, '_')
    .replace(/%2e/g, '.')
    .replace(/%21/g, '!')
    .replace(/%2a/g, '*')
    .replace(/%28/g, '(')
    .replace(/%29/g, ')')
    .replace(/%7e/g, '~');
}

function sortKeys(a, b) {
  const la = a.toLowerCase();
  const lb = b.toLowerCase();
  return la < lb ? -1 : la > lb ? 1 : 0;
}

function buildCheckMacValue(params, hashKey, hashIV) {
  if (!hashKey || !hashIV) throw new Error('ECPAY_HASH_KEY / ECPAY_HASH_IV missing');
  const pairs = Object.keys(params)
    .filter((k) => k !== 'CheckMacValue')
    .sort(sortKeys)
    .map((k) => `${k}=${params[k]}`)
    .join('&');
  const raw = `HashKey=${hashKey}&${pairs}&HashIV=${hashIV}`;
  return crypto.createHash('sha256').update(ecpayUrlEncode(raw)).digest('hex').toUpperCase();
}

function verifyCheckMacValue(params, hashKey, hashIV) {
  const received = params.CheckMacValue;
  if (!received || typeof received !== 'string') return false;
  const expected = buildCheckMacValue(params, hashKey, hashIV);
  const a = Buffer.from(received.toUpperCase());
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// 台灣 UTC+8，無夏令時
function twStamp(date = new Date()) {
  return new Date(date.getTime() + 8 * 3600_000)
    .toISOString().replace('T', ' ').slice(0, 19).replace(/-/g, '/');
}

function createAioCheckout(order, cfg) {
  const params = {
    MerchantID: cfg.merchantId,
    MerchantTradeNo: order.merchantTradeNo,
    MerchantTradeDate: twStamp(),
    PaymentType: 'aio',
    TotalAmount: String(Math.round(order.totalCents / 100)),
    TradeDesc: 'ECT-TW 保底流通券',
    ItemName: order.itemName,
    ReturnURL: order.returnURL,
    ChoosePayment: order.choosePayment || 'ALL',
    ClientBackURL: order.clientBackURL || '',
    EncryptType: '1',
    NeedExtraPaidInfo: 'N',
  };
  params.CheckMacValue = buildCheckMacValue(params, cfg.hashKey, cfg.hashIV);
  return params;
}

function ecpayConfigFromEnv() {
  return {
    merchantId: process.env.ECPAY_MERCHANT_ID,
    hashKey: process.env.ECPAY_HASH_KEY,
    hashIV: process.env.ECPAY_HASH_IV,
    host: process.env.ECPAY_HOST || 'https://payment-stage.ecpay.com.tw',
  };
}

module.exports = {
  ecpayUrlEncode,
  buildCheckMacValue,
  verifyCheckMacValue,
  twStamp,
  createAioCheckout,
  ecpayConfigFromEnv,
};
