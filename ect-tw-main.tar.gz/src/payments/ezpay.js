'use strict';
// ECT-TW 電子發票閘道（M1 第二批）
//
// ⚠️ 誠實邊界：截至本版尚未取得 ezPay 電子發票官方技術文件，本檔「不自稱已串接」。
//    已落地：請求正規化（金額/稅額/載具/捐贈碼互斥）、AES 封裝、三通道、fail-closed、
//            回應容錯解析、冪等鍵、逾時控制。
//    待對齊：provider=ezpay 的欄位名 / Version / 路徑（拿到官方文件只改 toEzpayParams
//            與 parseIssueResponse 兩處），且 EZPAY_HOST 未設定時直接 fail-closed，不會誤送。
//    立即可用：stub（本機/CI）、http（接自建或任意加值中心 webhook，JSON 正規化請求）。
//
// 法遵：發票開立時點未經律師意見書確認（律師清單 C2），由 ECT_INVOICE_ISSUE_POINT 決定，
//       ORDER / REDEEM 兩處都埋 hook，切換不需改程式。金流與發票為兩套商店代號與金鑰。
const crypto = require('node:crypto');
const np = require('./newebpay');

const PROVIDERS = Object.freeze(['stub', 'http', 'ezpay']);
const ISSUE_POINTS = Object.freeze(['ORDER', 'REDEEM']);

function configFromEnv(env = process.env) {
  return {
    provider: String(env.ECT_INVOICE_PROVIDER || 'stub').toLowerCase(),
    issuePoint: String(env.ECT_INVOICE_ISSUE_POINT || 'ORDER').toUpperCase(),
    merchantId: env.EZPAY_MERCHANT_ID || '',
    hashKey: env.EZPAY_HASH_KEY || '',
    hashIV: env.EZPAY_HASH_IV || '',
    host: env.EZPAY_HOST || '',                 // provider=ezpay 必填（官方網域待文件確認）
    webhook: env.EZPAY_WEBHOOK || '',           // provider=http 必填
    webhookToken: env.EZPAY_WEBHOOK_TOKEN || '',
    timeoutMs: Number(env.ECT_INVOICE_TIMEOUT_MS || 3000),
  };
}

// fail-closed：組態不完整一律拒絕，不產生可送出的請求
function assertConfig(cfg) {
  if (!PROVIDERS.includes(cfg.provider)) throw new Error('BAD_PROVIDER');
  if (!ISSUE_POINTS.includes(cfg.issuePoint)) throw new Error('BAD_ISSUE_POINT');
  if (!Number.isInteger(cfg.timeoutMs) || cfg.timeoutMs < 100 || cfg.timeoutMs > 30000) {
    throw new Error('BAD_TIMEOUT');
  }
  if (cfg.provider === 'http' && !cfg.webhook) throw new Error('WEBHOOK_UNSET');
  if (cfg.provider === 'ezpay') {
    if (!cfg.host) throw new Error('EZPAY_HOST_UNSET');
    if (!cfg.merchantId) throw new Error('BAD_MERCHANT_ID');
    // Node aes-256-cbc 固定 32/16（與藍新同體系；見 newebpay.js assertConfig 說明）
    if (Buffer.byteLength(cfg.hashKey, 'utf8') !== 32) throw new Error('BAD_HASH_KEY');
    if (Buffer.byteLength(cfg.hashIV, 'utf8') !== 16) throw new Error('BAD_HASH_IV');
  }
  return cfg;
}

// 台灣統一發票以「元」為最小單位；庫存一律以「分」整數儲存，非整百元直接拒，避免稅額算錯
function toYuan(cents) {
  const n = Number(cents);
  if (!Number.isInteger(n) || n <= 0) throw new Error('BAD_AMOUNT');
  if (n % 100 !== 0) throw new Error('AMOUNT_NOT_WHOLE_YUAN');
  return n / 100;
}

// 定價內含 5% 營業稅：銷售額 = round(總額 / 1.05)，稅額 = 總額 - 銷售額
function splitTax(totalYuan) {
  if (!Number.isInteger(totalYuan) || totalYuan <= 0) throw new Error('BAD_AMOUNT');
  const salesAmt = Math.round(totalYuan / 1.05);
  const taxAmt = totalYuan - salesAmt;
  if (salesAmt <= 0 || taxAmt < 0) throw new Error('BAD_TAX_SPLIT');
  return { salesAmt, taxAmt, totalAmt: totalYuan };
}

function normalizeDonateCode(v) {
  if (v == null || String(v).trim() === '') return '';
  const s = String(v).trim();
  // 財政部捐贈碼為純數字（位數待官方文件覆核，先放寬 3–8 碼）
  if (!/^\d{3,8}$/.test(s)) throw new Error('BAD_DONATE_CODE');
  return s;
}

function normalizeCarrier(v) {
  if (v == null || String(v).trim() === '') return { type: '', id: '' };
  const s = String(v).trim();
  if (!/^[A-Za-z0-9+/=._-]{1,64}$/.test(s)) throw new Error('BAD_CARRIER_ID');
  return { type: 'MEMBER', id: s };
}

function cleanText(v, max = 60) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);
}

/**
 * 正規化為「與加值中心無關」的發票請求。
 * input: { orderNo, ticketId, vendorId, amountCents, itemName,
 *          buyerUnifiedNo, buyerName, carrierId, donateCode }
 * 法規鐵律：捐贈碼與載具互斥；有捐贈碼時強制清空載具。
 */
function buildInvoiceRequest(input = {}, cfg = configFromEnv()) {
  assertConfig(cfg);
  // ref 可由呼叫端指定（例：核銷多次時帶殘值，確保每次部分核銷各開一張、又不因重送重複開立）
  const ref = String(input.ref || input.orderNo || (input.ticketId != null ? `T${input.ticketId}` : ''))
    .replace(/[^A-Za-z0-9]/g, '').slice(0, 30);
  if (!ref) throw new Error('BAD_REF');
  const yuan = toYuan(input.amountCents);
  const tax = splitTax(yuan);
  const donateCode = normalizeDonateCode(input.donateCode);
  const carrier = donateCode ? { type: '', id: '' } : normalizeCarrier(input.carrierId);

  let buyerUnifiedNo = '';
  if (input.buyerUnifiedNo != null && String(input.buyerUnifiedNo).trim() !== '') {
    const ubn = String(input.buyerUnifiedNo).trim();
    if (!/^\d{8}$/.test(ubn)) throw new Error('BAD_BUYER_UBN');
    buyerUnifiedNo = ubn;
  }

  return {
    provider: cfg.provider,
    issuePoint: cfg.issuePoint,
    ref,
    idempotencyKey: `${cfg.issuePoint}:${ref}:ISSUE`,
    merchantOrderNo: ref,
    itemName: cleanText(input.itemName) || 'TWECT 票券',
    buyerName: cleanText(input.buyerName, 40),
    buyerUnifiedNo,
    carrierType: carrier.type,
    carrierId: carrier.id,
    donateCode,
    printFlag: donateCode || carrier.id ? '0' : '1',
    ...tax,                                  // salesAmt / taxAmt / totalAmt（元）
    amountCents: Number(input.amountCents), // 庫存原始金額（分）
    ticketId: input.ticketId == null ? null : Number(input.ticketId),
    vendorId: input.vendorId == null ? null : Number(input.vendorId),
    orderNo: input.orderNo || null,
  };
}

// 待對齊：ezPay 實際欄位名 / Version / 路徑以官方技術文件為準。
// host 未設定時 assertConfig 已 fail-closed，故本函式不會把猜測欄位送出。
function toEzpayParams(req, cfg) {
  return {
    MerchantID_: cfg.merchantId,
    MerchantOrderNo: req.merchantOrderNo,
    TotalAmt: req.totalAmt,
    AmtSales: req.salesAmt,
    AmtTax: req.taxAmt,
    TaxType: '1',
    TaxRate: '5',
    ItemName: req.itemName,
    ItemCount: '1',
    ItemUnit: '式',
    ItemPrice: req.totalAmt,
    ItemAmt: req.totalAmt,
    BuyerUBN: req.buyerUnifiedNo,
    BuyerName: req.buyerName,
    CarrierType: req.carrierType,
    CarrierNum: req.carrierId,
    DonateCode: req.donateCode,
    PrintFlag: req.printFlag,
    TimeStamp: String(Math.floor(Date.now() / 1000)),
    Version: '1.0',
  };
}

function encryptPayload(params, cfg) {
  const qs = np.buildQuery(params);
  const PostData_ = np.encryptTradeInfo(qs, cfg.hashKey, cfg.hashIV);
  return { MerchantID_: cfg.merchantId, PostData_, Version: '1.0' };
}

// 回應容錯：JSON / query string / 巢狀 Result 皆能解析；明確失敗狀態一律拒
function parseIssueResponse(text) {
  if (text == null || String(text).trim() === '') return { ok: false, reason: 'EMPTY_RESPONSE' };
  let data;
  try {
    data = JSON.parse(text);
  } catch (_) {
    data = np.parseQuery(String(text));
  }
  if (data && typeof data.Result === 'string' && /^[{[]/.test(data.Result.trim())) {
    try { data = { ...data, ...JSON.parse(data.Result) }; } catch (_) { /* 保留原樣 */ }
  }
  const status = String(data.Status ?? data.status ?? data.ResultStatus ?? '').toUpperCase();
  if (status && !['SUCCESS', 'OK', '1', 'TRUE', 'T'].includes(status)) {
    return {
      ok: false, reason: 'PROVIDER_REJECT',
      message: cleanText(data.Message ?? data.message ?? data.Description, 200),
    };
  }
  const invoiceNo = data.InvoiceNo ?? data.invoice_no ?? data.InvoiceNumber ?? null;
  if (!invoiceNo && status === '') return { ok: false, reason: 'UNRECOGNIZED_RESPONSE' };
  return {
    ok: true,
    invoiceNo: invoiceNo ? cleanText(invoiceNo, 30) : null,
    invoiceDate: cleanText(data.InvoiceDate ?? data.invoice_date ?? '', 10) || null,
    randomNumber: cleanText(data.RandomNumber ?? data.random_number ?? '', 10) || null,
    simulated: false,
    message: cleanText(data.Message ?? '', 200),
  };
}

function todayTw() {
  // 台灣發票日期以服務商當地日為準；正式串接後以回應的 InvoiceDate 覆寫
  return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
}

async function post(url, body, headers, timeoutMs) {
  const r = await fetch(url, {
    method: 'POST',
    headers,
    body,
    signal: AbortSignal.timeout(timeoutMs),
  });
  const text = await r.text();
  if (!r.ok) return { ok: false, reason: 'HTTP_' + r.status, message: text.slice(0, 200) };
  return parseIssueResponse(text);
}

/**
 * 送出開立請求。回傳 { ok, reason?, invoiceNo?, invoiceDate?, randomNumber?, simulated? }
 * 呼叫端（invoice.js）負責把失敗記入 outbox，絕不讓發票失敗影響核銷／入帳。
 */
async function sendIssue(req, cfg = configFromEnv()) {
  assertConfig(cfg);
  if (cfg.provider === 'stub') {
    return {
      ok: true, simulated: true,
      invoiceNo: 'STUB' + crypto.createHash('sha256').update(req.idempotencyKey).digest('hex').slice(0, 10).toUpperCase(),
      invoiceDate: todayTw(), randomNumber: '0000',
      message: '模擬開立（未呼叫加值中心）',
    };
  }
  if (cfg.provider === 'http') {
    const headers = { 'content-type': 'application/json' };
    if (cfg.webhookToken) headers.authorization = `Bearer ${cfg.webhookToken}`;
    return post(cfg.webhook, JSON.stringify(req), headers, cfg.timeoutMs);
  }
  // provider=ezpay：欄位待官方文件對齊；host 已由 assertConfig 保證存在
  const form = encryptPayload(toEzpayParams(req, cfg), cfg);
  return post(
    cfg.host.replace(/\/$/, '') + '/Api/invoice_issue',
    np.buildQuery(form),
    { 'content-type': 'application/x-www-form-urlencoded' },
    cfg.timeoutMs
  );
}

module.exports = {
  PROVIDERS, ISSUE_POINTS, configFromEnv, assertConfig,
  toYuan, splitTax, normalizeDonateCode, normalizeCarrier, cleanText,
  buildInvoiceRequest, toEzpayParams, encryptPayload, parseIssueResponse,
  todayTw, sendIssue,
};
