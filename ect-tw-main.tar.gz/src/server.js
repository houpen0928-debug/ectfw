'use strict';
require('dotenv').config();
const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const { query } = require('../db');
const COPY = require('../config/copy');
const paymentRoutes = require('./routes/payment');
const verifyRoutes = require('./routes/verify');
const adminRoutes = require('./routes/admin');
const publicRoutes = require('./routes/public');
const transferRoutes = require('./routes/transfer');

const app = express();

// SOP §2.5：CSP form-action 放行藍新，否則瀏覽器封鎖表單 POST
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'form-action': [
        "'self'",
        'https://core.newebpay.com',
        'https://ccore.newebpay.com',
      ],
    },
  },
}));
app.use(express.json({ limit: '64kb' }));

// 零構建前端：外部 JS/CSS（無 inline script），符合 helmet 預設 CSP。
// /verify 與 /admin 必須註冊在官網 root static 之前，否則會被 / 吃掉。
const staticOpts = { index: 'index.html' };
app.use('/verify', express.static(path.join(__dirname, '..', 'apps', 'verify'), staticOpts));
app.use('/admin', express.static(path.join(__dirname, '..', 'apps', 'admin'), staticOpts));

// 不查 DB：部署冒煙用
app.get('/health', (_req, res) => {
  res.json({
    ok: true, service: 'ect-tw', version: '0.4.0-m1',
    engine: 'ticket-engine-v1', payment: 'newebpay-mpg',
    invoice: 'ezpay-gateway-v1', verify: 'web-console-v1',
    ts: new Date().toISOString(),
  });
});

// 部署後驗證 DB 連線
app.get('/health/db', async (_req, res) => {
  try {
    await query('SELECT 1 AS ok');
    res.json({ ok: true });
  } catch (err) {
    res.status(503).json({ ok: false, error: err.message });
  }
});

// 官網 ESG 數字條公開端點：讀 esg_snapshots 最新一筆，失敗靜默降級為 0
app.get('/api/public/esg', async (_req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  const fallback = {
    charityTotal: 0, charityCount: 0, zeroWasteRate: 0, projects: 0,
    meta: {
      methodology: 'TWECT ESG v1.0（與大陸版同源 6 指標）',
      source: 'stub', liveLabel: COPY.esg.liveLabel,
    },
  };
  try {
    const r = await query(
      `SELECT charity_total, charity_count, zero_waste_rate, projects, methodology
       FROM esg_snapshots ORDER BY created_at DESC, id DESC LIMIT 1`
    );
    if (!r.rowCount) return res.json(fallback);
    const s = r.rows[0];
    return res.json({
      charityTotal: Number(s.charity_total),
      charityCount: Number(s.charity_count),
      zeroWasteRate: Number(s.zero_waste_rate),
      projects: Number(s.projects),
      meta: {
        methodology: s.methodology || fallback.meta.methodology,
        source: 'ledger', liveLabel: COPY.esg.liveLabel,
      },
    });
  } catch (_) {
    return res.json(fallback); // 無 DB 時優雅降級，不讓官網數字條壞掉
  }
});

// 官網公開文案（無門禁、不含憑證）
app.use(publicRoutes);
// 後台總覽（X-Admin-Token 門禁；法遵儀表置頂）
app.use(adminRoutes);
// 核銷台 API（X-Verify-Key 門禁 + 發行人隔離）
app.use(verifyRoutes);
// 用戶端轉贈＋動態碼 API（X-User-Id 開發期門禁；批次B 換 LINE Login session）
app.use(transferRoutes);
// 藍新 server-to-server 回呼不帶 Origin，改以 TradeSha 驗簽/解密當認證（SOP §2.5 #1）
app.use(paymentRoutes);

// 官網首頁放最後：static 找不到就 next 交給 404，不影響任何 /api 或 /health 路由
app.use('/', express.static(path.join(__dirname, '..', 'apps', 'web'), staticOpts));

app.use((_req, res) => res.status(404).json({ error: 'not_found' }));
app.use((err, _req, res, _next) => {
  console.error('[server]', err.message);
  res.status(500).json({ error: 'internal_error' });
});

const port = Number(process.env.ECT_PORT || 3000);
if (require.main === module) {
  app.listen(port, () => console.log(`[ect-tw] listening on ${port}`));
}

module.exports = app;
