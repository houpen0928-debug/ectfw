'use strict';
// 批次②身份骨架：stateless HMAC session cookie（不新增套件、不新增表格）。
// 🔴 紀律：正式環境一律不接受 X-User-Id；該 header 僅在 ECT_ALLOW_DEV_HEADER=1
//    且 ECT_NODE_ENV !== 'production' 時才作為本機/CI 適配器生效。
// 已知限制：stateless cookie 無法由伺服端主動撤銷；logout 只清客戶端 cookie。
//    如需強制登出（踢人／換裝置），後續批次再加 users.session_version 比對。
const crypto = require('node:crypto');

const SESSION_COOKIE = 'ect_sid';
const OAUTH_STATE_COOKIE = 'ect_oauth_state';
const DEFAULT_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const STATE_TTL_MS = 10 * 60 * 1000;

function fail(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}

function sessionSecretFromEnv(env = process.env) {
  const s = env.ECT_SESSION_SECRET;
  if (typeof s !== 'string' || s.length < 16 || s.startsWith('replace-with')) {
    throw fail('SESSION_SECRET_UNSET', 'ECT_SESSION_SECRET 未設定或仍為樣板值');
  }
  return s;
}

function signPayload(payload, secret) {
  const body = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const mac = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${mac}`;
}

function verifyPayload(token, secret, now = Date.now()) {
  if (typeof token !== 'string' || typeof secret !== 'string' || !secret) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, mac] = parts;
  const expected = crypto.createHmac('sha256', secret).update(body).digest();
  let given;
  try { given = Buffer.from(mac, 'base64url'); } catch { return null; }
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  let payload;
  try { payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); } catch { return null; }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return null;
  if (!Number.isFinite(payload.exp) || payload.exp <= now) return null;
  return payload;
}

function issueSession({ uid, lineUid = null, secret, ttlMs = DEFAULT_TTL_MS, now = Date.now() }) {
  if (!Number.isInteger(uid) || uid <= 0) throw fail('BAD_UID', 'uid must be a positive integer');
  return signPayload({ kind: 'session', uid, lineUid, iat: now, exp: now + ttlMs }, secret);
}

function verifySession(token, secret, now = Date.now()) {
  const p = verifyPayload(token, secret, now);
  return p && p.kind === 'session' && Number.isInteger(p.uid) && p.uid > 0 ? p : null;
}

function issueOAuthState({ secret, now = Date.now(), ttlMs = STATE_TTL_MS }) {
  const state = crypto.randomBytes(16).toString('base64url');
  const nonce = crypto.randomBytes(16).toString('base64url');
  return {
    state, nonce,
    token: signPayload({ kind: 'oauth_state', state, nonce, exp: now + ttlMs }, secret),
  };
}

// 回完整 payload（含 nonce）供 OAuth callback 比對 ID token；比對失敗回 null。
function readOAuthState(token, secret, now = Date.now()) {
  const p = verifyPayload(token, secret, now);
  return p && p.kind === 'oauth_state' && typeof p.state === 'string' ? p : null;
}

function verifyOAuthState(token, expectedState, secret, now = Date.now()) {
  const p = readOAuthState(token, secret, now);
  return !!p && p.state === expectedState;
}

// 不依賴 cookie-parser：純字串解析，方便單測注入假 req。
function parseCookies(header) {
  const out = {};
  if (typeof header !== 'string' || !header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (!k) continue;
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch { out[k] = ''; }
  }
  return out;
}

function cookieString(name, value, { secure = true, sameSite = 'None', path = '/', maxAgeMs } = {}) {
  const bits = [`${name}=${encodeURIComponent(value)}`, `Path=${path}`];
  if (secure) bits.push('Secure');
  bits.push('HttpOnly', `SameSite=${sameSite}`);
  if (Number.isFinite(maxAgeMs)) bits.push(`Max-Age=${Math.floor(maxAgeMs / 1000)}`);
  return bits.join('; ');
}

function clearCookieString(name, opts) {
  return cookieString(name, '', { ...opts, maxAgeMs: 0 });
}

// 工廠：env / secret / now 皆可注入，讓紅線「正式環境拒 X-User-Id」能被單測直接驗證。
function createRequireSession({ env = process.env, secret, now } = {}) {
  return function requireSession(req, res, next) {
    let sec = secret;
    if (!sec) {
      try { sec = sessionSecretFromEnv(env); } catch {
        return res.status(503).json({ error: 'session_unavailable' });
      }
    }
    const stamp = typeof now === 'function' ? now() : (now == null ? Date.now() : now);
    const token = parseCookies(req.headers && req.headers.cookie)[SESSION_COOKIE];
    const payload = verifySession(token, sec, stamp);
    if (payload) {
      req.userId = payload.uid;
      req.session = payload;
      return next();
    }
    const devHeaderAllowed = env.ECT_ALLOW_DEV_HEADER === '1' && env.ECT_NODE_ENV !== 'production';
    if (devHeaderAllowed) {
      const uid = Number(req.headers && req.headers['x-user-id']);
      if (Number.isInteger(uid) && uid > 0) {
        req.userId = uid;
        req.session = { kind: 'dev', uid };
        return next();
      }
    }
    return res.status(401).json({ error: 'unauthorized' });
  };
}

const requireSession = createRequireSession();

module.exports = {
  SESSION_COOKIE, OAUTH_STATE_COOKIE, DEFAULT_TTL_MS, STATE_TTL_MS,
  sessionSecretFromEnv, signPayload, verifyPayload,
  issueSession, verifySession, issueOAuthState, readOAuthState, verifyOAuthState,
  parseCookies, cookieString, clearCookieString,
  createRequireSession, requireSession,
};
