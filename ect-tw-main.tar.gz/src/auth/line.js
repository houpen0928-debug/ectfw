'use strict';
// 批次②身份骨架：LINE Login 設定、授權網址、ID token 驗證、line_bindings 綁定。
// 🔴 設定缺任一項即 fail-closed（LINE_CONFIG_UNSET），不送出猜測值。
// 驗證走 LINE 官方 verify 端點（簽章由 LINE 驗），本端再獨立核 iss/aud/exp/sub 四項。
// fetchImpl / db 皆可注入 → 不需真 LINE、不需真 DB 就能單測。
const AUTHORIZE_ENDPOINT = 'https://access.line.me/oauth2/v2.1/authorize';
const TOKEN_ENDPOINT = 'https://api.line.me/oauth2/v2.1/token';
const VERIFY_ENDPOINT = 'https://api.line.me/oauth2/v2.1/verify';
const ISSUER = 'https://access.line.me';

function fail(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}

function lineConfigFromEnv(env = process.env) {
  const channelId = String(env.LINE_CHANNEL_ID || '').trim();
  const channelSecret = String(env.LINE_CHANNEL_SECRET || '').trim();
  const redirectUri = String(env.LINE_REDIRECT_URI || '').trim();
  const missing = [];
  if (!channelId || channelId.startsWith('replace-with')) missing.push('LINE_CHANNEL_ID');
  if (!channelSecret || channelSecret.startsWith('replace-with')) missing.push('LINE_CHANNEL_SECRET');
  if (!redirectUri) missing.push('LINE_REDIRECT_URI');
  if (missing.length) {
    throw fail('LINE_CONFIG_UNSET', `LINE 設定未完成：${missing.join(', ')}`);
  }
  return { channelId, channelSecret, redirectUri };
}

function buildAuthorizeUrl({ channelId, redirectUri, state, nonce }) {
  if (!state || !nonce) throw fail('BAD_STATE', 'state/nonce required');
  const u = new URL(AUTHORIZE_ENDPOINT);
  u.searchParams.set('response_type', 'code');
  u.searchParams.set('client_id', channelId);
  u.searchParams.set('redirect_uri', redirectUri);
  u.searchParams.set('scope', 'openid profile');
  u.searchParams.set('state', state);
  u.searchParams.set('nonce', nonce);
  // 不申請 email：email scope 需上傳隱私政策截圖送審；本平台只需 openid + profile。
  return u.toString();
}

async function exchangeCode({ code, cfg, fetchImpl = globalThis.fetch }) {
  if (typeof code !== 'string' || !code) throw fail('BAD_CODE', 'authorization code required');
  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    code,
    redirect_uri: cfg.redirectUri,
    client_id: cfg.channelId,
    client_secret: cfg.channelSecret,
  });
  const r = await fetchImpl(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!r || !r.ok) throw fail('TOKEN_EXCHANGE_FAILED', 'LINE token endpoint rejected the request');
  const data = await r.json();
  if (!data || typeof data.id_token !== 'string' || !data.id_token) {
    throw fail('NO_ID_TOKEN', 'LINE token response has no id_token');
  }
  return data;
}

async function verifyIdToken({ idToken, cfg, fetchImpl = globalThis.fetch, now = Date.now(), expectedNonce = null }) {
  if (typeof idToken !== 'string' || !idToken) throw fail('BAD_ID_TOKEN', 'id_token required');
  const body = new URLSearchParams({ id_token: idToken, client_id: cfg.channelId });
  const r = await fetchImpl(VERIFY_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!r || !r.ok) throw fail('ID_TOKEN_REJECTED', 'LINE verify endpoint rejected the id_token');
  const d = await r.json();
  if (!d || typeof d !== 'object') throw fail('BAD_VERIFY_RESPONSE', 'invalid verify response');
  if (d.iss !== ISSUER) throw fail('BAD_ISSUER', 'unexpected id_token issuer');
  if (String(d.aud) !== String(cfg.channelId)) throw fail('BAD_AUDIENCE', 'id_token aud mismatch');
  const expMs = Number(d.exp) * 1000;
  if (!Number.isFinite(expMs) || expMs <= now) throw fail('TOKEN_EXPIRED', 'id_token is no longer valid');
  if (typeof d.sub !== 'string' || !d.sub) throw fail('BAD_SUBJECT', 'id_token has no sub');
  // OAuth authorize 流程帶 nonce 時，ID token 必須回同一個值（防授權碼重放）。
  if (expectedNonce != null && d.nonce !== expectedNonce) {
    throw fail('BAD_NONCE', 'id_token nonce mismatch');
  }
  return {
    lineUid: d.sub,
    displayName: typeof d.name === 'string' ? d.name : null,
  };
}

// 冪等綁定：users.line_user_id 與 line_bindings.line_uid 皆為 UNIQUE。
// 參數一律綁定（$1/$2），無字串拼接。回傳 platform user id。
// ⚠️ 已知限制：既有「手機註冊、line_user_id 為 NULL」的帳號不會自動合併，
//    會另建一筆 user；帳號合併屬批次③範圍，本批不處理。
async function resolveOrCreateUser({ lineUid, displayName = null, db }) {
  if (typeof lineUid !== 'string' || !lineUid) throw fail('BAD_LINE_UID', 'lineUid required');
  if (!db || typeof db.withTransaction !== 'function') throw fail('DB_REQUIRED', 'db.withTransaction required');
  return db.withTransaction(async (client) => {
    const r = await client.query(
      `INSERT INTO users (line_user_id, display_name)
       VALUES ($1, $2)
       ON CONFLICT (line_user_id) DO UPDATE
         SET display_name = COALESCE($2, users.display_name)
       RETURNING id`,
      [lineUid, displayName]
    );
    if (!r || !r.rows || !r.rows.length) throw fail('USER_UPSERT_FAILED', 'user upsert returned no row');
    const userId = Number(r.rows[0].id);
    if (!Number.isInteger(userId) || userId <= 0) throw fail('USER_UPSERT_FAILED', 'invalid user id');
    await client.query(
      `INSERT INTO line_bindings (user_id, line_uid) VALUES ($1, $2)
       ON CONFLICT (line_uid) DO NOTHING`,
      [userId, lineUid]
    );
    return userId;
  });
}

module.exports = {
  AUTHORIZE_ENDPOINT, TOKEN_ENDPOINT, VERIFY_ENDPOINT, ISSUER,
  lineConfigFromEnv, buildAuthorizeUrl, exchangeCode, verifyIdToken,
  resolveOrCreateUser,
};
