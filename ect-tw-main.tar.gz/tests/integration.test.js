'use strict';
// 端到端整合測試：需真 PG。以 ECT_INTEGRATION=1 + ECT_PG_URL 啟用（CI postgres service）。
// 本機無 DB 時明確 skip，不假裝通過。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ON = process.env.ECT_INTEGRATION === '1';
const skip = ON ? false : { reason: 'ECT_INTEGRATION 未啟用（CI 才跑）' };

// ---- 不需 DB 的 migration 靜態檢查 ----
test('migration 檔：版本序連續、無巢狀交易、DDL 冪等、無 EXPIRED 終態', () => {
  const dir = path.resolve(__dirname, '../db/migrations');
  const files = fs.readdirSync(dir).filter((f) => /^\d{3}_.+\.sql$/.test(f)).sort();
  assert.ok(files.length >= 2, '至少含 001 baseline + 002 M1');
  files.forEach((f, i) => assert.equal(f.slice(0, 3), String(i + 1).padStart(3, '0')));
  for (const f of files) {
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    assert.ok(!/^\s*BEGIN\s*;/im.test(sql), `${f} 不得含 BEGIN（由 runner 包交易）`);
    assert.ok(!/^\s*COMMIT\s*;/im.test(sql), `${f} 不得含 COMMIT`);
    assert.ok(!/CREATE TABLE(?! IF NOT EXISTS)/i.test(sql), `${f} 建表須 IF NOT EXISTS`);
    // 只禁止把 EXPIRED 當成狀態「值」；中文註解「無 EXPIRED 終態」是說明，不算違規
    assert.ok(!/['"]EXPIRED['"]/.test(sql), `${f} 不得把逾期作廢列為狀態值`);
  }
});

// ---- 以下需真 PG ----
const KEY = 'Fs5cX1TGqYM2PpdbE14a9H83YQSQF5jn';
const IV = 'C6AcmfqJILwgnhIP';
const MID = 'MS127874575';

function notifyForm(over = {}) {
  const nb = require('../src/payments/newebpay');
  const inner = {
    Status: 'SUCCESS', MerchantID: MID, Amt: 699, TradeNo: 'TN' + crypto.randomInt(1e9),
    MerchantOrderNo: over.orderNo || 'ORDER' + crypto.randomInt(1e9), ...over,
  };
  const TradeInfo = nb.encryptTradeInfo(inner, KEY, IV);
  return { Status: 'SUCCESS', MerchantID: MID, Version: '2.0',
    TradeInfo, TradeSha: nb.buildTradeSha(TradeInfo, KEY, IV), inner };
}
const cfg = () => ({
  merchantId: MID, hashKey: KEY, hashIV: IV, enabled: true, sandbox: true,
  notifyURL: 'https://twect.com.tw/pay/newebpay/notify', returnURL: '', clientBackURL: '',
});

test('migration runner：執行後再跑一次應 0 new（冪等）+ checksum 防篡改', { skip }, async () => {
  const { run, status, listFiles } = require('../db/migrate');
  const files = listFiles();
  const first = await run();
  assert.equal(first.head, files[files.length - 1].version, 'head 應等於最新版本，不寫死版本號');
  const second = await run();
  assert.equal(second.applied, 0, '重跑不得重複套用');
  const rows = await status();
  for (const f of files) assert.ok(rows.some((r) => r.file === f.file), `${f.file} 應有版本紀錄`);
  // 不在此處 pool.end()：後續測試共用同一 pool
});

test('端到端：下單 → 藍新回呼 → 入帳＋發券 → 重送冪等 → 金額不符/偽造簽章全拒', { skip }, async () => {
  const { query } = require('../db');
  const { settleNotify } = require('../src/engine/payment');
  const { merchantOrderNo } = require('../src/payments/newebpay');

  const tag = crypto.randomBytes(4).toString('hex');
  const v = await query(
    `INSERT INTO vendors(unified_no,name,address,representative,status)
     VALUES($1,$2,'台北市','洪 tester','ACTIVE') RETURNING id`,
    [tag.slice(0, 8), '測試廠商-' + tag]
  );
  const vendorId = v.rows[0].id;
  const p = await query(
    `INSERT INTO products(vendor_id,name,face_value_cents,floor_value_cents,status)
     VALUES($1,'測試券',69900,32000,'ACTIVE') RETURNING id`,
    [vendorId]
  );
  const productId = p.rows[0].id;
  const u = await query("INSERT INTO users(display_name) VALUES('測試用戶') RETURNING id");
  const userId = u.rows[0].id;

  const orderNo = merchantOrderNo('T' + tag);
  await query(
    `INSERT INTO orders(order_no,user_id,product_id,vendor_id,qty,amount_cents,fee_scope,status)
     VALUES($1,$2,$3,$4,2,69900,'PLATFORM_FEE','PENDING')`,
    [orderNo, userId, productId, vendorId]
  );

  // 合法回呼
  const form = notifyForm({ orderNo, MerchantOrderNo: orderNo });
  const ok = await settleNotify(form, cfg());
  assert.equal(ok.reason, 'PAID');
  assert.equal(ok.issued.length, 2, '應發 2 張券');

  // 🔴 P0 回歸（真 PG）：發票 hook 與付款在同一交易，入隊成功且不得毒化入帳
  const inv = await query(
    `SELECT count(*)::int AS n FROM invoices WHERE order_no=$1 AND status='PENDING'`, [orderNo]
  );
  assert.equal(inv.rows[0].n, 1, '付款成功應在同一交易入隊一張發票');
  const ob = await query(
    `SELECT count(*)::int AS n FROM invoice_outbox WHERE order_no=$1 AND event='QUEUED'`, [orderNo]
  );
  assert.equal(ob.rows[0].n, 1, '入隊須留 QUEUED 軌跡');

  // 重送 → 冪等，不再發券
  const dup = await settleNotify(form, cfg());
  assert.equal(dup.reason, 'DUPLICATE');
  const cnt = await query(
    `SELECT count(*)::int AS n FROM tickets t JOIN orders o ON o.id=t.order_id WHERE o.order_no=$1`,
    [orderNo]
  );
  assert.equal(cnt.rows[0].n, 2, '重送不得重複發券');

  // 訂單與交易留痕
  const o = await query('SELECT status FROM orders WHERE order_no=$1', [orderNo]);
  assert.equal(o.rows[0].status, 'FULFILLED');
  const txn = await query('SELECT amt_cents,status FROM newebpay_txn WHERE merchant_order_no=$1', [orderNo]);
  assert.equal(txn.rows[0].status, 'PAID');
  assert.equal(Number(txn.rows[0].amt_cents), 69900);

  // 金額不符 → 拒且另一張訂單保持 PENDING
  const orderNo2 = merchantOrderNo('M' + tag);
  await query(
    `INSERT INTO orders(order_no,user_id,product_id,vendor_id,qty,amount_cents,fee_scope,status)
     VALUES($1,$2,$3,$4,1,69900,'PLATFORM_FEE','PENDING')`,
    [orderNo2, userId, productId, vendorId]
  );
  const mismatch = await settleNotify(notifyForm({ orderNo: orderNo2, MerchantOrderNo: orderNo2, Amt: 1 }), cfg());
  assert.equal(mismatch.reason, 'AMOUNT_MISMATCH');
  const o2 = await query('SELECT status FROM orders WHERE order_no=$1', [orderNo2]);
  assert.equal(o2.rows[0].status, 'PENDING', '金額不符不得入帳');

  // 偽造簽章 → 拒
  const bad = notifyForm({ orderNo: orderNo2, MerchantOrderNo: orderNo2, Amt: 699 });
  const forged = await settleNotify({ ...bad, TradeSha: 'A'.repeat(64) }, cfg());
  assert.equal(forged.reason, 'BAD_SIGNATURE');

  // 券貨款訂單走藍新 → 收款紅線攔截
  const orderNo3 = merchantOrderNo('S' + tag);
  await query(
    `INSERT INTO orders(order_no,user_id,product_id,vendor_id,qty,amount_cents,fee_scope,status)
     VALUES($1,$2,$3,$4,1,69900,'TICKET_SALE','PENDING')`,
    [orderNo3, userId, productId, vendorId]
  );
  const scope = await settleNotify(notifyForm({ orderNo: orderNo3, MerchantOrderNo: orderNo3 }), cfg());
  assert.equal(scope.reason, 'FEE_SCOPE_REJECT', '券貨款不得經平台藍新代號');

  // 事件軌跡可追溯
  const ev = await query('SELECT event FROM payment_events WHERE order_no=$1 ORDER BY id', [orderNo]);
  const events = ev.rows.map((r) => r.event);
  assert.ok(events.includes('NOTIFY_RECEIVED') && events.includes('PAID'));
});

test('券引擎：部分核銷保留殘值 → 轉點數 → 點數守恆 drift=0', { skip }, async () => {
  const { query } = require('../db');
  const { tx } = require('../src/engine/tickets');
  const crypto2 = crypto;
  const tag = crypto2.randomBytes(4).toString('hex');
  const v = await query(
    `INSERT INTO vendors(unified_no,name,address,representative,status)
     VALUES($1,$2,'台北市','洪 tester','ACTIVE') RETURNING id`,
    [tag.slice(0, 8), '引擎測試-' + tag]
  );
  const p = await query(
    `INSERT INTO products(vendor_id,name,face_value_cents,floor_value_cents,status)
     VALUES($1,'引擎券',100000,40000,'ACTIVE') RETURNING id`, [v.rows[0].id]
  );
  const b = await query(
    `INSERT INTO batches(product_id,issue_no,sale_date,qty,status)
     VALUES($1,$2,CURRENT_DATE,1,'ISSUED') RETURNING id`,
    [p.rows[0].id, 'BATCH-' + tag]
  );
  const u = await query("INSERT INTO users(display_name) VALUES('券主') RETURNING id");
  const userId = u.rows[0].id;
  const code = crypto2.randomBytes(16).toString('hex');
  const t = await query(
    `INSERT INTO tickets(batch_id,code_hash,scratch_hash,state,face_value_cents,floor_value_cents,residual_cents)
     VALUES($1,$2,$3,'UNBOUND',100000,40000,100000) RETURNING id`,
    [b.rows[0].id, require('../src/engine/tickets').sha256(code), require('../src/engine/tickets').sha256(code + 's')]
  );
  const id = t.rows[0].id;

  await tx.bind(id, userId);
  const partial = await tx.redeem(id, 30000);
  assert.equal(partial.state, 'BOUND');
  assert.equal(partial.residualCents, 70000, '部分核銷後殘值完整保留');

  const conv = await tx.convert(id, userId);
  assert.equal(conv.state, 'CONVERTED');
  assert.equal(Number(conv.creditedCents), 70000, '剩餘價值全額轉入點數');
  assert.equal(typeof conv.creditedCents, 'number', '金額須為數字，不得外洩 PG bigint 字串');

  const cons = await query('SELECT ledger_sum_cents,balance_sum_cents,drift_cents FROM points_conservation');
  // 只驗證「此用戶」的守恆：ledger 對該用戶的累計 == 其餘額
  const mine = await query('SELECT coalesce(sum(delta_cents),0)::bigint AS s FROM points_ledger WHERE user_id=$1', [userId]);
  const bal = await query('SELECT points_balance_cents FROM users WHERE id=$1', [userId]);
  assert.equal(String(mine.rows[0].s), String(bal.rows[0].points_balance_cents), '點數帳本與餘額必須守恆');
  assert.ok(cons.rows[0], 'points_conservation 視圖可查');
});

test('migration 後對帳視圖可查詢且無殘值違規', { skip }, async () => {
  const { query } = require('../db');
  const r = await query('SELECT * FROM residual_monitor');
  assert.equal(r.rowCount, 1);
  assert.equal(Number(r.rows[0].zero_residual_violations), 0, '存續中的券殘值不得為 0');
});

test('004 已套用：發票欄位、監控視圖、核銷軌跡表皆可查詢', { skip }, async () => {
  const { query } = require('../db');
  const cols = await query(
    `SELECT column_name FROM information_schema.columns WHERE table_name='invoices'`
  );
  const names = cols.rows.map((r) => r.column_name);
  for (const c of ['provider', 'order_no', 'idempotency_key', 'issue_point',
    'invoice_no', 'attempts', 'issued_at', 'updated_at']) {
    assert.ok(names.includes(c), `invoices 缺少 004 欄位 ${c}`);
  }
  const m = await query('SELECT * FROM invoice_monitor');
  assert.equal(m.rowCount, 1);
  assert.ok(m.rows[0].pending_count != null);
  const ops = await query('SELECT count(*)::int AS n FROM verify_operations');
  assert.equal(ops.rowCount, 1);
  const outbox = await query('SELECT count(*)::int AS n FROM invoice_outbox');
  assert.equal(outbox.rowCount, 1);
});

// ---- M2 批次A：券轉移 + 動態碼（真 PG）----

test('005 已套用 + M2A 轉移端到端：綁定→轉贈→領取過戶→舊碼全作廢、新碼可用、token 單次', { skip }, async () => {
  const { query, withTransaction } = require('../db');
  const T = require('../src/engine/tickets');
  const transfer = require('../src/engine/transfer');
  const dyn = require('../src/engine/dynamicCode');
  process.env.ECT_DYNAMIC_CODE_SECRET = 'integration-test-secret-0123456789';

  const tag = crypto.randomBytes(4).toString('hex');
  const v = await query(
    `INSERT INTO vendors(unified_no,name,address,representative,status)
     VALUES($1,$2,'台北市','洪 tester','ACTIVE') RETURNING id`,
    [tag.slice(0, 8), '測試廠商-' + tag]
  );
  const p = await query(
    `INSERT INTO products(vendor_id,name,face_value_cents,floor_value_cents,status)
     VALUES($1,'測試券',69900,32000,'ACTIVE') RETURNING id`,
    [v.rows[0].id]
  );
  const b = await query(
    `INSERT INTO batches(product_id, issue_no, sale_date, qty, status)
     VALUES($1,$2,CURRENT_DATE,1,'ISSUED') RETURNING id`,
    [p.rows[0].id, 'M2A' + tag]
  );
  const code = crypto.randomBytes(18).toString('base64url');
  const scratch = crypto.randomBytes(18).toString('base64url');
  const t = await query(
    `INSERT INTO tickets(batch_id, code_hash, scratch_hash, state,
                          face_value_cents, floor_value_cents, residual_cents)
     VALUES($1,$2,$3,'UNBOUND',69900,32000,69900) RETURNING id`,
    [b.rows[0].id, T.sha256(code), T.sha256(scratch)]
  );
  const ticketId = t.rows[0].id;
  const ua = await query("INSERT INTO users(display_name) VALUES('轉出人A') RETURNING id");
  const ub = await query("INSERT INTO users(display_name) VALUES('轉入人B') RETURNING id");
  const userA = ua.rows[0].id;
  const userB = ub.rows[0].id;

  await T.tx.bind(ticketId, userA, 'test');
  const dynOld = dyn.issueDynamicCode({ ticketId, codeSeq: 0, secret: process.env.ECT_DYNAMIC_CODE_SECRET });

  const created = await transfer.tx.create(ticketId, userA);
  assert.ok(created.token.length >= 8, 'token 明文應有足夠熵');
  const claim1 = await transfer.tx.claim(created.token, userB);
  assert.equal(claim1.state, 'BOUND');
  assert.equal(claim1.codeSeq, 1, '轉移後 code_seq 應 +1');
  assert.ok(claim1.code && claim1.code !== code, '應重簽新券碼');

  const tk = await withTransaction((c) => T.findTicketById(c, ticketId, null, { lock: false }));
  assert.equal(Number(tk.owner_user_id), Number(userB), '過戶後持有人應為 B');
  assert.equal(tk.residual_cents, 69900, '轉移不得減損殘值');

  // 舊靜態碼作廢：code_hash 已換，反查不到
  await assert.rejects(
    () => withTransaction((c) => T.findTicketByCode(c, code, null, { lock: false })),
    (e) => e.code === 'TICKET_NOT_FOUND'
  );
  const byNew = await withTransaction((c) => T.findTicketByCode(c, claim1.code, null, { lock: false }));
  assert.equal(Number(byNew.id), Number(ticketId), '新券碼應可反查同張券');

  // 舊動態碼（seq 落後）一律拒；新動態碼驗過
  await assert.rejects(
    () => withTransaction((c) => dyn.resolveTicketForVerify(c, dynOld, null, { lock: false })),
    (e) => e.code === 'SEQ_STALE'
  );
  const dynNew = dyn.issueDynamicCode({ ticketId, codeSeq: 1, secret: process.env.ECT_DYNAMIC_CODE_SECRET });
  const okTk = await withTransaction((c) => dyn.resolveTicketForVerify(c, dynNew, null, { lock: false }));
  assert.equal(Number(okTk.id), Number(ticketId));

  // token 單次消費
  await assert.rejects(
    () => transfer.tx.claim(created.token, userB),
    (e) => e.code === 'TOKEN_CONSUMED'
  );
  // 原持有人已非 owner，不得再發起
  await assert.rejects(() => transfer.tx.create(ticketId, userA), (e) => e.code === 'NOT_OWNER');
  // journal 留痕
  const j = await query('SELECT action FROM ticket_chain WHERE ticket_id=$1 ORDER BY id', [ticketId]);
  assert.ok(j.rows.some((r) => r.action === 'TRANSFER'), 'ticket_chain 應有 TRANSFER 記錄');
});

test('M2A 補償：token 過期/取消後，券留在原持有人、狀態不動（失敗補償狀態機）', { skip }, async () => {
  const { query } = require('../db');
  const T = require('../src/engine/tickets');
  const transfer = require('../src/engine/transfer');

  const tag = crypto.randomBytes(4).toString('hex');
  const v = await query(
    `INSERT INTO vendors(unified_no,name,address,representative,status)
     VALUES($1,$2,'台北市','洪 tester','ACTIVE') RETURNING id`,
    [tag.slice(0, 8), '補償廠商-' + tag]
  );
  const p = await query(
    `INSERT INTO products(vendor_id,name,face_value_cents,floor_value_cents,status)
     VALUES($1,'補償券',50000,20000,'ACTIVE') RETURNING id`,
    [v.rows[0].id]
  );
  const b = await query(
    `INSERT INTO batches(product_id, issue_no, sale_date, qty, status)
     VALUES($1,$2,CURRENT_DATE,1,'ISSUED') RETURNING id`,
    [p.rows[0].id, 'M2C' + tag]
  );
  const code = crypto.randomBytes(18).toString('base64url');
  const t = await query(
    `INSERT INTO tickets(batch_id, code_hash, scratch_hash, state,
                          face_value_cents, floor_value_cents, residual_cents)
     VALUES($1,$2,$3,'UNBOUND',50000,20000,50000) RETURNING id`,
    [b.rows[0].id, T.sha256(code), T.sha256(crypto.randomBytes(18).toString('base64url'))]
  );
  const ticketId = t.rows[0].id;
  const ua = await query("INSERT INTO users(display_name) VALUES('補償A') RETURNING id");
  const ub = await query("INSERT INTO users(display_name) VALUES('補償B') RETURNING id");
  const userA = ua.rows[0].id;
  const userB = ub.rows[0].id;
  await T.tx.bind(ticketId, userA, 'test');

  // 過期：領取被拒，券留在 A、狀態 BOUND、code_seq 不動
  const c1 = await transfer.tx.create(ticketId, userA);
  await query(
    `UPDATE transfer_tokens SET expires_at = now() - interval '1 second' WHERE token_hash=$1`,
    [T.sha256(c1.token)]
  );
  await assert.rejects(
    () => transfer.tx.claim(c1.token, userB),
    (e) => e.code === 'TOKEN_EXPIRED'
  );

  // 取消：僅發起人可取消；取消後領取被拒
  const c2 = await transfer.tx.create(ticketId, userA);
  await assert.rejects(() => transfer.tx.cancel(c2.token, userB), (e) => e.code === 'NOT_OWNER');
  const can = await transfer.tx.cancel(c2.token, userA);
  assert.equal(can.status, 'CANCELLED');
  await assert.rejects(() => transfer.tx.claim(c2.token, userB), (e) => e.code === 'TOKEN_CLOSED');

  const tk = await query(
    'SELECT state, owner_user_id, code_seq, residual_cents FROM tickets WHERE id=$1',
    [ticketId]
  );
  assert.equal(tk.rows[0].state, 'BOUND', '補償後狀態不動');
  assert.equal(Number(tk.rows[0].owner_user_id), Number(userA), '補償後持有人仍為 A');
  assert.equal(Number(tk.rows[0].code_seq), 0, '未過戶不得重簽碼');
  assert.equal(Number(tk.rows[0].residual_cents), 50000, '補償後殘值不減');
});
