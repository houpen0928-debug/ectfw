'use strict';
// M1 後段第一批：官網首頁／後台骨架。
// 核心是「文案自動對撞」：HTML 內 data-copy 的靜態副本必須逐字等於 config/copy.js，
// 且自檢本身要做反向測試（故意改一個字要抓得到），避免檢查器寫成永真。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const COPY = require('../config/copy');
const { scanText } = require('../scripts/check-banned-words');
const publicRoutes = require('../src/routes/public');
const adminRoutes = require('../src/routes/admin');

const ROOT = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');

function byPath(obj, dotted) {
  return dotted.split('.').reduce((v, k) => (v == null ? undefined : v[k]), obj);
}

// 回傳所有對撞失敗項；抽成函式才能對它做反向自測
function mismatches(html, copy) {
  const bad = [];
  const re = /data-copy="([^"]+)"[^>]*>([^<]*)</g;
  for (const m of html.matchAll(re)) {
    const expected = byPath(copy, m[1]);
    if (expected !== m[2]) {
      bad.push(`${m[1]}：HTML=${JSON.stringify(m[2])} / COPY=${JSON.stringify(expected)}`);
    }
  }
  return bad;
}

function collectStrings(v) {
  if (typeof v === 'string') return [v];
  if (Array.isArray(v)) return v.flatMap(collectStrings);
  if (v && typeof v === 'object') return Object.values(v).flatMap(collectStrings);
  return [];
}

// 靜態檢查「是否用了危險 API／長期儲存」時必須先剝註解，
// 否則像「無 innerHTML」「不寫 localStorage」這種說明文字會被誤判成違規。
// (?<!:) 避免把字串裡的 https:// 當成行註解砍掉。
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/[^\n]*/gm, '$1');
}

// ---- 公開文案端點 ----

test('buildSiteConfig：版本、文案分組齊全，且不含任何憑證欄位', () => {
  const site = publicRoutes.buildSiteConfig();
  assert.equal(site.version, '0.4.0-m1');
  assert.equal(site.entity, COPY.entity.name);
  for (const k of ['ticket', 'points', 'charity', 'refund', 'payment', 'verify', 'invoice', 'web', 'admin', 'esg']) {
    assert.ok(site.copy[k], `缺少文案分組 ${k}`);
  }
  const json = JSON.stringify(site);
  for (const secret of ['HASH_KEY', 'HASH_IV', 'ECT_ADMIN_TOKEN', 'ECT_PG_PASSWORD', 'MERCHANT_ID']) {
    assert.ok(!json.includes(secret), `公開端點不得外洩 ${secret}`);
  }
});

test('公開文案全數不含法規禁用語', () => {
  const strings = collectStrings(COPY);
  assert.ok(strings.length >= 40, '文案庫應有足夠內容');
  for (const s of strings) assert.deepEqual(scanText(s), [], `命中禁詞：${s}`);
  assert.match(COPY.ticket.alwaysValid, /長期有效/);
  assert.match(COPY.web.heroSub, /公益出口/);
});

// ---- 文案自動對撞（含自檢的反向測試）----

test('🔴 官網／後台 HTML 的 data-copy 靜態副本逐字等於 config/copy.js', () => {
  const files = ['apps/web/index.html', 'apps/admin/index.html'];
  let total = 0;
  for (const f of files) {
    const html = read(f);
    const count = (html.match(/data-copy="/g) || []).length;
    assert.ok(count >= 30, `${f} 的 data-copy 覆蓋不足（${count}）`);
    total += count;
    assert.deepEqual(mismatches(html, COPY), [], `${f} 文案漂移`);
  }
  assert.ok(total >= 80, `總對撞數不足：${total}`);
});

test('對撞自檢的反向測試：改一個字就必須被抓到', () => {
  const clean = '<p data-copy="ticket.alwaysValid">本券長期有效，未使用之價值完整保留，不會消失</p>';
  assert.deepEqual(mismatches(clean, COPY), [], '乾淨樣本應零 mismatch');

  const drifted = clean.replace('不會消失', '不會消失X');
  assert.equal(mismatches(drifted, COPY).length, 1, '漂移一個字必須被抓');

  const wrongPath = '<p data-copy="ticket.notExist">隨便</p>';
  assert.equal(mismatches(wrongPath, COPY).length, 1, '路徑不存在必須被抓');

  // 第二種獨立抓法交叉驗證：直接字面比對，不靠正則
  const direct = clean.includes(`>${COPY.ticket.alwaysValid}<`);
  assert.equal(direct, true, '第二種抓法也要能對上');
  assert.equal(drifted.includes(`>${COPY.ticket.alwaysValid}<`), false);
});

// ---- 前端靜態：CSP / XSS / 降級 ----

test('剝註解自檢：說明文字要移除，字串內的 https:// 要保留', () => {
  assert.equal(stripComments('// innerHTML\nconst x = 1;').includes('innerHTML'), false);
  assert.equal(stripComments('/* eval( */ const ok = 1;').includes('eval('), false);
  assert.ok(stripComments('const u = "https://example.com";').includes('https://example.com'));
  assert.ok(stripComments('const a = 1; // 註解\nconst b = 2;').includes('const b = 2;'));
});

test('兩套前端皆零 inline script、外部 CSS/JS、動態文字走 textContent', () => {
  for (const dir of ['apps/web', 'apps/admin']) {
    const html = read(`${dir}/index.html`);
    const js = read(`${dir}/app.js`);
    const code = stripComments(js);
    const css = read(`${dir}/style.css`);
    assert.ok(html.length > 300 && js.length > 300 && css.length > 300, `${dir} 檔案過小`);
    assert.ok(!/<script(?![^>]*\bsrc=)/i.test(html), `${dir} 不得有 inline script`);
    assert.match(html, /<script src="app\.js"><\/script>/);
    assert.match(html, /<link rel="stylesheet" href="style\.css">/);
    assert.ok(!/innerHTML|outerHTML|document\.write|eval\(/i.test(code), `${dir} 禁用 innerHTML/eval`);
    assert.ok(code.includes('textContent'), `${dir} 需以 textContent 寫入`);
    assert.ok(code.includes('/api/public/site'), `${dir} 文案須取自公開端點`);
  }
});

test('官網 ESG 四個數字位初始值為「—」，失敗不以估算值替代', () => {
  const html = read('apps/web/index.html');
  const js = read('apps/web/app.js');
  const ids = ['esgCharityTotal', 'esgCharityCount', 'esgZeroWaste', 'esgProjects'];
  for (const id of ids) {
    assert.match(html, new RegExp(`id="${id}"[^>]*>—</strong>`), `${id} 初始值須為「—」`);
  }
  assert.ok(js.includes('/api/public/esg'));
  assert.ok(/catch \(_\)/.test(js), '讀取失敗要有降級分支');
  assert.ok(!/charityTotal\s*=\s*\d{2,}/.test(js), '不得用估算值填充公益數字');
});

test('後台金鑰只存 sessionStorage，且以 X-Admin-Token 傳送', () => {
  const html = read('apps/admin/index.html');
  const code = stripComments(read('apps/admin/app.js'));
  assert.match(html, /id="token" type="password"/);
  assert.ok(code.includes('sessionStorage'), '金鑰須存於本頁籤');
  assert.ok(!code.includes('localStorage'), '不得寫入長期儲存');
  assert.ok(code.includes("'X-Admin-Token': token()"), 'API 須帶管理員金鑰');
  assert.ok(code.includes('/api/admin/overview') && code.includes('/api/admin/invoices'));
});

// ---- 後台總覽 API ----

test('OVERVIEW_SQL：四個監控視圖齊全、明確轉型、無逾期語義', () => {
  const sql = adminRoutes.OVERVIEW_SQL;
  for (const v of ['payables_monitor', 'residual_monitor', 'points_conservation', 'invoice_monitor']) {
    assert.ok(sql.includes(v), `缺少視圖 ${v}`);
  }
  assert.match(sql, /::int/);
  assert.match(sql, /::bigint/);
  assert.ok(!/EXPIRED/.test(sql), '不得出現逾期終態');
  assert.ok(!/\$\d/.test(sql), '固定常數查詢不應有未綁定參數占位');
});

test('shapeOverview：PG 字串轉數字，缺欄位補 0，分類不混', () => {
  const s = adminRoutes.shapeOverview({
    tickets: '12', orders_paid: '3', payable_cents: '98765',
    zero_residual_violations: '0', points_drift_cents: '0', invoice_failed: '2',
  });
  assert.equal(s.kpi.tickets, 12);
  assert.equal(s.kpi.ordersPaid, 3);
  assert.equal(s.compliance.payableCents, 98765);
  assert.equal(s.compliance.pointsDriftCents, 0);
  assert.equal(s.invoice.failed, 2);
  assert.equal(adminRoutes.shapeOverview().kpi.vendors, 0, '空輸入補 0');
  assert.deepEqual(Object.keys(s), ['kpi', 'compliance', 'invoice']);
});

// ---- R18 第三種獨立抓法：逐行精確比對（不同於檢查器的正則／字串包含）----

// 🔴 文件裡的測試支數也要能自動對撞（洪哥鐵律：程式算出的數字進文件後必須雙向比對）。
// 新增/刪除測試時，同步更新 EXPECT 與 README／SOP／規格書附錄 C，否則 CI 會咬。
const EXPECTED_TESTS = 76;
test('🔴 文件測試數自動對撞：README / SOP / 規格書附錄 C 三處一致', () => {
  const files = [
    'README.md',
    'docs/單VM上線SOP_v1.md',
    'docs/臺灣ECT_TW系統規劃與軟體規格書_v1_1.md',
  ];
  for (const f of files) {
    const txt = read(f);
    assert.ok(txt.includes(`${EXPECTED_TESTS} 支`), `${f} 未寫到 ${EXPECTED_TESTS} 支`);
    assert.ok(!txt.includes(`${EXPECTED_TESTS - 1} 支`), `${f} 仍殘留上一版測試數`);
  }
});

test('🔴 版本號自動對撞：package / lock / health / site / verify config 五處一致', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  assert.equal(lock.version, pkg.version, 'lock 根版本須與 package.json 對撞');
  assert.equal(lock.packages[''].version, pkg.version, 'lock packages[""] 版本須對撞');
  // 套件自身版本不可被「全域取代」誤改（media-typer 剛好也是 0.3.0）
  assert.equal(lock.packages['node_modules/media-typer'].version, '0.3.0',
    '套件版本不得被專案版本取代');

  const stem = `${pkg.version}-m1`;
  assert.ok(read('src/server.js').includes(`version: '${stem}'`), 'health 版本須對撞');
  assert.equal(publicRoutes.VERSION, stem, 'site 版本須對撞');
  assert.ok(read('src/routes/verify.js').includes(`version: '${stem}'`), 'verify config 版本須對撞');
});

test('🔴 server.js 三組 static 掛載齊全，且官網掛在 404 之前', () => {
  const src = read('src/server.js');
  const lines = src.split(/\r?\n/).map((l) => l.trim());
  const mounts = [
    "app.use('/verify', express.static(path.join(__dirname, '..', 'apps', 'verify'), staticOpts));",
    "app.use('/admin', express.static(path.join(__dirname, '..', 'apps', 'admin'), staticOpts));",
    "app.use('/', express.static(path.join(__dirname, '..', 'apps', 'web'), staticOpts));",
  ];
  for (const m of mounts) assert.ok(lines.includes(m), `缺少掛載：${m}`);

  const rootAt = src.indexOf("app.use('/', express.static(");
  const notFoundAt = src.indexOf('res.status(404).json');
  assert.ok(rootAt > 0 && notFoundAt > rootAt, '官網 static 必須在 404 handler 之前');
  assert.match(src, /version: '0\.4\.0-m1'/);
});
