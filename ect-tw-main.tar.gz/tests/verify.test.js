'use strict';
// M1 第二批：門市核銷台（門禁、前端靜態、004 DDL、image 打包紀律）
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const verify = require('../src/routes/verify');
const COPY = require('../config/copy');
const { scanText } = require('../scripts/check-banned-words');

const ROOT = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');

async function withEnv(patch, fn) {
  const saved = {};
  for (const k of Object.keys(patch)) {
    saved[k] = process.env[k];
    process.env[k] = patch[k];
  }
  try { return await fn(); } finally {
    for (const k of Object.keys(patch)) {
      if (saved[k] === undefined) delete process.env[k];
      else process.env[k] = saved[k];
    }
  }
}

function mockRes() {
  return {
    statusCode: null, body: null,
    status(n) { this.statusCode = n; return this; },
    json(o) { this.body = o; return this; },
  };
}

function collectStrings(v) {
  if (typeof v === 'string') return [v];
  if (Array.isArray(v)) return v.flatMap(collectStrings);
  if (v && typeof v === 'object') return Object.values(v).flatMap(collectStrings);
  return [];
}

// ---- 門禁 ----

test('checkVerifyHeaders：未設金鑰 503、錯金鑰 401、正確才放行', () => {
  const env = { ECT_VERIFY_KEY: 'k-123', ECT_VERIFY_VENDOR_ID: '7' };
  assert.deepEqual(verify.checkVerifyHeaders({}, {}), { ok: false, status: 503, error: 'VERIFY_KEY_UNSET' });

  const bad = verify.checkVerifyHeaders({ 'x-verify-key': 'wrong' }, env);
  assert.equal(bad.ok, false);
  assert.equal(bad.status, 401);

  const ok = verify.checkVerifyHeaders({ 'x-verify-key': 'k-123', 'x-verify-staff': '門市A' }, env);
  assert.equal(ok.ok, true);
  assert.equal(ok.vendorId, 7);
  assert.equal(ok.staff, '門市A');
});

test('checkVerifyHeaders：header 名稱大小寫敏感、廠商 ID 未設 503、staff 清洗', () => {
  const env = { ECT_VERIFY_KEY: 'k-123', ECT_VERIFY_VENDOR_ID: '7' };
  // Express 會把 header 正規化為小寫；直接喂大寫視為未帶（雙重確認不誤放行）
  assert.equal(verify.checkVerifyHeaders({ 'X-Verify-Key': 'k-123' }, env).status, 401);
  assert.deepEqual(
    verify.checkVerifyHeaders({ 'x-verify-key': 'k-123' }, { ECT_VERIFY_KEY: 'k-123' }).error,
    'VERIFY_VENDOR_UNSET'
  );
  const cleaned = verify.checkVerifyHeaders(
    { 'x-verify-key': 'k-123', 'x-verify-staff': '<img src=x>' }, env
  );
  assert.ok(!cleaned.staff.includes('<'), 'staff 須去除 HTML 控制字元');
  assert.equal(cleaned.staff, 'img src=x');
});

test('constantTimeEqual：相同放行、差異／長度／空值全拒', () => {
  assert.equal(verify.constantTimeEqual('abc', 'abc'), true);
  assert.equal(verify.constantTimeEqual('abc', 'abd'), false);
  assert.equal(verify.constantTimeEqual('abc', 'abcd'), false);
  assert.equal(verify.constantTimeEqual('', ''), false);
  assert.equal(verify.constantTimeEqual(null, 'a'), false);
  assert.equal(verify.constantTimeEqual('a', undefined), false);
});

test('adminGate：未設 token 503、錯 token 401、正確才 next', async () => {
  await withEnv({ ECT_ADMIN_TOKEN: 'secret' }, () => {
    let next = false;
    const r1 = mockRes();
    verify.adminGate({ get: () => 'secret' }, r1, () => { next = true; });
    assert.equal(next, true, '正確 token 必須放行');

    const r2 = mockRes();
    verify.adminGate({ get: () => 'wrong' }, r2, () => { assert.fail('不該放行'); });
    assert.equal(r2.statusCode, 401);
  });
  await withEnv({ ECT_ADMIN_TOKEN: '' }, () => {
    const r = mockRes();
    verify.adminGate({ get: () => '' }, r, () => { assert.fail('不該放行'); });
    assert.equal(r.statusCode, 503);
    assert.equal(r.body.error, 'ADMIN_TOKEN_UNSET');
  });
});

// ---- 前端靜態（CSP / XSS）----

test('核銷台三檔存在且零 inline script、無 innerHTML', () => {
  const html = read('apps/verify/index.html');
  const js = read('apps/verify/app.js');
  const css = read('apps/verify/style.css');
  assert.ok(html.length > 100 && js.length > 100 && css.length > 100);
  assert.match(html, /<script src="app\.js"><\/script>/, 'JS 必須外部載入');
  assert.ok(!/<script(?![^>]*\bsrc=)/i.test(html), 'helmet 預設 CSP 不允许 inline script');
  assert.match(html, /<link rel="stylesheet" href="style\.css">/);
  assert.ok(!/innerHTML|outerHTML|document\.write|eval\(/i.test(js), '動態文字一律走 textContent');
  assert.ok(js.includes('textContent'), '需以 textContent 寫入');
});

test('核銷台對外文案不含法規禁用語', () => {
  const strings = [...collectStrings(COPY.verify), ...collectStrings(COPY.invoice)];
  assert.ok(strings.length >= 10, '文案庫應有內容');
  for (const s of strings) assert.deepEqual(scanText(s), [], `命中禁詞：${s}`);
  assert.match(COPY.verify.graceAction, /優惠期間/);
  assert.match(COPY.ticket.alwaysValid, /長期有效/);
});

// ---- 004 migration 靜態 ----

test('004 migration：發票/outbox/核銷軌跡/監控視圖齊全且冪等', () => {
  const sql = read('db/migrations/004_m1_invoice_verify.sql');
  assert.match(sql, /ALTER TABLE invoices ADD COLUMN IF NOT EXISTS provider/);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS invoice_outbox/);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS verify_operations/);
  assert.match(sql, /CREATE OR REPLACE VIEW invoice_monitor/);
  assert.match(sql, /CHECK \(issue_point IN \('ORDER','REDEEM'\)\)/);
  assert.ok(!/^\s*BEGIN\s*;/im.test(sql), '不得含 BEGIN（由 runner 包交易）');
  assert.ok(!/^\s*COMMIT\s*;/im.test(sql), '不得含 COMMIT');
  assert.ok(!/['"]EXPIRED['"]/.test(sql), '不得把逾期作廢列為狀態值');
});

// ---- 部署紀律：與 check-prod-compose R17 用不同抓法交叉驗證 ----

test('🔴 核銷台靜態檔必須進 image（Dockerfile COPY + .dockerignore 未排除）', () => {
  const dockerfile = read('Dockerfile');
  const dockerignore = read('.dockerignore');
  assert.match(dockerfile, /COPY\s+apps\s+\.\/apps/, '漏 COPY 會讓上線 /verify 404');
  // 第二種獨立抓法：逐行精確比對，不靠正則
  const excluded = dockerignore.split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l === 'apps' || l.startsWith('apps/'));
  assert.deepEqual(excluded, [], `.dockerignore 不得排除 apps：${excluded.join(', ')}`);
});
