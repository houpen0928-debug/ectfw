'use strict';
// M2 批次A 單元測試：TRANSFER 狀態機 + 動態碼簽發/驗簽（純函式，不需 DB）
const test = require('node:test');
const assert = require('node:assert/strict');
const { STATES, ACTIONS, TERMINAL, transition } = require('../src/engine/tickets');
const dyn = require('../src/engine/dynamicCode');

const SECRET = 'unit-test-secret-0123456789abcdef';

test('TRANSFER：BOUND→BOUND、GRACE→GRACE，狀態與殘值不變（只有持有人換人）', () => {
  for (const from of [STATES.BOUND, STATES.GRACE]) {
    const r = transition(from, ACTIONS.TRANSFER, { fromUserId: 7, toUserId: 8, residualCents: 500 });
    assert.equal(r.ok, true);
    assert.equal(r.state, from, '轉移不改狀態');
    assert.equal(r.residualCents, 500, '轉移不得減損殘值');
    assert.equal(r.journal, 'TRANSFER');
  }
});

test('TRANSFER：未歸戶拒、缺人拒、自轉拒、終態拒', () => {
  const c = { fromUserId: 7, toUserId: 8, residualCents: 100 };
  assert.equal(transition(STATES.UNBOUND, ACTIONS.TRANSFER, c).reason, 'MUST_BE_BOUND_OR_GRACE');
  assert.equal(transition(STATES.BOUND, ACTIONS.TRANSFER, { residualCents: 100 }).reason, 'OWNER_REQUIRED');
  assert.equal(transition(STATES.BOUND, ACTIONS.TRANSFER, { ...c, toUserId: 7 }).reason, 'SELF_TRANSFER');
  for (const s of TERMINAL) {
    assert.equal(transition(s, ACTIONS.TRANSFER, c).reason, 'TERMINAL_STATE');
  }
});

test('動態碼：格式 5 段 ECTD1 前綴；當下與 +59 秒（前一個視窗）皆驗過', () => {
  const now = Date.now();
  const code = dyn.issueDynamicCode({ ticketId: 42, codeSeq: 3, secret: SECRET, now });
  assert.match(code, /^ECTD1\.42\.3\.\d+\.[0-9a-f]{16}$/);
  assert.deepEqual(dyn.verifyDynamicCode(code, { secret: SECRET, now }),
    { ok: true, ticketId: 42, codeSeq: 3 });
  assert.equal(dyn.verifyDynamicCode(code, { secret: SECRET, now: now + 59_000 }).ok, true);
});

test('動態碼：兩個視窗後過期（截圖重放失效）、篡改、改 seq、跨金鑰、壞格式全拒', () => {
  const now = Date.now();
  const code = dyn.issueDynamicCode({ ticketId: 42, codeSeq: 3, secret: SECRET, now });
  assert.equal(dyn.verifyDynamicCode(code, { secret: SECRET, now: now + 121_000 }).reason, 'CODE_EXPIRED');
  assert.equal(dyn.verifyDynamicCode(code.slice(0, -1) + '0', { secret: SECRET, now }).reason, 'BAD_SIGNATURE');
  const forged = code.replace('.3.', '.9.');
  assert.equal(dyn.verifyDynamicCode(forged, { secret: SECRET, now }).reason, 'BAD_SIGNATURE');
  assert.equal(dyn.verifyDynamicCode(code, { secret: 'other-secret-0123456789abcde', now }).reason, 'BAD_SIGNATURE');
  assert.equal(dyn.verifyDynamicCode('ECTD1.42.3.1.deadbeefdeadbeef', { secret: SECRET, now }).reason, 'CODE_EXPIRED');
  assert.equal(dyn.verifyDynamicCode('ECT1.42.3.9.0123456789abcdef', { secret: SECRET, now }).reason, 'BAD_FORMAT');
  assert.equal(dyn.verifyDynamicCode('short', { secret: SECRET, now }).reason, 'BAD_CODE');
  assert.equal(dyn.verifyDynamicCode(null, { secret: SECRET, now }).reason, 'BAD_CODE');
});

test('動態碼：金鑰未設/過短 fail-closed（SECRET_UNSET）', () => {
  assert.throws(() => dyn.secretFromEnv({}), (e) => e.code === 'SECRET_UNSET');
  assert.throws(() => dyn.secretFromEnv({ ECT_DYNAMIC_CODE_SECRET: 'short' }), (e) => e.code === 'SECRET_UNSET');
});

test('動態碼：參數邊界（ticketId/seq 非法拒、時鐘未來窗拒）', () => {
  assert.throws(() => dyn.issueDynamicCode({ ticketId: 0, codeSeq: 0, secret: SECRET }));
  assert.throws(() => dyn.issueDynamicCode({ ticketId: 1, codeSeq: -1, secret: SECRET }));
  const now = Date.now();
  const future = dyn.issueDynamicCode({ ticketId: 1, codeSeq: 0, secret: SECRET, now: now + 120_000 });
  assert.equal(dyn.verifyDynamicCode(future, { secret: SECRET, now }).reason, 'CODE_EXPIRED');
});
