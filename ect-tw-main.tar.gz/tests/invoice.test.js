'use strict';
// M1 第二批：電子發票閘道（純函式）+ 編排層（mock PG client，不需真 DB）
// 特別涵蓋 P0 回歸：發票 DB 錯誤不得毒化付款／核銷的同一交易。
const test = require('node:test');
const assert = require('node:assert/strict');
const ezpay = require('../src/payments/ezpay');
const invoice = require('../src/engine/invoice');

const stubCfg = () => ezpay.assertConfig(ezpay.configFromEnv({
  ECT_INVOICE_PROVIDER: 'stub',
  ECT_INVOICE_ISSUE_POINT: 'ORDER',
  ECT_INVOICE_TIMEOUT_MS: '3000',
}));

const baseInput = () => ({
  orderNo: 'ECTTW20261118001', vendorId: 7, ticketId: 3,
  amountCents: 69900, itemName: '測試券',
});

async function withEnv(patch, fn) {
  const saved = {};
  for (const k of Object.keys(patch)) {
    saved[k] = process.env[k];
    process.env[k] = patch[k];
  }
  try { return await fn(); } finally {
    for (const k of Object.keys(patch)) {
      if (saved[k] === undefined) delete process.env[k];
      else process.env[k] = saved[k];
    }
  }
}

/**
 * 模擬 PG 交易的關鍵行為：任一 statement 錯誤後，整個 transaction 標為 aborted，
 * 後續 SQL 一律丟 'current transaction is aborted'，直到 ROLLBACK TO SAVEPOINT 才恢復。
 */
function mockClient(failPattern = null) {
  const calls = [];
  let aborted = false;
  return {
    calls,
    async query(sql, params) {
      const q = String(sql).replace(/\s+/g, ' ').trim();
      calls.push({ q, params });
      if (/^SAVEPOINT /i.test(q)) return { rowCount: 0, rows: [] };
      if (/^ROLLBACK TO SAVEPOINT /i.test(q)) { aborted = false; return { rowCount: 0, rows: [] }; }
      if (/^RELEASE SAVEPOINT /i.test(q)) return { rowCount: 0, rows: [] };
      if (aborted) throw new Error('current transaction is aborted, commands ignored');
      if (failPattern && failPattern.test(q)) {
        aborted = true;
        throw new Error('null value in column "vendor_id" violates not-null constraint');
      }
      if (q.startsWith('INSERT INTO invoices')) return { rowCount: 1, rows: [{ id: 42 }] };
      if (q.startsWith('INSERT INTO invoice_outbox')) return { rowCount: 1, rows: [] };
      if (q.startsWith('SELECT id FROM invoices')) return { rowCount: 1, rows: [{ id: 42 }] };
      return { rowCount: 0, rows: [] };
    },
  };
}

// ---- 金額與稅額 ----

test('splitTax：內含 5% 稅，銷售額＋稅額＝總額（699→666+33）', () => {
  for (const total of [1, 5, 100, 105, 699, 1000, 12345]) {
    const t = ezpay.splitTax(total);
    assert.equal(t.totalAmt, total);
    assert.equal(t.salesAmt + t.taxAmt, total, '稅額拆分必須守恆');
    assert.ok(t.taxAmt >= 0 && t.salesAmt > 0);
  }
  assert.deepEqual(ezpay.splitTax(699), { salesAmt: 666, taxAmt: 33, totalAmt: 699 });
  assert.throws(() => ezpay.splitTax(0), /BAD_AMOUNT/);
  assert.throws(() => ezpay.splitTax(1.5), /BAD_AMOUNT/);
});

test('toYuan：只接受正的整百分（整元），避免稅額算錯', () => {
  assert.equal(ezpay.toYuan(69900), 699);
  assert.throws(() => ezpay.toYuan(69950), /AMOUNT_NOT_WHOLE_YUAN/);
  assert.throws(() => ezpay.toYuan(0), /BAD_AMOUNT/);
  assert.throws(() => ezpay.toYuan(-100), /BAD_AMOUNT/);
  assert.throws(() => ezpay.toYuan(12.5), /BAD_AMOUNT/);
});

// ---- 請求正規化 ----

test('buildInvoiceRequest：捐贈碼與載具互斥，捐贈碼優先清空載具', () => {
  const cfg = stubCfg();
  const both = ezpay.buildInvoiceRequest({
    ...baseInput(), carrierId: '/ABC+123', donateCode: '1234567',
  }, cfg);
  assert.equal(both.donateCode, '1234567');
  assert.equal(both.carrierType, '');
  assert.equal(both.carrierId, '');
  assert.equal(both.printFlag, '0');

  const carrier = ezpay.buildInvoiceRequest({ ...baseInput(), carrierId: '/ABC+123' }, cfg);
  assert.equal(carrier.carrierType, 'MEMBER');
  assert.equal(carrier.carrierId, '/ABC+123');
  assert.equal(carrier.printFlag, '0');

  const paper = ezpay.buildInvoiceRequest(baseInput(), cfg);
  assert.equal(paper.printFlag, '1');
  assert.equal(paper.amountCents, 69900);
  assert.equal(paper.idempotencyKey, 'ORDER:ECTTW20261118001:ISSUE');
});

test('buildInvoiceRequest：輸入清洗與格式錯誤一律拒', () => {
  const cfg = stubCfg();
  assert.throws(() => ezpay.buildInvoiceRequest({ ...baseInput(), donateCode: 'ABC' }, cfg), /BAD_DONATE_CODE/);
  assert.throws(() => ezpay.buildInvoiceRequest({ ...baseInput(), buyerUnifiedNo: '123' }, cfg), /BAD_BUYER_UBN/);
  assert.throws(() => ezpay.buildInvoiceRequest({ ...baseInput(), amountCents: 69950 }, cfg), /AMOUNT_NOT_WHOLE_YUAN/);
  assert.throws(() => ezpay.buildInvoiceRequest({ ...baseInput(), orderNo: '', ticketId: null, ref: '' }, cfg), /BAD_REF/);
  const cleaned = ezpay.buildInvoiceRequest({ ...baseInput(), itemName: '<script>alert(1)</script>券' }, cfg);
  assert.ok(!cleaned.itemName.includes('<'), '品名須去除 HTML 控制字元');
});

test('部分核銷：ref 帶殘值讓每次核銷各開一張，重送則同鍵（冪等）', () => {
  const cfg = stubCfg();
  const a = ezpay.buildInvoiceRequest({ ...baseInput(), ref: 'R3X70000', amountCents: 30000 }, cfg);
  const b = ezpay.buildInvoiceRequest({ ...baseInput(), ref: 'R3X40000', amountCents: 30000 }, cfg);
  const again = ezpay.buildInvoiceRequest({ ...baseInput(), ref: 'R3X70000', amountCents: 30000 }, cfg);
  assert.notEqual(a.idempotencyKey, b.idempotencyKey);
  assert.equal(a.idempotencyKey, again.idempotencyKey);
});

// ---- fail-closed ----

test('assertConfig：組態不完整一律拒，ezpay 未設 host 不會誤送', () => {
  const ok = { provider: 'stub', issuePoint: 'ORDER', timeoutMs: 3000, host: '', merchantId: '', hashKey: '', hashIV: '', webhook: '', webhookToken: '' };
  assert.equal(ezpay.assertConfig(ok), ok);
  assert.throws(() => ezpay.assertConfig({ ...ok, provider: 'nope' }), /BAD_PROVIDER/);
  assert.throws(() => ezpay.assertConfig({ ...ok, issuePoint: 'X' }), /BAD_ISSUE_POINT/);
  assert.throws(() => ezpay.assertConfig({ ...ok, timeoutMs: 10 }), /BAD_TIMEOUT/);
  assert.throws(() => ezpay.assertConfig({ ...ok, provider: 'http' }), /WEBHOOK_UNSET/);
  assert.throws(() => ezpay.assertConfig({ ...ok, provider: 'ezpay' }), /EZPAY_HOST_UNSET/);
  assert.throws(() => ezpay.assertConfig({ ...ok, provider: 'ezpay', host: 'https://x', merchantId: 'MS1' }), /BAD_HASH_KEY/);
  assert.throws(() => ezpay.assertConfig({
    ...ok, provider: 'ezpay', host: 'https://x', merchantId: 'MS1',
    hashKey: 'x'.repeat(32), hashIV: 'short',
  }), /BAD_HASH_IV/);
});

test('parseIssueResponse：JSON／query string／明確失敗／空回應皆正確判定', () => {
  const okJson = ezpay.parseIssueResponse('{"Status":"SUCCESS","InvoiceNo":"AB12345678","InvoiceDate":"2026-11-18"}');
  assert.equal(okJson.ok, true);
  assert.equal(okJson.invoiceNo, 'AB12345678');
  assert.equal(okJson.simulated, false);

  const okQs = ezpay.parseIssueResponse('Status=SUCCESS&InvoiceNo=CD98765432&RandomNumber=1234');
  assert.equal(okQs.ok, true);
  assert.equal(okQs.invoiceNo, 'CD98765432');

  assert.equal(ezpay.parseIssueResponse('{"Status":"FAILED","Message":"餘額不足"}').reason, 'PROVIDER_REJECT');
  assert.equal(ezpay.parseIssueResponse('').reason, 'EMPTY_RESPONSE');
  assert.equal(ezpay.parseIssueResponse('   ').reason, 'EMPTY_RESPONSE');
  assert.equal(ezpay.parseIssueResponse('{"foo":1}').reason, 'UNRECOGNIZED_RESPONSE');
});

test('sendIssue stub：模擬開立可預期且同冪等鍵同號（不呼叫加值中心）', async () => {
  const cfg = stubCfg();
  const req = ezpay.buildInvoiceRequest(baseInput(), cfg);
  const a = await ezpay.sendIssue(req, cfg);
  const b = await ezpay.sendIssue(req, cfg);
  assert.equal(a.ok, true);
  assert.equal(a.simulated, true);
  assert.match(a.invoiceNo, /^STUB[0-9A-F]{10}$/);
  assert.equal(a.invoiceNo, b.invoiceNo, '同冪等鍵不得產生不同發票號');
});

test('toEzpayParams：稅額與總額對應（欄位名待官方文件對齊）', () => {
  const cfg = { ...stubCfg(), merchantId: 'MS123' };
  const req = ezpay.buildInvoiceRequest(baseInput(), cfg);
  const p = ezpay.toEzpayParams(req, cfg);
  assert.equal(p.MerchantID_, 'MS123');
  assert.equal(p.TotalAmt, 699);
  assert.equal(p.AmtSales, 666);
  assert.equal(p.AmtTax, 33);
  assert.equal(p.TaxRate, '5');
});

// ---- 編排層：SAVEPOINT 與 fail-safe ----

test('正常入隊：SAVEPOINT → invoices → outbox(QUEUED) → RELEASE', async () => {
  await withEnv({ ECT_INVOICE_ISSUE_POINT: 'ORDER', ECT_INVOICE_PROVIDER: 'stub' }, async () => {
    const c = mockClient();
    const out = await invoice.maybeEnqueue(c, 'ORDER', baseInput());
    assert.deepEqual(out, { id: 42, duplicate: false });
    assert.ok(c.calls.some((x) => /^SAVEPOINT /.test(x.q)));
    assert.ok(c.calls.some((x) => x.q.startsWith('INSERT INTO invoices')));
    const queued = c.calls.find((x) => x.q.startsWith('INSERT INTO invoice_outbox') && x.params[3] === 'QUEUED');
    assert.ok(queued, '入隊成功要留 QUEUED 軌跡');
    assert.equal(queued.params[5].includes('"ref"'), true);
    assert.ok(c.calls.some((x) => /^RELEASE SAVEPOINT /.test(x.q)));
  });
});

test('🔴 P0 回歸：發票 DB 錯誤不得毒化主交易（ROLLBACK TO → 仍能留痕 → 回傳 null）', async () => {
  await withEnv({ ECT_INVOICE_ISSUE_POINT: 'ORDER', ECT_INVOICE_PROVIDER: 'stub' }, async () => {
    const c = mockClient(/^INSERT INTO invoices/);
    let out;
    let threw = null;
    try { out = await invoice.maybeEnqueue(c, 'ORDER', baseInput()); } catch (err) { threw = err; }
    assert.equal(threw, null, '發票失敗絕不可外拋，否則付款／核銷交易會被回滾');
    assert.equal(out, null);
    assert.ok(c.calls.some((x) => /^ROLLBACK TO SAVEPOINT /.test(x.q)), '必須先解除 aborted 狀態');
    const failed = c.calls.find((x) => x.q.startsWith('INSERT INTO invoice_outbox') && x.params[3] === 'FAILED');
    assert.ok(failed, '交易恢復後仍須寫入 FAILED 軌跡（沒有 ROLLBACK 這句會被 aborted 擋下）');
    assert.ok(String(failed.params[4]).includes('vendor_id'));
    assert.ok(c.calls.some((x) => /^RELEASE SAVEPOINT /.test(x.q)));
  });
});

test('正規化失敗（非整元）也要留痕，但不寫 invoices、不外拋', async () => {
  await withEnv({ ECT_INVOICE_ISSUE_POINT: 'ORDER', ECT_INVOICE_PROVIDER: 'stub' }, async () => {
    const c = mockClient();
    const out = await invoice.maybeEnqueue(c, 'ORDER', { ...baseInput(), amountCents: 69950 });
    assert.equal(out, null);
    assert.ok(!c.calls.some((x) => x.q.startsWith('INSERT INTO invoices')));
    const failed = c.calls.find((x) => x.q.startsWith('INSERT INTO invoice_outbox') && x.params[3] === 'FAILED');
    assert.ok(failed);
    assert.ok(String(failed.params[4]).includes('AMOUNT_NOT_WHOLE_YUAN'));
  });
});

test('非本開立時點：留 SKIPPED 軌跡，不產生發票', async () => {
  await withEnv({ ECT_INVOICE_ISSUE_POINT: 'REDEEM', ECT_INVOICE_PROVIDER: 'stub' }, async () => {
    const c = mockClient();
    const out = await invoice.maybeEnqueue(c, 'ORDER', baseInput());
    assert.equal(out, null);
    assert.equal(invoice.issuePoint(), 'REDEEM');
    assert.ok(!c.calls.some((x) => x.q.startsWith('INSERT INTO invoices')));
    assert.ok(c.calls.some((x) => x.q.startsWith('INSERT INTO invoice_outbox') && x.params[3] === 'SKIPPED'));
  });
});

test('重複入隊（冪等鍵衝突）回傳既有 id 且 duplicate=true', async () => {
  await withEnv({ ECT_INVOICE_ISSUE_POINT: 'ORDER', ECT_INVOICE_PROVIDER: 'stub' }, async () => {
    const c = {
      calls: [],
      async query(sql, params) {
        const q = String(sql).replace(/\s+/g, ' ').trim();
        this.calls.push({ q, params });
        if (/^SAVEPOINT |^ROLLBACK TO SAVEPOINT |^RELEASE SAVEPOINT /i.test(q)) return { rowCount: 0, rows: [] };
        if (q.startsWith('INSERT INTO invoices')) return { rowCount: 0, rows: [] };
        if (q.startsWith('SELECT id FROM invoices')) return { rowCount: 1, rows: [{ id: 77 }] };
        return { rowCount: 1, rows: [] };
      },
    };
    const out = await invoice.maybeEnqueue(c, 'ORDER', baseInput());
    assert.deepEqual(out, { id: 77, duplicate: true });
    assert.ok(!c.calls.some((x) => x.q.startsWith('INSERT INTO invoice_outbox')), '重複不該再寫 QUEUED');
  });
});

test('編排層常數與組態：MAX_ATTEMPTS、issuePoint、provider 皆在合法集合內', () => {
  assert.equal(invoice.MAX_ATTEMPTS, 5);
  assert.ok(ezpay.PROVIDERS.includes(invoice.configFromEnv().provider), 'provider 必須是已實作的通道');
  assert.ok(ezpay.ISSUE_POINTS.includes(invoice.issuePoint()), '開立時點只能是 ORDER / REDEEM');
  assert.deepEqual([...ezpay.ISSUE_POINTS], ['ORDER', 'REDEEM']);
});
