'use strict';
// 批次②前端骨架與紅線靜態守門：不需瀏覽器即可驗證「寫了但不對外生效」。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { scanText } = require('../scripts/check-banned-words');

const ROOT = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');
const html = read('apps/web/liff/index.html');
const js = read('apps/web/liff/liff.js');
const css = read('apps/web/liff/liff.css');

test('LIFF 三檔存在且 HTML 零 inline script、外部 CSS/JS', () => {
  assert.ok(html.length > 300 && js.length > 300 && css.length > 300);
  assert.ok(!/<script(?![^>]*\bsrc=)/i.test(html), '不得有 inline script');
  assert.match(html, /<script src="liff\.js"><\/script>/);
  assert.match(html, /<link rel="stylesheet" href="liff\.css">/);
});

test('🔴 ect-liff-id 必須為空：未開通時 SDK 不載入、不送出請求', () => {
  assert.match(html, /<meta name="ect-liff-id" content="">/);
  assert.match(js, /if \(!liffId\)/);
  // 早退分支內不得出現 fetch／postSession 呼叫
  const early = js.slice(js.indexOf('if (!liffId)'), js.indexOf('function loadSdk'));
  assert.ok(early.includes('return;'), '空值必須直接 return');
  assert.ok(!early.includes('fetch('), '空值分支不得送出請求');
  assert.ok(!early.includes('postSession('), '空值分支不得換 session');
});

test('🔴 對外不提供尚未開通的入口連結（line.me / lin.ee 零命中）', () => {
  assert.ok(!/line\.me/i.test(html), 'HTML 不得出現 line.me');
  assert.ok(!/lin\.ee/i.test(html), 'HTML 不得出現 lin.ee');
  // SDK CDN 是程式資源，且僅在 liffId 有值時才動態載入（見另一支測試）
  assert.ok(!/https:\/\/liff\.line\.me/i.test(js), '不得寫死 LIFF 入口網址');
});

test('LIFF JS：禁用 innerHTML／eval／document.write，動態文字走 textContent', () => {
  assert.ok(!/innerHTML|outerHTML|document\.write|eval\(/i.test(js));
  assert.ok(js.includes('textContent'));
  assert.ok(js.includes('credentials: \'include\''), '跨域換 session 須帶 cookie');
  assert.ok(js.includes('/api/auth/line/session'));
});

test('🔴 紅線守門：階段1 只放行 /api/auth/*，其餘寫操作仍全數 404', () => {
  const conf = read('deploy/nginx/ssl.conf');
  // 先剝掉 # 註解：ssl.conf 的說明列會列舉被擋的路徑，直接 includes 會誤判成放行。
  const body = conf.split(/\r?\n/).filter((l) => !/^\s*#/.test(l)).join('\n');
  // 交叉驗證抓法本身：剝完仍看得到真實規則，且不是空字串（避免改成永真）。
  assert.ok(body.includes('location = /health'));
  assert.ok(body.includes('location /api/public/'));
  assert.match(body, /location \/api\/auth\/ \{\s*proxy_pass http:\/\/app:3000;/);
  // 🔴 只看「實際 location 指令」不看註解，避免列舉文字造成誤判／反向永真。
  const opened = [...body.matchAll(/^\s*location\s+([^\s{]+)/gm)].map((m) => m[1]);
  assert.ok(opened.length >= 5, '抓法必須真的抓到多條規則');
  for (const p of ['/api/transfer', '/api/pay', '/api/admin', '/api/verify', '/admin', '/verify']) {
    assert.ok(!opened.some((x) => x.startsWith(p)), `${p} 不得在階段1 放行`);
  }
  assert.match(body, /location \/ \{\s*return 404;/);
});

test('🔴 紅線守門：首頁「建置中」與 statusNote 未因本批被偷改', () => {
  const copy = require('../config/copy');
  assert.equal(copy.web.statusBuilding, '建置中');
  assert.match(copy.web.lineV1.statusNote, /尚未開放/);
  const home = read('apps/web/index.html');
  assert.ok(!/line\.me|lin\.ee/i.test(home), '首頁不得新增 LINE 入口連結');
});

test('後端接線：server 掛 authRoutes；transfer 單一注入點已改 session', () => {
  const server = read('src/server.js');
  const transfer = read('src/routes/transfer.js');
  assert.match(server, /require\('\.\/routes\/auth'\)/);
  assert.match(server, /app\.use\(authRoutes\)/);
  assert.match(transfer, /requireSession/);
  assert.ok(!/req\.get\('x-user-id'\)/.test(transfer), '舊 header 讀取點必須移除');
  assert.match(transfer, /module\.exports\.userGate = userGate/);
});

test('三檔對外文案皆無法規禁用語', () => {
  for (const [name, text] of [['index.html', html], ['liff.js', js], ['liff.css', css]]) {
    assert.deepEqual(scanText(text), [], `${name} 命中禁用語`);
  }
});
