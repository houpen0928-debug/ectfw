'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const COPY = require('../config/copy');
const { scanText, scanTextCross, selftest } = require('../scripts/check-banned-words');
const {
  ecpayUrlEncode,
  buildCheckMacValue,
  verifyCheckMacValue,
  createAioCheckout,
  twStamp,
} = require('../src/payments/ecpay');

function collectStrings(value) {
  if (typeof value === 'string') return [value];
  if (Array.isArray(value)) return value.flatMap(collectStrings);
  if (value && typeof value === 'object') return Object.values(value).flatMap(collectStrings);
  return [];
}

test('禁詞掃描器 selftest 全數通過', () => {
  for (const x of selftest()) assert.ok(x.ok, x.name);
});

test('兩種獨立抓法在所有樣本上結果一致', () => {
  const samples = ['', '正常使用方式', '本券有使用期限', '逾期作廢', '到期失效'];
  for (const s of samples) {
    assert.deepEqual(scanText(s), scanTextCross(s));
  }
});

test('文案庫所有對外字串不含法規禁用語', () => {
  const strings = collectStrings(COPY);
  assert.ok(strings.length > 10, '文案庫應有內容');
  for (const s of strings) {
    assert.deepEqual(scanText(s), [], `命中禁詞：${s}`);
  }
});

test('綠界 CheckMacValue：產生、驗簽、竄改拒絕', () => {
  const key = 'testHashKey';
  const iv = 'testHashIV';
  const params = {
    MerchantID: '2000132',
    MerchantTradeNo: 'ECTTW20261118001',
    MerchantTradeDate: '2026/11/18 11:40:35',
    PaymentType: 'aio',
    TotalAmount: '100',
    TradeDesc: 'ECT-TW',
    ItemName: '保底流通券',
    ChoosePayment: 'ALL',
    EncryptType: '1',
  };
  const mac = buildCheckMacValue(params, key, iv);
  assert.match(mac, /^[0-9A-F]{64}$/);
  assert.equal(verifyCheckMacValue({ ...params, CheckMacValue: mac }, key, iv), true);
  assert.equal(verifyCheckMacValue(params, key, iv), false, '缺簽章應拒');
  assert.equal(
    verifyCheckMacValue({ ...params, TotalAmount: '999', CheckMacValue: mac }, key, iv),
    false,
    '竄改金額應拒'
  );
  assert.equal(
    verifyCheckMacValue({ ...params, CheckMacValue: mac }, 'wrongKey', iv),
    false,
    '錯金鑰應拒'
  );
});

test('綠界 URL encode 規則與台灣時戳', () => {
  assert.equal(ecpayUrlEncode('A-B'), 'a-b');
  assert.equal(ecpayUrlEncode('a b'), 'a%20b');
  assert.ok(!ecpayUrlEncode('x~y').includes('%7e'));
  assert.match(twStamp(new Date('2026-11-18T03:40:35Z')), /^2026\/11\/18 11:40:35$/);
});

test('AIO 下單參數自帶簽章且可驗證', () => {
  const cfg = { merchantId: '2000132', hashKey: 'k', hashIV: 'v' };
  const p = createAioCheckout(
    { merchantTradeNo: 'ECTTW001', totalCents: 23040, itemName: '中秋禮券', returnURL: 'https://twect.com.tw/api/pay/notify' },
    cfg
  );
  assert.equal(p.TotalAmount, '230');
  assert.equal(verifyCheckMacValue(p, cfg.hashKey, cfg.hashIV), true);
});
