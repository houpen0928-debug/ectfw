'use strict';
// 券引擎狀態機：完整轉移矩陣 + 法遵不變量（無 EXPIRED、殘值不歸零）
const test = require('node:test');
const assert = require('node:assert/strict');
const { STATES, ACTIONS, TERMINAL, transition, sha256 } = require('../src/engine/tickets');

test('法遵：狀態集合不含 EXPIRED，且終態只有 USED/CONVERTED/CHARITY', () => {
  const all = Object.values(STATES);
  assert.ok(!all.includes('EXPIRED'), '台灣版不得有逾期作廢終態');
  assert.deepEqual([...TERMINAL].sort(), ['CHARITY', 'CONVERTED', 'USED']);
});

test('ISSUE→UNBOUND→BIND→BOUND：歸戶需 owner，重複綁定拒', () => {
  const r = transition(STATES.UNBOUND, ACTIONS.BIND, { ownerUserId: 7, residualCents: 1000 });
  assert.equal(r.ok, true);
  assert.equal(r.state, STATES.BOUND);
  assert.equal(r.residualCents, 1000);
  assert.equal(transition(STATES.UNBOUND, ACTIONS.BIND, { residualCents: 1000 }).reason, 'OWNER_REQUIRED');
  assert.equal(transition(STATES.BOUND, ACTIONS.BIND, { ownerUserId: 7, residualCents: 1000 }).reason, 'MUST_BE_UNBOUND');
});

test('部分核銷：residual 完整保留、狀態不變；全額核銷才進 USED', () => {
  const partial = transition(STATES.BOUND, ACTIONS.REDEEM, { amountCents: 300, residualCents: 1000 });
  assert.equal(partial.ok, true);
  assert.equal(partial.state, STATES.BOUND);
  assert.equal(partial.residualCents, 700);
  assert.equal(partial.journal, 'REDEEM_PARTIAL');
  const full = transition(STATES.BOUND, ACTIONS.REDEEM, { amountCents: 1000, residualCents: 1000 });
  assert.equal(full.state, STATES.USED);
  assert.equal(full.residualCents, 0);
  assert.equal(full.journal, 'REDEEM_FULL');
});

test('GRACE：優惠期間結束可從 UNBOUND/BOUND 進入，價值一分不減', () => {
  for (const from of [STATES.UNBOUND, STATES.BOUND]) {
    const r = transition(from, ACTIONS.GRACE_ENTER, { residualCents: 880 });
    assert.equal(r.ok, true);
    assert.equal(r.state, STATES.GRACE);
    assert.equal(r.residualCents, 880, 'GRACE 不得減損殘值');
  }
  assert.equal(transition(STATES.GRACE, ACTIONS.GRACE_ENTER, { residualCents: 1 }).reason, 'INVALID_GRACE_SOURCE');
});

test('GRACE 仍可全額/部分核銷：不會因優惠期間結束而失效', () => {
  assert.equal(transition(STATES.GRACE, ACTIONS.REDEEM, { amountCents: 100, residualCents: 880 }).state, STATES.GRACE);
  assert.equal(transition(STATES.GRACE, ACTIONS.REDEEM, { amountCents: 880, residualCents: 880 }).state, STATES.USED);
});

test('CONVERT：殘值全額轉點數（不歸零消失），需 owner 且有殘值', () => {
  const r = transition(STATES.GRACE, ACTIONS.CONVERT, { ownerUserId: 7, residualCents: 880 });
  assert.equal(r.state, STATES.CONVERTED);
  assert.equal(r.residualCents, 0); // 券終結，價值已移到點數帳（由 PG 層入帳）
  assert.equal(transition(STATES.GRACE, ACTIONS.CONVERT, { residualCents: 880 }).reason, 'OWNER_REQUIRED');
  assert.equal(transition(STATES.GRACE, ACTIONS.CONVERT, { ownerUserId: 7, residualCents: 0 }).reason, 'NO_RESIDUAL');
});

test('DONATE：BOUND/GRACE 皆可轉公益；終態一律拒絕任何動作', () => {
  for (const from of [STATES.BOUND, STATES.GRACE]) {
    assert.equal(transition(from, ACTIONS.DONATE, { residualCents: 500 }).state, STATES.CHARITY);
  }
  for (const s of TERMINAL) {
    for (const a of [ACTIONS.BIND, ACTIONS.REDEEM, ACTIONS.GRACE_ENTER, ACTIONS.CONVERT, ACTIONS.DONATE]) {
      assert.equal(transition(s, a, { ownerUserId: 1, amountCents: 1, residualCents: 100 }).reason,
        'TERMINAL_STATE');
    }
  }
});

test('PG bigint 字串輸入：狀態機以 Number 正規化，殘值運算仍正確', () => {
  // node-pg 會把 BIGINT 回傳成字串；狀態機不可因此算出 '700' 這類字串拼接
  const r = transition(STATES.BOUND, ACTIONS.REDEEM, { amountCents: 300, residualCents: '1000' });
  assert.equal(r.residualCents, 700);
  assert.equal(typeof r.residualCents, 'number');
});

test('邊界：金額非整數/為負/超過殘值/未知動作/非法狀態全拒', () => {
  const c = { residualCents: 100 };
  assert.equal(transition(STATES.BOUND, ACTIONS.REDEEM, { ...c, amountCents: 0 }).reason, 'BAD_AMOUNT');
  assert.equal(transition(STATES.BOUND, ACTIONS.REDEEM, { ...c, amountCents: -1 }).reason, 'BAD_AMOUNT');
  assert.equal(transition(STATES.BOUND, ACTIONS.REDEEM, { ...c, amountCents: 1.5 }).reason, 'BAD_AMOUNT');
  assert.equal(transition(STATES.BOUND, ACTIONS.REDEEM, { ...c, amountCents: 101 }).reason, 'AMOUNT_EXCEEDS_RESIDUAL');
  assert.equal(transition(STATES.BOUND, 'NOPE', c).reason, 'UNKNOWN_ACTION');
  assert.equal(transition('EXPIRED', ACTIONS.BIND, c).reason, 'BAD_STATE');
});

test('券碼雜湊：穩定、不同輸入不同值、64 碼 hex', () => {
  assert.equal(sha256('abc'), sha256('abc'));
  assert.notEqual(sha256('abc'), sha256('abd'));
  assert.match(sha256('abc'), /^[0-9a-f]{64}$/);
});
