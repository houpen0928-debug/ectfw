'use strict';
// 藍新工具層測試。金鑰為藍新官方技術手冊公開的測試值，非任何真實商店憑證。
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const nb = require('../src/payments/newebpay');

const KEY = 'Fs5cX1TGqYM2PpdbE14a9H83YQSQF5jn'; // 32 bytes
const IV = 'C6AcmfqJILwgnhIP';                   // 16 bytes
const MID = 'MS127874575';
const cfg = (over = {}) => ({
  merchantId: MID, hashKey: KEY, hashIV: IV, enabled: true, sandbox: true,
  returnURL: 'https://twect.com.tw/pay/newebpay/return',
  notifyURL: 'https://twect.com.tw/pay/newebpay/notify',
  clientBackURL: '', ...over,
});

// 獨立第二種實作：不呼叫本專案任何函式，直接用 Node crypto 手算（交叉驗證用）
function independentEncrypt(qs, key, iv) {
  const c = crypto.createCipheriv('aes-256-cbc', Buffer.from(key, 'utf8'), Buffer.from(iv, 'utf8'));
  return c.update(qs, 'utf8', 'hex') + c.final('hex');
}
function independentDecrypt(hex, key, iv) {
  const d = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key, 'utf8'), Buffer.from(iv, 'utf8'));
  return d.update(hex, 'hex', 'utf8') + d.final('utf8');
}
function independentSha(hex, key, iv) {
  return crypto.createHash('sha256')
    .update(`HashKey=${key}&${hex}&HashIV=${iv}`).digest('hex').toUpperCase();
}

test('TradeInfo：小寫 hex、AES block 對齊，且與獨立實作逐字相同', () => {
  const qs = 'MerchantID=MS127874575&RespondType=JSON&TimeStamp=1695795410&Version=2.0&MerchantOrderNo=ECT1695795410&Amt=699&ItemDesc=ECT-TW';
  const mine = nb.encryptTradeInfo(qs, KEY, IV);
  assert.match(mine, /^[0-9a-f]+$/);
  assert.equal(mine.length % 32, 0);
  assert.equal(mine, independentEncrypt(qs, KEY, IV), '兩種獨立加密結果必須一致');
});

test('TradeInfo 解密：本專案解密 == 獨立解密 == 原始 query', () => {
  const params = { MerchantID: MID, Amt: 699, ItemDesc: '保底流通券', NotifyURL: 'https://twect.com.tw/pay/n' };
  const hex = nb.encryptTradeInfo(params, KEY, IV);
  const qs = nb.buildQuery(params);
  assert.equal(independentDecrypt(hex, KEY, IV), qs);
  // query string 還原後所有值皆為字串（藍新回呼亦然，故清算層需 Number() 轉型）
  assert.deepEqual(nb.decryptTradeInfo(hex, KEY, IV), {
    MerchantID: MID, Amt: '699', ItemDesc: '保底流通券', NotifyURL: 'https://twect.com.tw/pay/n',
  });
});

test('TradeSha：與官方公式手算一致，且為 64 碼大寫', () => {
  const hex = nb.encryptTradeInfo({ Amt: 699 }, KEY, IV);
  const sha = nb.buildTradeSha(hex, KEY, IV);
  assert.match(sha, /^[0-9A-F]{64}$/);
  assert.equal(sha, independentSha(hex, KEY, IV));
});

test('驗簽：正確通過；竄改 / 錯金鑰 / 缺簽 / 大小寫不敏感', () => {
  const hex = nb.encryptTradeInfo({ Amt: 699 }, KEY, IV);
  const sha = nb.buildTradeSha(hex, KEY, IV);
  assert.equal(nb.verifyTradeSha(hex, sha, KEY, IV), true);
  assert.equal(nb.verifyTradeSha(hex.toLowerCase(), sha, KEY, IV), true, 'hex 大小寫不影響');
  assert.equal(nb.verifyTradeSha(hex, sha.toLowerCase(), KEY, IV), true, 'sha 大小寫不影響');
  assert.equal(nb.verifyTradeSha(hex.replace(/^./, '0'), sha, KEY, IV), false, '竄改密文應拒');
  assert.equal(nb.verifyTradeSha(hex, sha, 'X'.repeat(32), IV), false, '錯金鑰應拒');
  assert.equal(nb.verifyTradeSha(hex, '', KEY, IV), false, '缺簽應拒');
  assert.equal(nb.verifyTradeSha(hex, 'AA', KEY, IV), false, '長度不符不應拋例外');
});

test('MerchantOrderNo：≤30 英數、固定前綴、尾 5 碼隨機', () => {
  const a = nb.merchantOrderNo('ECT', 1695795410000);
  assert.match(a, /^[A-Za-z0-9]{1,30}$/);
  assert.ok(a.startsWith('ECT'));
  const set = new Set(Array.from({ length: 200 }, () => nb.merchantOrderNo('ECT', 1695795410000)));
  assert.ok(set.size > 150, '同秒多次產生應有足夠分散度');
});

test('MPG 表單：外層 5 欄、Version/EncryptType、action 依 sandbox', () => {
  const form = nb.createMpgForm({ amountCents: 69900, itemDesc: '平台服務費' }, cfg());
  assert.deepEqual(Object.keys(form.fields), ['MerchantID', 'TradeInfo', 'TradeSha', 'Version', 'EncryptType']);
  assert.equal(form.fields.Version, '2.0');
  assert.equal(form.fields.EncryptType, '0');
  assert.equal(form.action, 'https://ccore.newebpay.com/MPG/mpg_gateway');
  const prod = nb.createMpgForm({ amountCents: 69900 }, cfg({ sandbox: false }));
  assert.equal(prod.action, 'https://core.newebpay.com/MPG/mpg_gateway');
  assert.equal(prod.inner.Amt, 699);
  assert.match(prod.inner.MerchantOrderNo, /^[A-Za-z0-9]{1,30}$/);
});

test('fail-closed：未啟用 / 金鑰長度錯 / 缺 NotifyURL / 金額非正', () => {
  const base = { amountCents: 69900 };
  assert.throws(() => nb.createMpgForm(base, cfg({ enabled: false })), /NEWEBPAY_DISABLED/);
  assert.throws(() => nb.createMpgForm(base, cfg({ hashKey: 'short' })), /BAD_HASH_KEY/);
  assert.throws(() => nb.createMpgForm(base, cfg({ hashIV: 'short' })), /BAD_HASH_IV/);
  assert.throws(() => nb.createMpgForm(base, cfg({ notifyURL: '' })), /NOTIFY_URL_REQUIRED/);
  assert.throws(() => nb.createMpgForm({ amountCents: 0 }, cfg()), /BAD_AMOUNT/);
  assert.throws(() => nb.createMpgForm({ amountCents: 69900, merchantOrderNo: 'bad-no!' }, cfg()), /BAD_MERCHANT_ORDER_NO/);
});

// 造一筆合法回呼（模擬藍新 server-to-server）
function makeNotify(over = {}) {
  const inner = {
    Status: 'SUCCESS', Message: '授權成功', MerchantID: MID, Amt: 699,
    TradeNo: '20261118131000001', MerchantOrderNo: 'ECT169579541000001',
    PaymentType: 'CREDIT', PayTime: '2026-11-18 13:10:00', ...over,
  };
  const TradeInfo = nb.encryptTradeInfo(inner, KEY, IV);
  return {
    Status: 'SUCCESS', MerchantID: MID, Version: '2.0',
    TradeInfo, TradeSha: nb.buildTradeSha(TradeInfo, KEY, IV), inner,
  };
}

test('parseNotify：合法回呼解密還原完整結果', () => {
  const n = makeNotify();
  const r = nb.parseNotify(n, cfg());
  assert.equal(r.ok, true);
  assert.equal(r.reason, 'OK');
  assert.equal(r.result.Amt, '699');
  assert.equal(r.result.MerchantOrderNo, n.inner.MerchantOrderNo);
});

test('parseNotify：偽造簽章 / 商店代號不符 / 壞密文 / 未啟用 / 壞金鑰全拒', () => {
  const n = makeNotify();
  assert.equal(nb.parseNotify({ ...n, TradeSha: 'F'.repeat(64) }, cfg()).reason, 'BAD_SIGNATURE');
  assert.equal(nb.parseNotify({ ...n, MerchantID: 'MS9999999999' }, cfg()).reason, 'MERCHANT_ID_MISMATCH');
  assert.equal(nb.parseNotify({ ...n, TradeInfo: 'zz' }, cfg()).reason, 'BAD_SIGNATURE');
  assert.equal(nb.parseNotify(n, cfg({ enabled: false })).reason, 'FAIL_CLOSED');
  assert.equal(nb.parseNotify(n, cfg({ hashKey: 'short' })).reason, 'BAD_KEY_CONFIG');
  // 內層 MerchantID 與外層不同（簽章合法但內容矛盾）→ 仍拒
  const bad = makeNotify({ MerchantID: 'MS8888888888' });
  assert.equal(nb.parseNotify(bad, cfg()).reason, 'INNER_MERCHANT_MISMATCH');
});

test('parseFormBody：自解析 form-urlencoded（+ 號、URL encode、無等號）', () => {
  assert.deepEqual(nb.parseFormBody('A=1&B=hello+world&C=a%26b&D'), {
    A: '1', B: 'hello world', C: 'a&b', D: '',
  });
  const obj = { A: '1' };
  assert.equal(nb.parseFormBody(obj), obj, '已解析物件直接回傳');
});
