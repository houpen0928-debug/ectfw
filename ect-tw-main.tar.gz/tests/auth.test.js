'use strict';
// 批次②身份骨架單元測試：純函式＋假 req/res，不需真 LINE、不需真 DB、不需網路。
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../src/auth/session');
const L = require('../src/auth/line');

const SECRET = 'unit-test-session-secret-0123456789';
const NOW = 1_700_000_000_000;
const CFG = { channelId: '1234567890', channelSecret: 'dummy-channel-secret', redirectUri: 'https://api.twect.com.tw/api/auth/line/callback' };

function fakeReq(headers = {}) { return { headers }; }
function fakeRes() {
  const r = { statusCode: null, body: null, headers: {} };
  r.status = (c) => { r.statusCode = c; return r; };
  r.json = (b) => { r.body = b; return r; };
  r.set = (k, v) => { r.headers[k] = v; return r; };
  return r;
}
function runGate(gate, req) {
  const res = fakeRes();
  let nexted = false;
  gate(req, res, () => { nexted = true; });
  return { nexted, res, req };
}

test('session：簽發→驗證可取回 uid／lineUid', () => {
  const token = S.issueSession({ uid: 7, lineUid: 'Uabc', secret: SECRET, now: NOW });
  const p = S.verifySession(token, SECRET, NOW);
  assert.equal(p.uid, 7);
  assert.equal(p.lineUid, 'Uabc');
  assert.equal(p.kind, 'session');
});

test('session：篡改簽章／改 payload／超時限／壞格式／錯金鑰全拒', () => {
  const token = S.issueSession({ uid: 7, secret: SECRET, now: NOW });
  const [body, mac] = token.split('.');
  assert.equal(S.verifySession(`${body}.${mac.slice(0, -1)}0`, SECRET, NOW), null);
  const forgedBody = Buffer.from(JSON.stringify({ kind: 'session', uid: 999, exp: NOW + 60_000 })).toString('base64url');
  assert.equal(S.verifySession(`${forgedBody}.${mac}`, SECRET, NOW), null);
  assert.equal(S.verifySession(token, SECRET, NOW + 8 * 24 * 60 * 60 * 1000), null);
  assert.equal(S.verifySession('not-a-token', SECRET, NOW), null);
  assert.equal(S.verifySession(null, SECRET, NOW), null);
  assert.equal(S.verifySession(token, 'another-secret-0123456789', NOW), null);
});

test('session：金鑰未設／樣板值／過短 fail-closed（SESSION_SECRET_UNSET）', () => {
  assert.throws(() => S.sessionSecretFromEnv({}), (e) => e.code === 'SESSION_SECRET_UNSET');
  assert.throws(() => S.sessionSecretFromEnv({ ECT_SESSION_SECRET: 'short' }), (e) => e.code === 'SESSION_SECRET_UNSET');
  assert.throws(() => S.sessionSecretFromEnv({ ECT_SESSION_SECRET: 'replace-with-random-32-bytes' }), (e) => e.code === 'SESSION_SECRET_UNSET');
  assert.equal(S.sessionSecretFromEnv({ ECT_SESSION_SECRET: SECRET }), SECRET);
});

test('🔴 紅線：正式環境即使帶 X-User-Id 也一律 401', () => {
  const gate = S.createRequireSession({
    secret: SECRET, now: NOW,
    env: { ECT_NODE_ENV: 'production', ECT_ALLOW_DEV_HEADER: '1' },
  });
  const r = runGate(gate, fakeReq({ 'x-user-id': '7' }));
  assert.equal(r.nexted, false);
  assert.equal(r.res.statusCode, 401);
  assert.deepEqual(r.res.body, { error: 'unauthorized' });
});

test('🔴 紅線：預設（未開 dev 開關）帶 X-User-Id 也 401', () => {
  const gate = S.createRequireSession({ secret: SECRET, now: NOW, env: {} });
  assert.equal(runGate(gate, fakeReq({ 'x-user-id': '7' })).res.statusCode, 401);
  assert.equal(runGate(gate, fakeReq({})).res.statusCode, 401);
});

test('dev 適配器：雙重條件成立才接受 X-User-Id', () => {
  const gate = S.createRequireSession({
    secret: SECRET, now: NOW,
    env: { ECT_NODE_ENV: 'development', ECT_ALLOW_DEV_HEADER: '1' },
  });
  const ok = runGate(gate, fakeReq({ 'x-user-id': '7' }));
  assert.equal(ok.nexted, true);
  assert.equal(ok.req.userId, 7);
  assert.equal(ok.req.session.kind, 'dev');
  assert.equal(runGate(gate, fakeReq({ 'x-user-id': '-1' })).res.statusCode, 401);
  assert.equal(runGate(gate, fakeReq({ 'x-user-id': 'abc' })).res.statusCode, 401);
});

test('requireSession：有效 cookie 通過；金鑰未設回 503', () => {
  const token = S.issueSession({ uid: 12, secret: SECRET, now: NOW });
  const gate = S.createRequireSession({ secret: SECRET, now: NOW, env: {} });
  const ok = runGate(gate, fakeReq({ cookie: `ect_sid=${encodeURIComponent(token)}; other=1` }));
  assert.equal(ok.nexted, true);
  assert.equal(ok.req.userId, 12);

  const noSecret = S.createRequireSession({ now: NOW, env: {} });
  assert.equal(runGate(noSecret, fakeReq({})).res.statusCode, 503);
});

test('oauth state：簽發與比對；錯 state／超時限／錯 kind 全拒', () => {
  const { state, token } = S.issueOAuthState({ secret: SECRET, now: NOW });
  assert.equal(S.verifyOAuthState(token, state, SECRET, NOW), true);
  assert.equal(S.verifyOAuthState(token, 'other-state', SECRET, NOW), false);
  assert.equal(S.verifyOAuthState(token, state, SECRET, NOW + 11 * 60 * 1000), false);
  assert.equal(S.verifyOAuthState(S.issueSession({ uid: 1, secret: SECRET, now: NOW }), state, SECRET, NOW), false);
});

test('oauth state：readOAuthState 可取回 nonce；錯 kind／超時限回 null', () => {
  const { state, nonce, token } = S.issueOAuthState({ secret: SECRET, now: NOW });
  const p = S.readOAuthState(token, SECRET, NOW);
  assert.equal(p.state, state);
  assert.equal(p.nonce, nonce);
  assert.equal(S.readOAuthState(token, SECRET, NOW + 11 * 60 * 1000), null);
  assert.equal(S.readOAuthState(S.issueSession({ uid: 1, secret: SECRET, now: NOW }), SECRET, NOW), null);
});

test('cookie：HttpOnly／Secure／SameSite=None；清除時 Max-Age=0', () => {
  const c = S.cookieString('ect_sid', 'a.b', { maxAgeMs: 604800000 });
  assert.match(c, /HttpOnly/);
  assert.match(c, /Secure/);
  assert.match(c, /SameSite=None/);
  assert.match(c, /Max-Age=604800/);
  assert.match(S.clearCookieString('ect_sid'), /Max-Age=0/);
  assert.deepEqual(S.parseCookies('a=1; ect_sid=a.b; bad'), { a: '1', ect_sid: 'a.b' });
  assert.deepEqual(S.parseCookies(undefined), {});
});

test('LINE 設定：缺任一項 fail-closed（LINE_CONFIG_UNSET）', () => {
  assert.throws(() => L.lineConfigFromEnv({}), (e) => e.code === 'LINE_CONFIG_UNSET');
  assert.throws(() => L.lineConfigFromEnv({ LINE_CHANNEL_ID: '1', LINE_CHANNEL_SECRET: 's' }), (e) => e.code === 'LINE_CONFIG_UNSET');
  assert.throws(() => L.lineConfigFromEnv({ LINE_CHANNEL_ID: 'replace-with-x', LINE_CHANNEL_SECRET: 's', LINE_REDIRECT_URI: 'https://x/cb' }), (e) => e.code === 'LINE_CONFIG_UNSET');
  assert.deepEqual(L.lineConfigFromEnv({
    LINE_CHANNEL_ID: '123', LINE_CHANNEL_SECRET: 'sec', LINE_REDIRECT_URI: 'https://x/cb',
  }), { channelId: '123', channelSecret: 'sec', redirectUri: 'https://x/cb' });
});

test('授權網址：scope 只要 openid+profile、帶 state/nonce、不含 email', () => {
  const url = new URL(L.buildAuthorizeUrl({ ...CFG, state: 'st-1', nonce: 'no-1' }));
  assert.equal(url.origin + url.pathname, 'https://access.line.me/oauth2/v2.1/authorize');
  assert.equal(url.searchParams.get('scope'), 'openid profile');
  assert.equal(url.searchParams.get('client_id'), CFG.channelId);
  assert.equal(url.searchParams.get('state'), 'st-1');
  assert.equal(url.searchParams.get('nonce'), 'no-1');
  assert.equal(url.searchParams.get('redirect_uri'), CFG.redirectUri);
  assert.equal(url.searchParams.get('scope').includes('email'), false);
  assert.throws(() => L.buildAuthorizeUrl({ ...CFG, state: '', nonce: 'n' }), (e) => e.code === 'BAD_STATE');
});

function verifyPayload(overrides = {}) {
  return {
    iss: L.ISSUER, aud: CFG.channelId,
    exp: Math.floor(NOW / 1000) + 600, sub: 'U1234567890', name: 'Jason',
    ...overrides,
  };
}
function fetchOk(payload) {
  return async () => ({ ok: true, json: async () => payload });
}

test('verifyIdToken：正確回 lineUid；iss／aud／exp／sub 逐項擋', async () => {
  const good = await L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: fetchOk(verifyPayload()), now: NOW });
  assert.equal(good.lineUid, 'U1234567890');
  assert.equal(good.displayName, 'Jason');

  await assert.rejects(
    () => L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: fetchOk(verifyPayload({ iss: 'https://evil.example' })), now: NOW }),
    (e) => e.code === 'BAD_ISSUER');
  await assert.rejects(
    () => L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: fetchOk(verifyPayload({ aud: 'other-channel' })), now: NOW }),
    (e) => e.code === 'BAD_AUDIENCE');
  await assert.rejects(
    () => L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: fetchOk(verifyPayload({ exp: Math.floor(NOW / 1000) - 1 })), now: NOW }),
    (e) => e.code === 'TOKEN_EXPIRED');
  await assert.rejects(
    () => L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: fetchOk(verifyPayload({ sub: '' })), now: NOW }),
    (e) => e.code === 'BAD_SUBJECT');
  await assert.rejects(
    () => L.verifyIdToken({ idToken: '', cfg: CFG, fetchImpl: fetchOk(verifyPayload()), now: NOW }),
    (e) => e.code === 'BAD_ID_TOKEN');
  await assert.rejects(
    () => L.verifyIdToken({ idToken: 'jwt', cfg: CFG, fetchImpl: async () => ({ ok: false }), now: NOW }),
    (e) => e.code === 'ID_TOKEN_REJECTED');
});

test('verifyIdToken：OAuth nonce 比對（相符通過／不符或缺失即拒）', async () => {
  await assert.doesNotReject(() => L.verifyIdToken({
    idToken: 'jwt', cfg: CFG, now: NOW, expectedNonce: 'no-1',
    fetchImpl: fetchOk(verifyPayload({ nonce: 'no-1' })),
  }));
  await assert.rejects(() => L.verifyIdToken({
    idToken: 'jwt', cfg: CFG, now: NOW, expectedNonce: 'no-1',
    fetchImpl: fetchOk(verifyPayload({ nonce: 'other' })),
  }), (e) => e.code === 'BAD_NONCE');
  await assert.rejects(() => L.verifyIdToken({
    idToken: 'jwt', cfg: CFG, now: NOW, expectedNonce: 'no-1',
    fetchImpl: fetchOk(verifyPayload()),
  }), (e) => e.code === 'BAD_NONCE');
});

test('exchangeCode：送出 form 參數且要求 id_token；無 id_token 即拒', async () => {
  let captured = null;
  const fetchImpl = async (url, opts) => {
    captured = { url, opts };
    return { ok: true, json: async () => ({ id_token: 'jwt', access_token: 'at' }) };
  };
  const d = await L.exchangeCode({ code: 'code-1', cfg: CFG, fetchImpl });
  assert.equal(d.id_token, 'jwt');
  assert.equal(captured.url, L.TOKEN_ENDPOINT);
  const form = new URLSearchParams(captured.opts.body);
  assert.equal(form.get('grant_type'), 'authorization_code');
  assert.equal(form.get('client_id'), CFG.channelId);
  assert.equal(form.get('code'), 'code-1');
  await assert.rejects(
    () => L.exchangeCode({ code: 'c', cfg: CFG, fetchImpl: async () => ({ ok: true, json: async () => ({}) }) }),
    (e) => e.code === 'NO_ID_TOKEN');
});

test('resolveOrCreateUser：空 lineUid／缺 db 一律 fail-closed', async () => {
  await assert.rejects(() => L.resolveOrCreateUser({ lineUid: '', db: {} }), (e) => e.code === 'BAD_LINE_UID');
  await assert.rejects(() => L.resolveOrCreateUser({ lineUid: 'U1' }), (e) => e.code === 'DB_REQUIRED');
});

test('resolveOrCreateUser：兩段 SQL 皆參數綁定、冪等 upsert、回傳 user id', async () => {
  const calls = [];
  const db = {
    withTransaction: async (fn) => fn({
      query: async (sql, params) => {
        calls.push({ sql, params });
        return calls.length === 1 ? { rows: [{ id: 42 }] } : { rows: [] };
      },
    }),
  };
  const uid = await L.resolveOrCreateUser({ lineUid: 'U123', displayName: 'Jason', db });
  assert.equal(uid, 42);
  assert.equal(calls.length, 2);
  assert.deepEqual(calls[0].params, ['U123', 'Jason']);
  assert.deepEqual(calls[1].params, [42, 'U123']);
  assert.match(calls[0].sql, /ON CONFLICT \(line_user_id\)/);
  assert.match(calls[1].sql, /ON CONFLICT \(line_uid\) DO NOTHING/);
  assert.ok(calls.every((c) => c.sql.includes('$1') && c.sql.includes('$2')));
});
