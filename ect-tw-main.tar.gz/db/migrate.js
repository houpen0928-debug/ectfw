'use strict';
// 版本化 migration runner：schema_migrations 記錄版本，每次一檔、單一交易、可重複執行
// 用法：node db/migrate.js [--status|--check]
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pool, withTransaction } = require('./index');

const DIR = path.join(__dirname, 'migrations');

function listFiles() {
  if (!fs.existsSync(DIR)) return [];
  return fs.readdirSync(DIR)
    .filter((f) => /^\d{3}_.+\.sql$/.test(f))
    .sort()
    .map((f) => {
      const sql = fs.readFileSync(path.join(DIR, f), 'utf8');
      return {
        version: f.slice(0, 3),
        file: f,
        sql,
        checksum: crypto.createHash('sha256').update(sql).digest('hex'),
      };
    });
}

async function ensureMeta(client) {
  await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version    VARCHAR(8) PRIMARY KEY,
    file       TEXT NOT NULL,
    checksum   CHAR(64) NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
  )`);
}

async function status() {
  const client = await pool.connect();
  try {
    await ensureMeta(client);
    const { rows } = await client.query(
      'SELECT version, file, checksum, applied_at FROM schema_migrations ORDER BY version'
    );
    return rows;
  } finally {
    client.release();
  }
}

async function run() {
  const files = listFiles();
  if (!files.length) throw new Error('no migration files found');
  const applied = await status();
  const done = new Map(applied.map((r) => [r.version, r.checksum]));

  let count = 0;
  for (const m of files) {
    if (done.has(m.version)) {
      if (done.get(m.version) !== m.checksum) {
        throw new Error(`checksum mismatch on ${m.file}: 已套用的 migration 內容被修改，拒絕繼續`);
      }
      console.log(`[migrate] = ${m.file} (already applied)`);
      continue;
    }
    // eslint-disable-next-line no-await-in-loop
    await withTransaction(async (client) => {
      await client.query(m.sql);
      await client.query(
        'INSERT INTO schema_migrations(version, file, checksum) VALUES($1,$2,$3)',
        [m.version, m.file, m.checksum]
      );
    });
    console.log(`[migrate] + ${m.file} applied`);
    count++;
  }
  console.log(`[migrate] done, ${count} new migration(s), head=${files[files.length - 1].version}`);
  return { applied: count, head: files[files.length - 1].version };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.includes('--status')) {
    const rows = await status();
    for (const r of rows) console.log(`${r.version}  ${r.file}  ${r.applied_at.toISOString()}`);
    console.log(`[migrate] ${rows.length} applied`);
    return;
  }
  if (args.includes('--check')) {
    const rows = await status();
    const pending = listFiles().filter((m) => !rows.some((r) => r.version === m.version));
    console.log(`[migrate] applied=${rows.length} pending=${pending.length}` +
      (pending.length ? ` [${pending.map((p) => p.file).join(', ')}]` : ''));
    if (pending.length) process.exitCode = 1;
    return;
  }
  await run();
}

if (require.main === module) {
  main()
    .catch((err) => {
      console.error('[migrate] FAILED:', err.message);
      process.exitCode = 1;
    })
    .finally(() => pool.end());
}

module.exports = { listFiles, status, run };
