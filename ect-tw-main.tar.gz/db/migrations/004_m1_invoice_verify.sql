-- 004 M1 第二批：電子發票 + 核銷台所需 DDL（2026-11-18）
-- 依 migration 紀律：001/002/003 已發布，不改其內容（checksum 防篡改），以新版本補齊。
-- 全部冪等（IF NOT EXISTS / DO block），由 db/migrate.js 包單一交易。
-- 法遵：發票開立時點尚未經律師意見書確認（律師清單 C2），故 issue_point 為可配置欄位，不寫死。

-- ===== invoices：001 已有 type/amount_cents/carrier_id/donate_code/status/payload =====
-- ecpay_invoice_no 為綠界時代命名，保留相容；另補 provider 中立欄位。
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS provider          VARCHAR(16) NOT NULL DEFAULT 'ezpay';
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS order_no          VARCHAR(30);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS idempotency_key   TEXT;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS issue_point       VARCHAR(12) NOT NULL DEFAULT 'ORDER';
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS buyer_unified_no  VARCHAR(8);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS invoice_no        TEXT;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS invoice_date      DATE;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS random_number     TEXT;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS attempts         INT NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS last_error        TEXT;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS issued_at         TIMESTAMPTZ;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS updated_at        TIMESTAMPTZ NOT NULL DEFAULT now();

-- 開立點約束以 DO block 冪等加上（避免 ADD COLUMN ... CHECK 重跑時重複命名約束）
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'invoices_issue_point_chk') THEN
    ALTER TABLE invoices ADD CONSTRAINT invoices_issue_point_chk
      CHECK (issue_point IN ('ORDER','REDEEM'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'invoices_amount_pos_chk') THEN
    ALTER TABLE invoices ADD CONSTRAINT invoices_amount_pos_chk
      CHECK (amount_cents > 0);
  END IF;
END $$;

-- 冪等鍵：同一開立點 + 同一來源（訂單或券）+ 同一類型只開一張，防重複開立
CREATE UNIQUE INDEX IF NOT EXISTS uq_invoices_idempotency
  ON invoices(idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_invoices_ticket ON invoices(ticket_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status, created_at);

-- ===== 發票待補／重試軌跡（append-only）=====
-- 發票 fire-and-forget 失敗不阻塞核銷；每筆嘗試留痕，供 admin 補開與對帳。
CREATE TABLE IF NOT EXISTS invoice_outbox (
  id          BIGSERIAL PRIMARY KEY,
  invoice_id  BIGINT REFERENCES invoices(id),
  ticket_id   BIGINT REFERENCES tickets(id),
  order_no    VARCHAR(30),
  event       VARCHAR(32) NOT NULL,          -- QUEUED / SENT / FAILED / SKIPPED / RETRY
  detail      TEXT,
  payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_inv_outbox_created ON invoice_outbox(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inv_outbox_invoice ON invoice_outbox(invoice_id, created_at);
DROP TRIGGER IF EXISTS trg_inv_outbox_immutable ON invoice_outbox;
CREATE TRIGGER trg_inv_outbox_immutable BEFORE UPDATE OR DELETE ON invoice_outbox
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- ===== 核銷台操作軌跡（append-only）=====
-- ticket_chain 記狀態機動作；本表補「門市／人員／發行人／成敗」維度，供門市對帳。
CREATE TABLE IF NOT EXISTS verify_operations (
  id           BIGSERIAL PRIMARY KEY,
  ticket_id    BIGINT NOT NULL REFERENCES tickets(id),
  vendor_id    BIGINT NOT NULL REFERENCES vendors(id),
  staff        TEXT,
  action       VARCHAR(24) NOT NULL,
  amount_cents BIGINT,
  result       VARCHAR(24) NOT NULL,          -- OK / REJECTED / ERROR
  detail       TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_verify_ops_ticket ON verify_operations(ticket_id, created_at);
CREATE INDEX IF NOT EXISTS idx_verify_ops_vendor ON verify_operations(vendor_id, created_at DESC);
DROP TRIGGER IF EXISTS trg_verify_ops_immutable ON verify_operations;
CREATE TRIGGER trg_verify_ops_immutable BEFORE UPDATE OR DELETE ON verify_operations
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- ===== 發票監控視圖（法遵可追溯：待開立不得長期滯留）=====
CREATE OR REPLACE VIEW invoice_monitor AS
SELECT
  count(*) FILTER (WHERE status = 'PENDING')                          AS pending_count,
  count(*) FILTER (WHERE status = 'ISSUED')                           AS issued_count,
  count(*) FILTER (WHERE status = 'FAILED')                           AS failed_count,
  coalesce(sum(amount_cents) FILTER (WHERE status = 'ISSUED'), 0)    AS issued_amount_cents,
  max(created_at)                                                     AS last_created_at
FROM invoices;

COMMENT ON COLUMN invoices.issue_point IS 'ORDER=訂單成立/付款時開立；REDEEM=核銷時開立。時點待法遵意見書（律師清單 C2）確認，以 ECT_INVOICE_ISSUE_POINT 切換';
