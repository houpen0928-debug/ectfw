-- 005 M2 批次A：券轉移（一次性領取 token）＋ 動態碼防偽（code_seq）
-- 轉移＝原子交割：過戶當下重簽新 code_hash/scratch_hash 且 code_seq+1，
-- 轉出人手上的舊靜態碼（雜湊已換）與舊動態碼（seq 落後）同時作廢。
-- 補償語義：token 過期／取消／被拒，券留在原持有人、狀態不動（失敗補償狀態機）。
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS code_seq INT NOT NULL DEFAULT 0;
COMMENT ON COLUMN tickets.code_seq IS '券碼重簽次數：每次轉移 +1；動態碼驗證時 seq 落後即拒（防舊碼重放）';

CREATE TABLE IF NOT EXISTS transfer_tokens (
  id           BIGSERIAL PRIMARY KEY,
  ticket_id    BIGINT NOT NULL REFERENCES tickets(id),
  from_user_id BIGINT NOT NULL REFERENCES users(id),
  token_hash   TEXT NOT NULL UNIQUE,
  status       VARCHAR(16) NOT NULL DEFAULT 'PENDING'
               CHECK (status IN ('PENDING','CLAIMED','CANCELLED','LAPSED')),
  expires_at   TIMESTAMPTZ NOT NULL,
  claimed_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status <> 'CLAIMED' OR claimed_at IS NOT NULL)
);
COMMENT ON TABLE transfer_tokens IS '一次性轉贈領取憑證：明文 token 只在建立時回傳一次，DB 只存 sha256';
CREATE INDEX IF NOT EXISTS idx_transfer_ticket ON transfer_tokens (ticket_id, status);
CREATE INDEX IF NOT EXISTS idx_transfer_pending ON transfer_tokens (status, expires_at);
