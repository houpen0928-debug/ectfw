-- 003 修正 002 遺漏欄位（2026-11-18）
-- 依 migration 紀律：已套用之 002 不改其內容（checksum 防篡改），以新版本補齊。
-- 002 的 ALTER 列表漏了 converted_at，但 src/engine/tickets.js 轉點數時會寫入。
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS converted_at TIMESTAMPTZ;
COMMENT ON COLUMN tickets.converted_at IS '轉入點數錢包之時間（CONVERTED 終態）';
