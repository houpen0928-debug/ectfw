-- ECT-TW PostgreSQL schema v0.1（2026-11-18）
-- 法遵約束：券無使用期限、殘值不消失、點數無換現出口、發行人＝廠商
-- 冪等：可重複執行；金流金額一律以「分」為單位整數儲存

-- 交易由 db/migrate.js 統一包裹（migration 檔本身不含 BEGIN/COMMIT）

CREATE TABLE IF NOT EXISTS vendors (
  id                  BIGSERIAL PRIMARY KEY,
  unified_no          VARCHAR(8)  NOT NULL UNIQUE,          -- 台灣統一編號（發行人／券面應記載事項 1）
  name                TEXT        NOT NULL,
  address             TEXT        NOT NULL,
  representative      TEXT        NOT NULL,
  phone               TEXT,
  trust_bank          TEXT,                                -- 履約保障：信託專戶銀行
  trust_account_no    TEXT,
  trust_contract_no   TEXT,
  trust_start         DATE,
  trust_end           DATE,                                -- 自出售日起至少一年
  trust_evidence_url  TEXT,                                -- 存入憑證（上架審核必要文件）
  status              VARCHAR(16) NOT NULL DEFAULT 'PENDING'
                      CHECK (status IN ('PENDING','ACTIVE','SUSPENDED')),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id               BIGSERIAL PRIMARY KEY,
  phone            VARCHAR(20) UNIQUE,
  display_name     TEXT,
  line_user_id     TEXT UNIQUE,
  apple_user_id    TEXT UNIQUE,
  points_balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (points_balance_cents >= 0),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS line_bindings (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id),
  line_uid    TEXT   NOT NULL UNIQUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS otp_codes (
  id          BIGSERIAL PRIMARY KEY,
  phone       VARCHAR(20) NOT NULL,
  code_hash   TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  consumed_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_otp_phone ON otp_codes (phone, created_at DESC);

CREATE TABLE IF NOT EXISTS corp_accounts (
  id             BIGSERIAL PRIMARY KEY,
  unified_no     VARCHAR(8) NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  contact_phone  TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id                 BIGSERIAL PRIMARY KEY,
  vendor_id          BIGINT NOT NULL REFERENCES vendors(id),
  name               TEXT   NOT NULL,
  face_value_cents   BIGINT NOT NULL CHECK (face_value_cents > 0),
  floor_value_cents  BIGINT NOT NULL CHECK (floor_value_cents >= 0),
  grace_start        DATE,                                -- 優惠期間起（非使用期限）
  grace_end          DATE,                                -- 優惠期間迄；屆至後券仍可保底兌換
  category           TEXT,
  status             VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
                     CHECK (status IN ('DRAFT','ACTIVE','SUSPENDED')),
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (floor_value_cents <= face_value_cents),
  CHECK (grace_start IS NULL OR grace_end IS NULL OR grace_end >= grace_start)
);
COMMENT ON COLUMN products.grace_end IS '優惠期間結束日；依台灣禮券法規，券不得記載使用期限，優惠期間屆至不影響券之效力';
CREATE INDEX IF NOT EXISTS idx_products_vendor ON products (vendor_id);

CREATE TABLE IF NOT EXISTS batches (
  id                   BIGSERIAL PRIMARY KEY,
  product_id           BIGINT NOT NULL REFERENCES products(id),
  issue_no             TEXT   NOT NULL UNIQUE,            -- 發售編號（應記載事項 3）
  sale_date            DATE   NOT NULL,                   -- 出售日（應記載事項 3）
  qty                  INT    NOT NULL CHECK (qty > 0),
  trust_deposit_cents  BIGINT NOT NULL DEFAULT 0,
  status               VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
                       CHECK (status IN ('DRAFT','ISSUED','CLOSED')),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_batches_product ON batches (product_id);

CREATE TABLE IF NOT EXISTS tickets (
  id              BIGSERIAL PRIMARY KEY,
  batch_id        BIGINT NOT NULL REFERENCES batches(id),
  code_hash       TEXT   NOT NULL UNIQUE,
  scratch_hash    TEXT   NOT NULL UNIQUE,
  state           VARCHAR(16) NOT NULL DEFAULT 'UNBOUND'
                  CHECK (state IN ('UNBOUND','BOUND','USED','GRACE','CONVERTED','CHARITY')),
  owner_user_id   BIGINT REFERENCES users(id),
  corp_account_id BIGINT REFERENCES corp_accounts(id),
  bound_at        TIMESTAMPTZ,
  used_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON COLUMN tickets.state IS '無 EXPIRED 終態：GRACE＝優惠期間已結束、保底流通中（台灣法遵）';
CREATE INDEX IF NOT EXISTS idx_tickets_state ON tickets (state);
CREATE INDEX IF NOT EXISTS idx_tickets_owner ON tickets (owner_user_id);

-- 不可改寫的操作留痕（append-only journal）
CREATE OR REPLACE FUNCTION ect_deny_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'ECT journal is append-only';
END $$;

CREATE TABLE IF NOT EXISTS ticket_chain (
  id          BIGSERIAL PRIMARY KEY,
  ticket_id   BIGINT NOT NULL REFERENCES tickets(id),
  action      VARCHAR(32) NOT NULL,
  actor       TEXT,
  payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chain_ticket ON ticket_chain (ticket_id, created_at);
DROP TRIGGER IF EXISTS trg_chain_immutable ON ticket_chain;
CREATE TRIGGER trg_chain_immutable BEFORE UPDATE OR DELETE ON ticket_chain
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- 點數流水：臺灣版僅三類 reason，無 CASHOUT（免電子支付執照）
CREATE TABLE IF NOT EXISTS points_ledger (
  id                   BIGSERIAL PRIMARY KEY,
  user_id              BIGINT NOT NULL REFERENCES users(id),
  delta_cents          BIGINT NOT NULL,
  balance_after_cents  BIGINT NOT NULL CHECK (balance_after_cents >= 0),
  reason               VARCHAR(24) NOT NULL
                       CHECK (reason IN ('GRACE_CONVERT','REDEEM_TICKET','CHARITY')),
  ref                  TEXT,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_points_user ON points_ledger (user_id, created_at DESC);
DROP TRIGGER IF EXISTS trg_points_immutable ON points_ledger;
CREATE TRIGGER trg_points_immutable BEFORE UPDATE OR DELETE ON points_ledger
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

CREATE TABLE IF NOT EXISTS charity_partners (
  id              BIGSERIAL PRIMARY KEY,
  unified_no      VARCHAR(8) NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  donate_code     TEXT,                                  -- 電子發票捐贈碼
  bank_account    TEXT,
  mou_ref         TEXT,                                  -- 合作備忘錄（勸募主體在團體方）
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS donations (
  id             BIGSERIAL PRIMARY KEY,
  user_id        BIGINT REFERENCES users(id),
  ticket_id      BIGINT REFERENCES tickets(id),
  partner_id     BIGINT NOT NULL REFERENCES charity_partners(id),
  amount_cents   BIGINT NOT NULL CHECK (amount_cents > 0),
  path           VARCHAR(16) NOT NULL CHECK (path IN ('USER_CHOICE','POINTS','INVOICE_CODE')),
  receipt_url    TEXT,                                   -- 感謝回執（G 可追溯率素材）
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settlements (
  id                  BIGSERIAL PRIMARY KEY,
  vendor_id           BIGINT NOT NULL REFERENCES vendors(id),
  ticket_id           BIGINT REFERENCES tickets(id),
  gross_cents         BIGINT NOT NULL,
  platform_fee_cents  BIGINT NOT NULL DEFAULT 0,
  net_cents           BIGINT NOT NULL,
  status              VARCHAR(16) NOT NULL DEFAULT 'PENDING'
                      CHECK (status IN ('PENDING','PAID','REVERSED')),
  settled_at          TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_settle_status ON settlements (status, created_at);
DROP TRIGGER IF EXISTS trg_settle_immutable ON settlements;
CREATE TRIGGER trg_settle_immutable BEFORE UPDATE OR DELETE ON settlements
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- 法遵儀表：代收未付餘額（電支條例 §5 監控用），不是財務 KPI
CREATE OR REPLACE VIEW payables_monitor AS
SELECT
  count(*) FILTER (WHERE status = 'PENDING')                       AS pending_count,
  coalesce(sum(net_cents) FILTER (WHERE status = 'PENDING'), 0)    AS payable_cents,
  max(created_at)                                                  AS last_created_at
FROM settlements;

CREATE TABLE IF NOT EXISTS invoices (
  id                 BIGSERIAL PRIMARY KEY,
  ticket_id          BIGINT REFERENCES tickets(id),
  vendor_id          BIGINT NOT NULL REFERENCES vendors(id),
  ecpay_invoice_no   TEXT,
  type               VARCHAR(16) NOT NULL CHECK (type IN ('ISSUE','OFFSET','VOID','DONATE')),
  amount_cents       BIGINT NOT NULL,
  carrier_id         TEXT,
  donate_code        TEXT,
  status             VARCHAR(16) NOT NULL DEFAULT 'PENDING',
  payload            JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS corp_grants (
  id               BIGSERIAL PRIMARY KEY,
  corp_account_id  BIGINT NOT NULL REFERENCES corp_accounts(id),
  batch_id         BIGINT NOT NULL REFERENCES batches(id),
  qty              INT NOT NULL CHECK (qty > 0),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sms_outbox (
  id           BIGSERIAL PRIMARY KEY,
  phone        VARCHAR(20) NOT NULL,
  text         TEXT NOT NULL,
  scene        VARCHAR(32) NOT NULL,
  channel      VARCHAR(16) NOT NULL DEFAULT 'stub'
               CHECK (channel IN ('stub','line','push','sms')),
  status       VARCHAR(16) NOT NULL DEFAULT 'PENDING',
  fail_reason  TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS esg_snapshots (
  id                BIGSERIAL PRIMARY KEY,
  charity_total     BIGINT NOT NULL DEFAULT 0,
  charity_count     BIGINT NOT NULL DEFAULT 0,
  zero_waste_rate   NUMERIC(5,2) NOT NULL DEFAULT 0,
  projects          INT NOT NULL DEFAULT 0,
  methodology       TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 001 baseline end（COMMIT 由 migrate.js 統一執行）
