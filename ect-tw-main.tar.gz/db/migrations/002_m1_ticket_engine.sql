-- 002 M1 第一批：券引擎 + 藍新金流 callback 所需 DDL（2026-11-18）
-- 法遵約束：券無 EXPIRED 終態、殘值完整保留、點數無換現出口、發行人＝廠商
-- 收款紅線：平台商店代號只收「平台服務費」；券貨款不經平台（fee_scope 明確區分）
-- 冪等：全部 IF NOT EXISTS / DO block，可重複執行

-- ===== 訂單 =====
-- fee_scope：PLATFORM_FEE = 平台服務費（走藍新平台商店代號，合規）
--            TICKET_SALE  = 券貨款（進廠商信託專戶／廠商自收，平台僅記憑證不經手）
CREATE TABLE IF NOT EXISTS orders (
  id                BIGSERIAL PRIMARY KEY,
  order_no          VARCHAR(30) NOT NULL UNIQUE,        -- = 藍新 MerchantOrderNo（≤30 英數）
  user_id           BIGINT REFERENCES users(id),
  product_id        BIGINT NOT NULL REFERENCES products(id),
  batch_id          BIGINT REFERENCES batches(id),
  vendor_id         BIGINT NOT NULL REFERENCES vendors(id),  -- 發行人＝廠商
  qty               INT NOT NULL DEFAULT 1 CHECK (qty > 0),
  amount_cents      BIGINT NOT NULL CHECK (amount_cents > 0),
  fee_scope         VARCHAR(16) NOT NULL DEFAULT 'PLATFORM_FEE'
                    CHECK (fee_scope IN ('PLATFORM_FEE','TICKET_SALE')),
  trust_receipt_ref TEXT,                              -- 廠商信託專戶存入憑證（TICKET_SALE 用）
  status            VARCHAR(16) NOT NULL DEFAULT 'PENDING'
                    CHECK (status IN ('PENDING','PAID','FAILED','FULFILLED','REFUNDED')),
  fulfilled_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON COLUMN orders.fee_scope IS '收款主體：平台服務費走藍新平台商店代號；券貨款直接進發行人信託專戶，平台不代收代付';
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status, created_at);

-- 修正 v0.1：settlements 需狀態流轉（PENDING→PAID），不該套 append-only；
-- 真正不可改寫的是 journal（ticket_chain / points_ledger），清算單據本身要能更新狀態。
DROP TRIGGER IF EXISTS trg_settle_immutable ON settlements;

-- ===== 藍新交易對應（callback 冪等核心，append-only 防竄改）=====
-- 只寫終態（PAID）當作交易結果留痕；冪等靠 UNIQUE(merchant_order_no)，不做 PENDING→PAID 更新
CREATE TABLE IF NOT EXISTS newebpay_txn (
  id                 BIGSERIAL PRIMARY KEY,
  ref_kind           VARCHAR(16) NOT NULL DEFAULT 'ORDER'
                     CHECK (ref_kind IN ('ORDER','BILL','MANDATE')),
  ref_id             BIGINT,
  merchant_order_no  VARCHAR(30) NOT NULL UNIQUE,
  trade_no           TEXT,                              -- 藍新交易序號
  amt_cents          BIGINT NOT NULL CHECK (amt_cents >= 0),
  status             VARCHAR(16) NOT NULL DEFAULT 'PENDING'
                     CHECK (status IN ('PENDING','PAID','FAILED','SUPERSEDED')),
  pay_time           TIMESTAMPTZ,
  payload            JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_np_txn_status ON newebpay_txn (status, created_at);
DROP TRIGGER IF EXISTS trg_np_txn_immutable ON newebpay_txn;
CREATE TRIGGER trg_np_txn_immutable BEFORE UPDATE OR DELETE ON newebpay_txn
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- ===== 回呼事件留痕（append-only，法遵可追溯）=====
CREATE TABLE IF NOT EXISTS payment_events (
  id           BIGSERIAL PRIMARY KEY,
  order_no     VARCHAR(30),
  event        VARCHAR(32) NOT NULL,                  -- NOTIFY_RECEIVED / SHA_OK / SHA_BAD / AMOUNT_MISMATCH / PAID / DUPLICATE / FAIL_CLOSED
  detail       TEXT,
  payload      JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pay_evt_order ON payment_events (order_no, created_at);
DROP TRIGGER IF EXISTS trg_pay_evt_immutable ON payment_events;
CREATE TRIGGER trg_pay_evt_immutable BEFORE UPDATE OR DELETE ON payment_events
  FOR EACH ROW EXECUTE FUNCTION ect_deny_mutation();

-- ===== 券價值快照 + 殘值（部分核銷後完整保留）=====
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS order_id           BIGINT REFERENCES orders(id);
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS face_value_cents   BIGINT;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS floor_value_cents  BIGINT;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS residual_cents     BIGINT;   -- 剩餘可兌換價值
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS grace_entered_at   TIMESTAMPTZ;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS terminal_at        TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_tickets_order ON tickets (order_id);

-- 已發券補齊殘值（冪等；既有列 residual_cents IS NULL 時以面額初始化）
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tickets_residual_nonneg') THEN
    ALTER TABLE tickets ADD CONSTRAINT tickets_residual_nonneg
      CHECK (residual_cents IS NULL OR residual_cents >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tickets_value_ordered') THEN
    ALTER TABLE tickets ADD CONSTRAINT tickets_value_ordered
      CHECK (face_value_cents IS NULL OR floor_value_cents IS NULL OR floor_value_cents <= face_value_cents);
  END IF;
END $$;

UPDATE tickets SET residual_cents = face_value_cents
 WHERE residual_cents IS NULL AND face_value_cents IS NOT NULL;

-- ===== 對帳視圖 =====
-- 殘值完整保留：GRACE／BOUND／UNBOUND 券的 residual 必須恆 > 0（無作廢歸零）
CREATE OR REPLACE VIEW residual_monitor AS
SELECT
  count(*) FILTER (WHERE state IN ('UNBOUND','BOUND','GRACE'))                    AS live_count,
  coalesce(sum(residual_cents) FILTER (WHERE state IN ('UNBOUND','BOUND','GRACE')), 0) AS live_residual_cents,
  count(*) FILTER (WHERE state IN ('UNBOUND','BOUND','GRACE') AND
                         (residual_cents IS NULL OR residual_cents <= 0))        AS zero_residual_violations,
  count(*) FILTER (WHERE state = 'CONVERTED')                                    AS converted_count,
  count(*) FILTER (WHERE state = 'CHARITY')                                      AS charity_count
FROM tickets;

-- 點數守恆：帳本累計 = 用戶餘額合計（不得漂移）
CREATE OR REPLACE VIEW points_conservation AS
SELECT
  coalesce(sum(delta_cents), 0)                                      AS ledger_sum_cents,
  (SELECT coalesce(sum(points_balance_cents), 0) FROM users)        AS balance_sum_cents,
  coalesce(sum(delta_cents), 0)
    - (SELECT coalesce(sum(points_balance_cents), 0) FROM users)    AS drift_cents
FROM points_ledger;
