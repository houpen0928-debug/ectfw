'use strict';
const { Pool } = require('pg');
require('dotenv').config();

// Pool 建立時不連線 → 無 DB 也能通過 /health 冒煙
const pool = new Pool({
  connectionString:
    process.env.ECT_PG_URL || 'postgresql://ect:ect_local_dev@127.0.0.1:5433/ect_tw',
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 3_000,
});

pool.on('error', (err) => console.error('[pg] idle client error:', err.message));

// 所有查詢一律走參數綁定（$1,$2...），禁止字串拼接 SQL
async function query(text, params = []) {
  if (!Array.isArray(params)) throw new TypeError('SQL params must be an array');
  return pool.query(text, params);
}

// 資金相關寫操作（點數／清算／退券）一律包在同一交易
async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, withTransaction };
