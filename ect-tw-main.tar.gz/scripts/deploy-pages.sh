#!/usr/bin/env bash
# TWECT 首頁 → Cloudflare Pages（Direct Upload），冪等、可重跑
# 憑證：.cf-token（API Token）／.cf_account_id（Account ID），皆已 gitignore
# 驗證一律走 Cloudflare API，不用本機 curl 打目標站（本機代理會回假 502）
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TOKEN_FILE="$ROOT/.cf-token"
ACCT_FILE="$ROOT/.cf_account_id"
API="https://api.cloudflare.com/client/v4"
PROJECT="twect-home"
DOMAIN="twect.com.tw"
ZONE_FILE="$ROOT/.cf_zone_id"
WRANGLER_JS="C:/Users/A/AppData/Local/Temp/cfdeploy/node_modules/wrangler/bin/wrangler.js"

[[ -f "$TOKEN_FILE" ]] || { echo "MISSING $TOKEN_FILE"; exit 1; }
[[ -f "$ACCT_FILE" ]] || { echo "MISSING $ACCT_FILE"; exit 1; }
TOKEN="$(tr -d '\r\n[:space:]' < "$TOKEN_FILE")"
ACCT="$(tr -d '\r\n[:space:]' < "$ACCT_FILE")"
[[ -n "$TOKEN" && -n "$ACCT" ]] || { echo "EMPTY credential"; exit 1; }
export CLOUDFLARE_API_TOKEN="$TOKEN"
export CLOUDFLARE_ACCOUNT_ID="$ACCT"
AUTH=(-H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json")

# Zone ID（DNS 補記錄用）：優先讀檔，沒有就查一次後落檔（Token 需含 Zone:Read／DNS:Edit）
if [[ -f "$ZONE_FILE" ]]; then
  ZONE="$(tr -d '\r\n[:space:]' < "$ZONE_FILE")"
else
  ZONE="$(curl -sf "${AUTH[@]}" "$API/zones?name=$DOMAIN" | node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8"));process.stdout.write(d.result&&d.result[0]?d.result[0].id:"")')"
  [[ -n "$ZONE" ]] && printf '%s' "$ZONE" > "$ZONE_FILE"
fi

echo "=== 1/5 Token 驗證 ==="
curl -sf "${AUTH[@]}" "$API/user/tokens/verify" \
  | node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8")); if(!d.success){console.error(d.errors);process.exit(1);} console.log("status:",d.result.status);'

echo "=== 2/5 準備靜態檔（apps/web 三檔）==="
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
cp "$ROOT/apps/web/index.html" "$ROOT/apps/web/style.css" "$ROOT/apps/web/app.js" "$STAGE/"
ls -l "$STAGE"

echo "=== 3/5 建立／確認 Pages 專案 ==="
curl -s "${AUTH[@]}" -X POST "$API/accounts/$ACCT/pages/projects" \
  -d "{\"name\":\"$PROJECT\",\"production_branch\":\"main\"}" \
  | node -e '
const d=JSON.parse(require("fs").readFileSync(0,"utf8"));
if(d.success){console.log("project created:",d.result.name);}
else{const m=(d.errors||[]).map(e=>e.message).join("; ");
  if(/already|exists|duplicate|taken/i.test(m)){console.log("project already exists, continue");}
  else{console.error("create project FAILED:",m);process.exit(1);}}
'

echo "=== 4/5 Direct Upload 部署 ==="
node "$WRANGLER_JS" pages deploy "$STAGE" --project-name="$PROJECT" --branch=main --commit-dirty=true

echo "=== 5/5 綁定自訂網域 twect.com.tw ==="
curl -s "${AUTH[@]}" -X POST "$API/accounts/$ACCT/pages/projects/$PROJECT/domains" \
  -d "{\"name\":\"$DOMAIN\"}" \
  | node -e '
const d=JSON.parse(require("fs").readFileSync(0,"utf8"));
if(d.success){console.log("domain:",d.result.name,"status:",d.result.status);}
else{const m=(d.errors||[]).map(e=>e.message).join("; ");
  if(/already|exists|duplicate/i.test(m)){console.log("domain already attached, continue");}
  else{console.error("attach domain FAILED:",m);process.exit(1);}}
'

echo "=== 6/7 綁定 www.twect.com.tw（洪哥習慣打 www）==="
curl -s "${AUTH[@]}" -X POST "$API/accounts/$ACCT/pages/projects/$PROJECT/domains" \
  -d '{"name":"www.twect.com.tw"}' \
  | node -e '
const d=JSON.parse(require("fs").readFileSync(0,"utf8"));
if(d.success){console.log("domain:",d.result.name,"status:",d.result.status);}
else{const m=(d.errors||[]).map(e=>e.message).join("; ");
  if(/already|exists|duplicate/i.test(m)){console.log("www domain already attached, continue");}
  else{console.error("attach www domain FAILED:",m);process.exit(1);}}
'

echo "=== 7/7 補 DNS CNAME（apex＋www → pages.dev，冪等；需 Token 含 Zone:DNS:Edit）==="
# 教訓（2026-11-27）：Pages API 綁網域不會自動建 CNAME，缺記錄會永久卡在
# verification "CNAME record not set" → 網站看不到。此步冪等補齊。
if [[ -n "${ZONE:-}" ]]; then
  for NAME in "$DOMAIN" "www.$DOMAIN"; do
    curl -s "${AUTH[@]}" -X POST "$API/zones/$ZONE/dns_records" \
      -d "{\"type\":\"CNAME\",\"name\":\"$NAME\",\"content\":\"$PROJECT.pages.dev\",\"ttl\":1,\"proxied\":true,\"comment\":\"TWECT -> Cloudflare Pages\"}" \
      | node -e '
const d=JSON.parse(require("fs").readFileSync(0,"utf8"));
if(d.success){console.log("dns created:",d.result.name);}
else{const m=(d.errors||[]).map(e=>e.message).join("; ");
  if(/already|exists|duplicate|81053|81044|9109/i.test(m+JSON.stringify(d.errors||[]).toLowerCase())){console.log("dns already exists, continue:",JSON.stringify(d.errors).slice(0,80));}
  else{console.error("dns FAILED:",m);process.exit(1);}}'
  done
else
  echo "SKIP: no zone id（Token 無 Zone 權限）；若 domain 卡 pending 請手動補 CNAME"
fi

echo "=== 驗證（API 查狀態，本機 curl 目標站不作準）==="
curl -sf "${AUTH[@]}" "$API/accounts/$ACCT/pages/projects/$PROJECT/domains" \
  | node -e 'const d=JSON.parse(require("fs").readFileSync(0,"utf8"));
for(const x of d.result) console.log(x.name,"|",x.status,"| validation:",x.validation_data&&x.validation_data.status,"| verification:",x.verification_data&&x.verification_data.status);'
echo "DEPLOY_PAGES_DONE"
