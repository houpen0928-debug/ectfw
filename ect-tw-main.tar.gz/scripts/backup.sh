#!/usr/bin/env bash
# ECT-TW 每日備份 — 在 VM 宿主由 cron 執行，不額外跑容器（e2-micro 只有 1GB RAM）
# 用法：./scripts/backup.sh   （可用 ECT_DEPLOY_ROOT / ECT_BACKUP_DIR / ECT_BACKUP_KEEP_DAYS 覆蓋）
set -euo pipefail

ROOT="${ECT_DEPLOY_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
BACKUP_DIR="${ECT_BACKUP_DIR:-$ROOT/backups}"
KEEP_DAYS="${ECT_BACKUP_KEEP_DAYS:-14}"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$BACKUP_DIR/ect_tw-$STAMP.dump"

mkdir -p "$BACKUP_DIR"
cd "$ROOT"

# -T：cron 無 TTY；pg_dump 走 stdout 直接寫宿主，容器內不留檔
docker compose exec -T postgres \
  pg_dump -U ect -d ect_tw --format=custom --no-owner --no-privileges \
  > "$OUT"

# 空檔視為失敗並刪除，避免日後還原拿到 0 byte
if [ ! -s "$OUT" ]; then
  rm -f "$OUT"
  echo "[backup] FAIL: empty dump" >&2
  exit 1
fi

find "$BACKUP_DIR" -maxdepth 1 -type f -name 'ect_tw-*.dump' -mtime "+$KEEP_DAYS" -delete
echo "[backup] OK: $OUT ($(du -h "$OUT" | cut -f1)), keep ${KEEP_DAYS}d"
