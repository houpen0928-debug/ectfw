'use strict';
// 法遵禁詞掃描（規格書 R3）。CLI：node scripts/check-banned-words.js [--selftest]
// 兩種獨立抓法交叉驗證，避免「抓法本身寫錯」造成假陰性。
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
// 第一組：法規明文禁用語（禮券不得記載使用期限、殘值不得歸零）。
// 第二組：大陸版語彙 —— 臺灣版對外門面一律改用「禮券／優惠期間／信託專戶／統一編號／藍新／點數」。
// ⚠️ 「核銷」刻意不列入：門市核銷台是內部工具，用語合法；僅「對客」文案禁用（由 data-copy 統一控管）。
const BANNED = [
  '使用期限', '逾期作廢', '逾期無效', '過期無效', '到期作廢',
  '到期失效', '逾期失效', '到期無效', '餘額沒收', '沒收', '餘額不得消費',
  '券種', '提現', '託管池', '備案號', '微信支付', '有效期', '到期日', '即期',
];
const TARGET_DIRS = ['src', 'config', 'apps']; // docs/ 引用法規原文故不掃；tests/ 故意注入故不掃
const SCAN_EXT = new Set(['.js', '.jsx', '.ts', '.tsx', '.vue', '.html', '.json', '.md']);

function scanText(text) {
  return BANNED.filter((w) => text.includes(w));
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// 第二種獨立抓法（RegExp），用於交叉驗證 scanText 的結果
function scanTextCross(text) {
  return BANNED.filter((w) => new RegExp(escapeRegExp(w)).test(text));
}

function collectFiles(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.git') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) collectFiles(full, out);
    else if (SCAN_EXT.has(path.extname(entry.name).toLowerCase())) out.push(full);
  }
  return out;
}

function scanRepo() {
  const hits = [];
  for (const dir of TARGET_DIRS) {
    const base = path.join(ROOT, dir);
    if (!fs.existsSync(base)) continue;
    for (const file of collectFiles(base)) {
      const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
      lines.forEach((line, i) => {
        const words = scanText(line);
        if (words.length) {
          hits.push({
            file: path.relative(ROOT, file).replace(/\\/g, '/'),
            line: i + 1,
            words,
            snippet: line.trim().slice(0, 120),
          });
        }
      });
    }
  }
  return hits;
}

function selftest() {
  const r = [];
  const t = (name, ok) => r.push({ name, ok });
  const clean = '優惠期間已結束，本券仍可依保底價值兌換，未使用之價值完整保留';

  // 1) 抓法自檢：已知存在的字串必須命中
  t('抓法自檢：已知字串必命中', scanText('本券有使用期限').includes('使用期限'));
  // 2) 乾淨文案零命中，且用第二種抓法再確認一次
  t('乾淨文案零命中', scanText(clean).length === 0);
  t('零命中雙重確認（第二種抓法）', scanTextCross(clean).length === 0);
  // 3) 注入違禁詞必命中
  t('注入違禁詞必命中', scanText('逾期無效，餘額不得消費').length === 2);
  // 4) 兩種抓法在全部樣本上結果一致
  const samples = ['', clean, '本券有使用期限', '逾期作廢', '到期失效', '正常使用方式與面額'];
  for (const s of samples) {
    t(`交叉驗證一致：${JSON.stringify(s.slice(0, 16))}`,
      JSON.stringify(scanText(s)) === JSON.stringify(scanTextCross(s)));
  }
  // 5) 臺灣版大陸語彙也要被兩種抓法一致命中（避免只加詞表、抓法卻沒跟上）
  for (const w of ['券種', '提現', '有效期']) {
    t(`臺灣用語禁詞命中：${w}`,
      scanText(w).includes(w) && scanTextCross(w).includes(w));
  }
  return r;
}

if (require.main === module) {
  if (process.argv.includes('--selftest')) {
    const results = selftest();
    for (const x of results) console.log(`${x.ok ? 'PASS' : 'FAIL'}  ${x.name}`);
    const failed = results.filter((x) => !x.ok).length;
    console.log(`[selftest] ${results.length} checks, ${failed} failed`);
    process.exit(failed ? 1 : 0);
  }
  const hits = scanRepo();
  if (hits.length) {
    for (const h of hits) console.error(`BANNED ${h.file}:${h.line} [${h.words.join(',')}] ${h.snippet}`);
    console.error(`[compliance] ${hits.length} violation(s)`);
    process.exit(1);
  }
  console.log('[compliance] OK — 對外文案無法規禁用語');
}

module.exports = { BANNED, TARGET_DIRS, scanText, scanTextCross, scanRepo, selftest };
