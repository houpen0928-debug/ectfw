#!/usr/bin/env bash
# ECT-TW GCP 專案 bootstrap（冪等、只開免費 API、不建任何付費資源）
# 用法：在 Cloud Shell 執行
#   bash gcp-bootstrap.sh                    # 預設專案 ID ect-tw-prod
#   bash gcp-bootstrap.sh my-project-id      # 自訂專案 ID
#   bash gcp-bootstrap.sh my-project-id asia-east1
set -euo pipefail

PROJECT_ID="${1:-ect-tw-prod}"
REGION="${2:-asia-east1}"
PROJECT_NAME="ECT-TW"

say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
ok()  { printf '  \033[1;32m[OK]\033[0m %s\n' "$*"; }
warn(){ printf '  \033[1;33m[!!]\033[0m %s\n' "$*"; }

say "0. 目前身分"
gcloud auth list --filter=status:ACTIVE --format="value(account)"
echo "  專案 ID  : $PROJECT_ID"
echo "  專案名稱 : $PROJECT_NAME"
echo "  區域     : $REGION"

say "1. 建立專案（已存在則跳過，不報錯）"
if gcloud projects describe "$PROJECT_ID" >/dev/null 2>&1; then
  ok "專案已存在：$PROJECT_ID"
else
  if ! gcloud projects create "$PROJECT_ID" --name="$PROJECT_NAME" 2>/tmp/ect-create.err; then
    warn "建立失敗，常見原因：專案 ID 已被全球佔用（ID 必須全域唯一）"
    cat /tmp/ect-create.err
    echo
    echo "請換一個 ID 重跑，例如：bash $0 ${PROJECT_ID}-tw"
    exit 1
  fi
  ok "已建立：$PROJECT_ID"
fi

say "2. 切換到本專案並固定區域"
gcloud config set project "$PROJECT_ID" >/dev/null
gcloud config set compute/region "$REGION" >/dev/null
gcloud config set run/region "$REGION" >/dev/null 2>&1 || true
ok "project=$PROJECT_ID  region=$REGION"

say "3. 啟用必要 API（enable 本身不收費；建立資源才收費）"
# 逐個 enable 並容錯回報，避免一個失敗全斷
for api in \
  cloudresourcemanager.googleapis.com \
  run.googleapis.com \
  sqladmin.googleapis.com \
  secretmanager.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  iam.googleapis.com
do
  if gcloud services enable "$api" --project="$PROJECT_ID" >/dev/null 2>&1; then
    ok "$api"
  else
    warn "$api 啟用失敗（多半是尚未綁定帳單帳戶，或帳號無權限）"
  fi
done

say "4. 驗證：已啟用的 API"
gcloud services list --enabled --project="$PROJECT_ID" --format="value(config.name)" | sort

say "5. 帳單狀態（只讀，不綁定）"
BILLING=$(gcloud billing projects describe "$PROJECT_ID" --format="value(billingEnabled)" 2>/dev/null || echo "UNKNOWN")
if [ "$BILLING" = "True" ]; then
  ok "已綁定帳單帳戶"
else
  warn "尚未綁定帳單（billingEnabled=$BILLING）→ 到 Console 手動綁，本腳本刻意不代綁（避免綁錯帳戶產生費用）"
fi

cat <<'EOF'

────────────────────────────────────────
下一步（都要手動、都要先確認費用）：
  1) Console → Billing → 綁定「選我科技有限公司」帳單帳戶
  2) 建立服務帳號（最小權限）與 Secret Manager 金鑰槽位
  3) 建 Cloud SQL / Cloud Run 前先跟洪哥 confirm（會產生費用）
本腳本沒有建立任何付費資源，可安全重複執行。
EOF
