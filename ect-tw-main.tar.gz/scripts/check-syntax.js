'use strict';
// 全專案 JS 語法檢查（不依賴 lint 套件）
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
// apps/ 為零構建前端 JS（核銷台等），也要納入 node --check，避免前端語法錯誤進生產 image
const DIRS = ['src', 'db', 'config', 'scripts', 'tests', 'apps'];

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name === '.git') continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, out);
    else if (e.name.endsWith('.js')) out.push(full);
  }
  return out;
}

const files = DIRS.flatMap((d) => walk(path.join(ROOT, d)));
let failed = 0;
for (const f of files) {
  try {
    execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' });
  } catch (err) {
    console.error(`SYNTAX ${path.relative(ROOT, f)}: ${String(err.stderr || err.message).trim()}`);
    failed++;
  }
}
console.log(`[check] ${files.length} js files, ${failed} failed`);
process.exit(failed ? 1 : 0);
