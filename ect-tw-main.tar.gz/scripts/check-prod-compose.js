#!/usr/bin/env node
'use strict';
/**
 * 生產 compose 靜態檢查器。
 *
 * 為什麼不用 YAML parser：本機與 CI 都不一定有 docker / yaml 套件，
 * 而這裡要驗證的是「幾條不可退讓的部署紀律」，純文字行比對反而更穩、更好做反向自測。
 *
 *   node scripts/check-prod-compose.js             檢查（CI / npm run compose）
 *   node scripts/check-prod-compose.js --selftest  反向自測：確認每條規則真的會咬人
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const COMPOSE = path.join(ROOT, 'docker-compose.yml');
const SELFTEST = process.argv.includes('--selftest');

function readCtx(root = ROOT) {
  const p = (f) => {
    try { return fs.readFileSync(path.join(root, f), 'utf8'); } catch { return ''; }
  };
  return {
    root,
    compose: p('docker-compose.yml'),
    dockerfile: p('Dockerfile'),
    gitignore: p('.gitignore'),
    httpConf: p('deploy/nginx/http.conf'),
    sslConf: p('deploy/nginx/ssl.conf'),
    dockerignore: p('.dockerignore'),
    server: p('src/server.js'),
  };
}

// 只取 services: 區塊（到下一個頂層鍵為止），避免把 volumes 下的 ect_tw_pg 誤認成服務
function servicesBlock(src) {
  const lines = src.split(/\r?\n/);
  const buf = [];
  let inside = false;
  for (const line of lines) {
    if (/^services:\s*$/.test(line)) { inside = true; continue; }
    if (inside && /^[A-Za-z]/.test(line)) break;
    if (inside) buf.push(line);
  }
  return buf.join('\n');
}

function splitServices(src) {
  const block = servicesBlock(src);
  const out = {};
  let cur = null;
  for (const line of block.split(/\r?\n/)) {
    const m = /^  ([A-Za-z0-9_-]+):\s*$/.exec(line);
    if (m) { cur = m[1]; out[cur] = []; continue; }
    if (cur) out[cur].push(line);
  }
  return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, v.join('\n')]));
}

const NAMES = ['postgres', 'app', 'nginx'];

const RULES = [
  {
    id: 'R01-services',
    desc: 'postgres / app / nginx 三服務皆定義',
    test: (c) => NAMES.every((n) => Object.prototype.hasOwnProperty.call(splitServices(c.compose), n)),
  },
  {
    id: 'R02-password-interpolation',
    desc: 'POSTGRES_PASSWORD 必須走 ${} 插值，不得有明文字串',
    test: (c) => /POSTGRES_PASSWORD:\s*\$\{[^}]+\}/.test(c.compose) &&
      !/POSTGRES_PASSWORD:\s*["']?[A-Za-z0-9_!@#%-]{4,}["']?\s*$/m.test(c.compose),
  },
  {
    id: 'R03-pg-loopback-only',
    desc: 'postgres 對外埠只綁 127.0.0.1（不得 0.0.0.0 / 直接 ":5432"）',
    test: (c) => {
      const s = splitServices(c.compose).postgres || '';
      const ports = s.split(/\r?\n/).filter((l) => /^\s*-\s*["']?.*:5432["']?\s*$/.test(l));
      return ports.length > 0 && ports.every((l) => /127\.0\.0\.1:/.test(l));
    },
  },
  {
    id: 'R04-app-no-public-port',
    desc: 'app 只有 expose，不得宣告 ports（唯一入口是 nginx）',
    test: (c) => {
      const s = splitServices(c.compose).app || '';
      return /^\s*expose:/m.test(s) && !/^\s*ports:/m.test(s);
    },
  },
  {
    id: 'R05-healthcheck',
    desc: '三服務皆設 healthcheck',
    test: (c) => { const s = splitServices(c.compose); return NAMES.every((n) => /^\s*healthcheck:/m.test(s[n] || '')); },
  },
  {
    id: 'R06-restart',
    desc: '三服務皆設 restart: unless-stopped',
    test: (c) => { const s = splitServices(c.compose); return NAMES.every((n) => /restart:\s*unless-stopped/.test(s[n] || '')); },
  },
  {
    id: 'R07-memory-limit',
    desc: '三服務皆設 mem_limit（1GB RAM 機型的硬約束）',
    test: (c) => { const s = splitServices(c.compose); return NAMES.every((n) => /^\s*mem_limit:/m.test(s[n] || '')); },
  },
  {
    id: 'R08-no-new-privileges',
    desc: '三服務皆設 no-new-privileges',
    test: (c) => { const s = splitServices(c.compose); return NAMES.every((n) => /no-new-privileges:true/.test(s[n] || '')); },
  },
  {
    id: 'R09-log-rotation',
    desc: 'json-file log 輪轉（max-size / max-file）',
    test: (c) => /max-size:\s*"\d+m"/.test(c.compose) && /max-file:\s*"\d+"/.test(c.compose),
  },
  {
    id: 'R10-migrate-on-boot',
    desc: '啟動命令先跑版本化 migration 再起服務',
    test: (c) => /node db\/migrate\.js && node src\/server\.js/.test(c.compose),
  },
  {
    id: 'R11-no-privileged-or-host-net',
    desc: '不得 privileged / network_mode: host',
    test: (c) => c.compose.trim().length > 0 &&
      !/privileged:\s*true/.test(c.compose) && !/network_mode:\s*host/.test(c.compose),
  },
  {
    id: 'R12-pinned-images',
    desc: 'image 皆有明確 tag，不用 :latest',
    test: (c) => {
      const imgs = [...c.compose.matchAll(/^\s*image:\s*(\S+)/gm)].map((m) => m[1]);
      return imgs.length >= 2 && imgs.every((i) => /:[A-Za-z0-9._-]+$/.test(i)) && !imgs.some((i) => /:latest$/.test(i));
    },
  },
  {
    id: 'R13-nginx-conf-switch',
    desc: 'nginx conf 由 NGINX_CONF 環境變數切換（http / ssl）',
    test: (c) => /\$\{NGINX_CONF:-http\}\.conf/.test(c.compose),
  },
  {
    id: 'R14-conf-health-endpoint',
    desc: '兩份 nginx conf 皆提供 /nginx-health（healthcheck 不受 301 影響）',
    test: (c) => /location\s*=\s*\/nginx-health/.test(c.httpConf) && /location\s*=\s*\/nginx-health/.test(c.sslConf),
  },
  {
    id: 'R15-certs-not-in-repo',
    desc: '憑證私鑰被 .gitignore 與 .dockerignore 排除',
    test: (c) => /\*\.pem/.test(c.gitignore) && /\*\.key/.test(c.gitignore) &&
      /\.env/.test(c.dockerignore) && /deploy\/certs\/\*\.key/.test(c.dockerignore),
  },
  {
    id: 'R16-backups-ignored',
    desc: '備份檔與 backups/ 不入庫',
    test: (c) => /backups\//.test(c.gitignore) && /\*\.dump/.test(c.gitignore),
  },
  {
    id: 'R17-verify-assets-in-image',
    desc: '核銷台靜態檔必須進 image（Dockerfile COPY apps；.dockerignore 不得排除 apps）',
    // 起因：M1 第二批加了 /verify，但 Dockerfile 未 COPY apps 且 .dockerignore 排除 apps，
    //       上線會 404。CI 直接跑 node 不會抓到，只能靠靜態規則擋。
    test: (c) => /^\s*COPY\s+apps\s+\.\/apps\s*$/m.test(c.dockerfile) &&
      !/^\s*apps(?:\s|\/|$)/m.test(c.dockerignore),
  },
  {
    id: 'R18-site-static-mounted',
    desc: 'server.js 必須掛 /verify、/admin 與 / 官網三組 express.static（漏掛＝上線 404）',
    // 起因：R17 只保證「檔案進了 image」，但路由沒掛照樣 404。
    // 兩種獨立抓法交叉驗證：① 正則比對 app.use 掛載 ② 字串比對 apps 目錄參數。
    test: (c) => {
      const mounted = (prefix) => new RegExp(
        "app\\.use\\(\\s*'" + prefix + "'\\s*,\\s*express\\.static\\("
      ).test(c.server);
      const dirs = c.server.includes("'apps', 'verify'") &&
        c.server.includes("'apps', 'admin'") && c.server.includes("'apps', 'web'");
      return mounted('/verify') && mounted('/admin') && mounted('/') && dirs;
    },
  },
];

function evaluate(ctx) {
  const failed = RULES.filter((r) => {
    let ok = false;
    try { ok = r.test(ctx) === true; } catch { ok = false; }
    return !ok;
  });
  return failed;
}

function selftest() {
  const good = readCtx();
  const realFails = evaluate(good);
  const problems = [];

  if (realFails.length) {
    problems.push(`真實檔案本身未通過：${realFails.map((r) => r.id).join(', ')}`);
  }

  // 反向測試 1：空白 ctx 時，每條規則都必須「咬人」；仍回 true 代表規則寫成永真（寫錯）
  const blank = {
    root: ROOT, compose: '', dockerfile: '', gitignore: '',
    httpConf: '', sslConf: '', dockerignore: '', server: '',
  };
  for (const r of RULES) {
    let ok = false;
    try { ok = r.test(blank) === true; } catch { ok = false; }
    if (ok) problems.push(`${r.id} 在空白輸入仍回 PASS（規則可能是永真，等於沒檢查）`);
  }

  // 反向測試 2：針對性注入違規，確認對應規則真的會失敗（用第二種獨立抓法交叉驗證）
  const mutations = [
    { id: 'R02-password-interpolation', from: /\$\{ECT_PG_PASSWORD:\?[^}]+\}/, to: 'hunter2' },
    { id: 'R03-pg-loopback-only', from: '127.0.0.1:${ECT_PG_HOST_PORT:-5433}:5432', to: '0.0.0.0:5432:5432' },
    { id: 'R04-app-no-public-port', from: '    expose: ["3000"]', to: '    ports: ["3000:3000"]\n    expose: ["3000"]' },
    { id: 'R11-no-privileged-or-host-net', from: '    logging: *logging', to: '    privileged: true\n    logging: *logging' },
    { id: 'R14-conf-health-endpoint', from: 'location = /nginx-health', to: 'location = /removed' },
    { id: 'R17-verify-assets-in-image', from: 'COPY apps ./apps', to: '' },
    { id: 'R18-site-static-mounted', from: "app.use('/', express.static(", to: "app.use('/removed', express.static(" },
  ];
  const covered = new Set();
  const has = (needle, hay) => (typeof needle === 'string' ? hay.includes(needle) : needle.test(hay));
  for (const m of mutations) {
    const ctx = { ...good };
    if (m.id === 'R14-conf-health-endpoint') {
      ctx.httpConf = good.httpConf.replace(m.from, m.to);
    } else if (m.id === 'R17-verify-assets-in-image') {
      if (!good.dockerfile.includes(m.from)) { problems.push(`${m.id} 的注入錨點不存在，反向測試無效`); continue; }
      ctx.dockerfile = good.dockerfile.replace(m.from, m.to);
    } else if (m.id === 'R18-site-static-mounted') {
      if (!good.server.includes(m.from)) { problems.push(`${m.id} 的注入錨點不存在，反向測試無效`); continue; }
      ctx.server = good.server.replace(m.from, m.to);
    } else {
      if (!has(m.from, good.compose)) { problems.push(`${m.id} 的注入錨點不存在，反向測試無效`); continue; }
      ctx.compose = good.compose.replace(m.from, m.to);
    }
    const rule = RULES.find((r) => r.id === m.id);
    let ok = false;
    try { ok = rule.test(ctx) === true; } catch { ok = false; }
    if (ok) problems.push(`${m.id} 注入違規後仍回 PASS（抓不到 = 檢查器寫錯）`);
    covered.add(m.id);
  }

  // 反向測試 3：注入案例必須覆蓋「會被誤寫成正則」的關鍵規則
  for (const must of ['R02-password-interpolation', 'R03-pg-loopback-only', 'R04-app-no-public-port', 'R11-no-privileged-or-host-net', 'R14-conf-health-endpoint', 'R17-verify-assets-in-image', 'R18-site-static-mounted']) {
    if (!covered.has(must)) problems.push(`${must} 缺少針對性注入測試`);
  }

  // 反向測試 4（R17 第二種獨立注入）：.dockerignore 重新排除 apps 也必須被抓
  {
    const ctx = { ...good, dockerignore: `${good.dockerignore}\napps\n` };
    const rule = RULES.find((r) => r.id === 'R17-verify-assets-in-image');
    let ok = false;
    try { ok = rule.test(ctx) === true; } catch { ok = false; }
    if (ok) problems.push('R17 在 .dockerignore 注入 apps 後仍回 PASS（抓不到 = 檢查器寫錯）');
  }

  // 反向測試 5（R18 第二種獨立注入）：目錄參數寫錯也必須被抓（與正則抓法互相獨立）
  {
    const ctx = { ...good, server: good.server.replace("'apps', 'web'", "'apps', 'missing'") };
    const rule = RULES.find((r) => r.id === 'R18-site-static-mounted');
    let ok = false;
    try { ok = rule.test(ctx) === true; } catch { ok = false; }
    if (ok) problems.push('R18 在 apps 目錄注入後仍回 PASS（抓不到 = 檢查器寫錯）');
  }

  if (problems.length) {
    console.error(`[compose] SELFTEST FAIL (${problems.length})`);
    problems.forEach((p) => console.error('  ✗ ' + p));
    process.exit(1);
  }
  console.log(`[compose] SELFTEST OK：${RULES.length} 條規則皆「空白會咬人」，${mutations.length + 2} 組注入違規全數被抓`);
}

function main() {
  if (SELFTEST) return selftest();
  const failed = evaluate(readCtx());
  if (failed.length) {
    console.error(`[compose] FAIL (${failed.length}/${RULES.length})`);
    failed.forEach((r) => console.error(`  ✗ ${r.id} ${r.desc}`));
    process.exit(1);
  }
  console.log(`[compose] PASS：${RULES.length}/${RULES.length} 項部署紀律檢查通過`);
}

main();
