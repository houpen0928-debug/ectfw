#!/usr/bin/env bash
# ECT-TW 還原 — 會 DROP 既有物件，故強制二次確認（與「動錢不自動執行」同級）
# 用法：./scripts/restore.sh backups/ect_tw-20261118-031700.dump
set -euo pipefail

ROOT="${ECT_DEPLOY_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
FILE="${1:-}"

if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
  echo "用法: $0 <backups/ect_tw-YYYYmmdd-HHMMSS.dump>" >&2
  exit 2
fi

echo "⚠️  即將覆蓋資料庫 ect_tw（--clean --if-exists 會先 DROP 既有物件）。"
echo "    檔案: $FILE"
printf '輸入 YES 繼續：'
read -r ans
if [ "$ans" != "YES" ]; then
  echo "已取消，資料庫未變動"
  exit 1
fi

cd "$ROOT"
# 還原期間停 app 避免並發寫入；不論成功失敗都要把 app 拉回來
docker compose stop app
trap 'docker compose start app >/dev/null 2>&1 || true' EXIT

docker compose exec -T postgres \
  pg_restore -U ect -d ect_tw --clean --if-exists --no-owner --no-privileges \
  < "$FILE"

echo "[restore] OK：請再跑 docker compose exec -T app node db/migrate.js --check 核對版本"
